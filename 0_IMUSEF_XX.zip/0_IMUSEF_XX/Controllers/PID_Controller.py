import time
from IMUSEF_Data import IMUSEF_Data
from Controllers.PID_Input import PID_Input


class PID_Controller(object):

    def __init__(self):

        self.Input = PID_Input()

        self.PIDInitialized = False
        #self.DesiredCadence = 0
        self.interr = 0
        self.data = IMUSEF_Data()
        self.LastCadence = 0
        self.Previous = 0
        self.P = 0.5
        self.I = 1
        self.D = 0.4
        #self.Max = 0
        #self.Min = 0
        self.CV_Min = 0
        self.CV_Max = 0
        self.OV = 0
        self.OV_Max = 0
        self.OV_add = 0
        self.result = 0
        self.PIDresult = 0
        self.DesiredCadence = 0
        self.CurrentCadence = 0
        self.Baseline = 0
        self.STresult = [0, 0, 0]
        self.Test = 0
        self.Elapsed = 0
        self.Init = 0
        self.start = 0
        self.c = 0
        self.d = 0
        self.equalizer = 1
        self.LastPower = 0
        self.LastLeg = 0

    def updateDCadence(self, C):
        self.DesiredCadence = C

        return True

    def updateCCadence(self, C):
        self.CurrentCadence = C

        return True

    def updateCV(self, Min, Max):
        self.CV_Min = Min
        self.CV_Max = Max

        return True

    #def updateInput(self, CrankAngle):
     #   self.Input.update(CrankAngle)



    def PID(self,Mode):

        if Mode == 0: #Amplitude
            self.P = 0.8
            self.I = 0.5
            self.D = 0
            self.OV = 400 + self.OV_add*10
            self.OV_Max = 0
            #self.Max = 60
            #self.Min = 20
        elif Mode == 1: #Frequency
            self.P = 4.4
            self.I = 5.5
            self.D = 0.4
            #self.Max = 60
            #self.Min = 20
        else:           #Phasewidth
            self.P = 8
            self.I = 5
            self.D = 0
            self.OV = 60 + self.OV_add
            self.OV_Max = 0
            #self.Max = 1000
            #self.Min = 150

        if self.CurrentCadence == 0:
             self.interr = 0
             self.PIDresult=0




        #if self.LastCadence != self.CurrentCadence:
        CCadence = self.CurrentCadence
        Now = time.time()

        err = self.DesiredCadence - CCadence

        if self.PIDInitialized:
            diff = Now - self.Previous
            RoC = (CCadence - self.LastCadence) / diff
            # if CCadence == 0:
            #     self.interr = 0
            # else:
            if (self.I * self.interr) < (self.CV_Max - self.P * err):
                self.interr = self.interr + err * diff
            if (self.I * self.interr) > (self.CV_Max - self.P * err) and self.I !=0:
                self.OV_add = self.OV_add + ((((self.I * self.interr) - (self.CV_Max - self.P * err)))/2)
                self.interr = (self.CV_Max - self.P * err)/self.I

            if CCadence <= 0:
                self.interr = 0
                self.OV_add = 0
                self.equalizer = 1

            self.result = self.P * err + self.I * self.interr - self.D * RoC + self.CV_Min

        else:
            self.PIDInitialized = True
            self.result = self.P * err
            self.OV_add = 0

        self.LastCadence = CCadence
        self.Previous = Now

        if self.OV_add > self.OV_Max:
            self.OV_add = self. OV_Max

        if self.result > self.CV_Max:
            self.PIDresult = self.CV_Max
        elif (self.result < self.CV_Min) and (CCadence <= self.DesiredCadence):
            self.PIDresult = self.CV_Min
        elif (self.result < self.CV_Min) and (CCadence > self.DesiredCadence):
            self.PIDresult = self.CV_Min
        else:
            self.PIDresult = self.result

    def equalize(self, active, Power_Left, Power_Right):

            if Power_Right - Power_Left < -3:
                if active[0]:
                    self.PIDresult = self.PIDresult * (1+0.01*self.equalizer)
                elif active[4]:
                    self.PIDresult = self.PIDresult * (1-0.01*self.equalizer)
                if self.LastLeg == 2:
                    self.equalizer = 1
                self.LastLeg = 1
            elif Power_Left - Power_Right < -3:
                if active[0]:
                    self.PIDresult = self.PIDresult * (1-0.01*self.equalizer)
                elif active[4]:
                    self.PIDresult = self.PIDresult * (1+0.01*self.equalizer)
                    if self.LastLeg == 1:
                        self.equalizer = 1
                self.LastLeg = 2

            if self.LastPower != Power_Left:
                if Power_Right - Power_Left < -3 or Power_Left - Power_Right < -3:
                    self.equalizer = self.equalizer+1
                else:
                    self.equalizer = 1
                self.LastPower = Power_Left



    def getResult(self):
        return self.PIDresult

    def getOtherVariable(self):
        return self.OV

    def resetPID(self):
        self.interr = 0
        self.OV_add = 0

    def ST_TEST(self, Mode):
        Now = time.time()
        if self.Init == 0:
            self.start = Now
            self.Init = 1
            self.c = 0
            self.d = 1
            self.STresult = [10, 20, 200, 1]
        self.Elapsed = Now - self.start

        if (self.c*20) <= self.Elapsed <= ((self.c+1)*20):
            Now = time.time()
            self.Elapsed = Now - self.start
            if Mode == 0:
                self.STresult=[(34 + (self.c * 1)), 40, 1000, 1]

            elif Mode == 1:
                self.STresult=[60, (20 + (self.c * 2)), 400, 1]

            else:
                self.STresult=[70, 40, (100 + (self.c * 25)), 1]

        else:
            if (self.d * 20) <= self.Elapsed <= ((self.d + 1) * 20):
                self.STresult = [30, 30, 400, 1]
            else:
                self.d = self.d+2
                self.c = self.c+2



        if self.c > 36:
            self.STresult = [0, 30, 400, 0]
            self.start = 0
            self.Init = 0


    def getST(self):
        return self.STresult

    def PID_TEST_Cadence(self):
        Now = time.time()
        if self.Init == 0:
            self.start = Now
            self.Init = 1
            self.Test = 20
        self.Elapsed = Now - self.start
        if self.Elapsed < 10:
            self.Test = 20
        elif 10 <= self.Elapsed < 40:
            self.Test = 40
        elif 40 <= self.Elapsed < 70:
            self.Test = 50
        elif 70 <= self.Elapsed < 110:
            self.Test = 30
        elif 110 <= self.Elapsed:
            self.Init = 0
            self.Test = 5


    def getTest(self):
        return self.Test


