
class Biodex_Controller_Data(object):
    def __init__(self):

        # Stimulation Flags
        self.activeChannels = [False, False, False, False, False, False, False, False]

        self.BiodexPosition = 0
        self.BiodexSpeed = 0
        self.KneeExtensionAngle = 0
        self.SIDE = 0
        self.StimFlag = False



