
class PID_Controller_Data(object):
    def __init__(self):

        # Cadence
        self.RTCadence = 0.0
        self.RTCadenceSmooth = 0.0

