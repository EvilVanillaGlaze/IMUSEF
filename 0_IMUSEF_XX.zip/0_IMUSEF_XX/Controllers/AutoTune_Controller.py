import time
import numpy as np
import copy
import json
from json import encoder

class AutoTune_Controller(object):

    # Constants
    LEFT = 0
    RIGHT = 1
    NONE = -1
    CRANKANGLE = 0
    THIGHANGLE = 1

    def __init__(self):




        # Internal Settings
        self.__TorqueDelay = 20                                 # Samples - Delay of Rotor Powermeter is 200 ms against Reality -> 20 Samples
        self.__SensorDelay = 20                                 # Samples - Delay of Sensor Signal against Reality
        self.__Delay = self.__TorqueDelay - self.__SensorDelay  # Overall Delay between Sensor- and Torque-Signal

        self.__SAMPLE_PERIODE = 10.0    # [ms]

        # User Settings
        self.StimChannels = [False, False, False, False, False, False, False, False]  # Stimulation Channels to be used
        self.StimSide   = "LEFT"
        self.Intensity = 20        # Stimulation intensity in [%]

        self.Target_Cadence = 30.0          # RPM
        self.Tolerance_Cadence = 10.0       # %

        self.NumberOfCycles = 3         # Number of traces to record and average

        self.__SensorType = self.CRANKANGLE

        self.Threshold_Start = 0        # Threshold which needs to be passed (in % of max torque) to detect the start
        self.Threshold_Stop = 0         # Threshold which needs to be passed (in % of max torque) to detect the stop

        self.__maxTorque = 0.0
        self.__TH_Start = 0.0
        self.__TH_Stop = 0.0



        # Status of the Module
        # -1 ... Inactive
        #  0 ... Aquire passive traces
        #  1 ... Aquire active traces
        #  2 ... Finished aquisition
        self.__MODE = -1

        self.__X_REF = (np.linspace(0,360,361)).tolist()   # Defines the desired range

        # Variables
        self.__X = []        # Sensor Data
        self.__lastX = None
        self.__Y = []        # Torque Data

        self.__NewCycle_idx = None
        self.__LastNewCycle_idx = None
        self.__LastNewCycle_time = None

        self.__NewCycle = False
        self.__skipCycle = False        # This flag is used to add an accomodation cycle for the stimulation to get active

        # Output
        self.Cadence = 0
        self.n_passive = 0
        self.n_active = 0

        self.__Torques_passive = []
        self.__Torques_active = []

        self.__Active_Torque_AVG = []
        self.__Passive_Torque_AVG = []
        self.__Diff_Torque_AVG = []

        self.START = None
        self.STOP = None
        self.BEEP = False


    # Sets a new Sensortype and initializes the X_REF data array
    def set_SensorType(self, SensorType):

        self.__SensorType = SensorType

        if SensorType == self.CRANKANGLE:
            self.__X_REF = (np.linspace(0,360,361)).tolist()
            self.__SensorDelay = 20     # RotorDelay is estimated to be 200ms
            self.__TorqueDelay = 20     # RotorDelay is estimated to be 200ms

        elif SensorType == self.THIGHANGLE:
            self.__X_REF = (np.linspace(0,100,101)).tolist()
            self.__SensorDelay = 4      # IMUs have an estimated delay of 35ms. This is about 4 samples at 100Hz.
                                        # Adaptive Smoothing is not taken into account because it should be turned off
                                        # when AutoTune is active.
            self.__TorqueDelay = 20     # RotorDelay is estimated to be 200ms
        else:
            self.__SensorType = self.NONE

    # Returns the current Sensortype
    def get_SensorType(self):
        return self.__SensorType

    # Sets the Delays of the different Sensors against Reality
    def set_Delays(self, SensorDelay, TorqueDelay = 20):

        self.__SensorDelay = SensorDelay
        self.__TorqueDelay = TorqueDelay

        self.__Delay = self.__TorqueDelay - self.__SensorDelay


    # Starts the AutoTune Module
    def start(self):

        # Initialize Tracking Variables
        self.__X = []
        self.__Y = []
        self.__lastX = None

        self.__NewCycle_idx = None
        self.__LastNewCycle_idx = None
        self.__LastNewCycle_time = None

        self.__NewCycle = False
        self.__skipCycle = False

        self.__Torques_passive = []
        self.__Torques_active = []

        self.__Active_Torque_AVG = []
        self.__Passive_Torque_AVG = []
        self.__Diff_Torque_AVG = []

        self.START = None
        self.STOP = None
        self.BEEP = False

        self.Cadence = 0
        self.n_passive = 0
        self.n_active = 0

        self.__MODE = 0

    # Stops the AutoTune Module
    def stop(self):
        self.start()
        self.__MODE = -1
        self.__activeChannels = [False, False, False, False, False, False, False, False]

    def update(self, SensorValue, TorqueValue):

        if self.__MODE < 0:
            return

        # Add data
        self.__X.append(SensorValue)
        self.__Y.append(TorqueValue)

        # Current Index of last added data-point
        n = len(self.__X)-1

        # Init Check
        if self.__lastX is None:
            self.__lastX = SensorValue

        diff = SensorValue - self.__lastX
        self.__lastX = SensorValue

        # Jump detected
        if diff < -60:

            # Initial Flank detected
            if self.__LastNewCycle_idx is None:
                self.__LastNewCycle_idx = n
                self.__LastNewCycle_time = time.time()

            else:

                # Check if the recorded cycle matches the Cadence criteria
                time_now = time.time()

                self.Cadence = 60/(time_now-self.__LastNewCycle_time)
                Cadence_min = self.Target_Cadence * (1 - self.Tolerance_Cadence / 100.0)
                Cadence_max = self.Target_Cadence * (1 + self.Tolerance_Cadence / 100.0)

                # Wuhu - Matching Cycle :)
                if self.Cadence >= Cadence_min  and self.Cadence <= Cadence_max and self.__skipCycle == False:
                    self.__NewCycle = True
                    self.__NewCycle_idx = n
                    self.__LastNewCycle_time = time_now

                # Cycle did not match the criteria - ignore current and wait for the next one
                else:
                    self.__LastNewCycle_idx = n
                    self.__LastNewCycle_time = time_now

                # Only skip one cycle
                if self.__skipCycle:
                    self.__skipCycle = False


        # New valid cycle detected - wait for sensor delay
        if self.__NewCycle and n > self.__NewCycle_idx + self.__Delay:

            start_X = self.__LastNewCycle_idx
            stop_X = n - self.__Delay - 1

            start_Y = start_X + self.__Delay
            stop_Y = stop_X + self.__Delay

            # Cut out data
            x_temp = self.__X[start_X:stop_X]
            y_temp = self.__Y[start_Y:stop_Y]

            # Unify data to get rid of duplicates.... nobody likes duplicates -> just be original
            [x_temp, y_temp] = self.__unifyData(x_temp, y_temp)

            # Resample data to fixed size
            y_temp = self.__resampleData(self.__X_REF, x_temp, y_temp)

            # Store Data into results
            if self.__MODE == 0:
                self.__Torques_passive.append(y_temp)
                self.n_passive = self.n_passive + 1
                self.BEEP = True

            elif self.__MODE == 1:
                self.__Torques_active.append(y_temp)
                self.n_active = self.n_active + 1
                self.BEEP = True


            # Redetermine Mode
            if self.n_passive == self.NumberOfCycles and self.n_active < self.NumberOfCycles and self.__MODE == 0:

                self.__MODE = 1

                # Give the stimulation some time to get active
                self.__skipCycle = True

            elif self.n_passive == self.NumberOfCycles and self.n_active == self.NumberOfCycles and self.__MODE < 2:
                self.__MODE = 2

                # Calculate Results
                self.__Passive_Torque_AVG = self.__get_Passive_AVG()
                self.__Active_Torque_AVG = self.__get_Active_AVG()
                self.__Diff_Torque_AVG = self.__get_Diff_AVG()
                try:
                    self.__get_Start_Stop()
                except Exception:
                    self.START = -1
                    self.STOP = -1

            # Release data fom Tracking lists
            self.__X = self.__X[self.__NewCycle_idx:n]
            self.__Y = self.__Y[self.__NewCycle_idx:n]

            # Reinitialize Cycle indices
            self.__NewCycle = False
            self.__LastNewCycle_idx = 0


    # This function returns a unifyfied data array. If there are multiple X-datapoints with the same value
    # this function will average the corresponding y-datapoints and return a single unique douplet of X,Y.
    # Additionally the function ensures that the data is stricly monotonously rising. Decreasing values will
    # be removed.
    def __unifyData(self, X, Y):
        X_new = []
        Y_new = []

        ## Ensure strict monotonous rising behaviour
        last_X = X[0]
        X_new.append(X[0])
        Y_new.append(Y[0])

        for i in range(1, len(X)):

            if X[i] >= last_X:
                last_X = X[i]
                X_new.append(X[i])
                Y_new.append(Y[i])

        X = copy.deepcopy(X_new)
        Y = copy.deepcopy(Y_new)

        X_new = []
        Y_new = []

        ## UNIFY Dataset
        # Define end
        end = len(X) - 1

        # Init
        last_X = X[0]
        sum = Y[0]
        n = 1.0

        # Merge same values
        for i in range(1, end + 1):

            if X[i] == last_X and i < end:
                sum = sum + Y[i]
                n = n + 1.0

            elif X[i] != last_X and i < end:
                X_new.append(last_X)
                Y_new.append(sum / n)

                last_X = X[i]
                sum = Y[i]
                n = 1.0

            elif X[i] == last_X and i == end:

                X_new.append(last_X)
                Y_new.append(sum / n)

            elif X[i] != last_X and i == end:

                X_new.append(last_X)
                Y_new.append(sum / n)

                X_new.append(X[i])
                Y_new.append(Y[i])

        return [X_new, Y_new]


    # Returns a resampled version of the data interpolated for the x-values given in X_ref
    # Values which are out of the boundaries will be replaced by either the first or last value of
    # the data provided in Y
    def __resampleData(self, X_ref, X, Y):

        # Define extremes
        end = len(Y) - 1
        LEFT = Y[0]
        RIGHT = Y[end]

        # Interpolation
        Y_new = np.interp(X_ref, X, Y, left=LEFT, right=RIGHT)

        return Y_new.tolist()

    # Finishes the Measurement and deactivates AutoTune
    def finishMeasurement(self):
        self.__MODE = -1

    # Returns an average of the recorded passive torques
    def __get_Passive_AVG(self):

        temp_Torque_AVG = [0.0] * len(self.__X_REF)

        if self.n_passive == 0:
            return temp_Torque_AVG
        elif self.n_passive == 1:
            return self.__Torques_passive[0]

        # Time to be mean ^_^
        for i in range(0,len(self.__X_REF)):

            for u in range(0,self.n_passive):

                tempTorque = self.__Torques_passive[u][i]
                temp_Torque_AVG[i] = temp_Torque_AVG[i] + tempTorque

            temp_Torque_AVG[i] = temp_Torque_AVG[i] / self.n_passive

        return temp_Torque_AVG


    # Returns an average of the recorded active torques
    def __get_Active_AVG(self):

        temp_Torque_AVG = [0.0] * len(self.__X_REF)

        if self.n_active == 0:
            return temp_Torque_AVG
        elif self.n_active == 1:
            return self.__Torques_active[0]


        # Time to be mean ^_^
        for i in range(0, len(self.__X_REF)):

            for u in range(0, self.n_active):
                tempTorque = self.__Torques_active[u][i]
                temp_Torque_AVG[i] = temp_Torque_AVG[i] + tempTorque

            temp_Torque_AVG[i] = temp_Torque_AVG[i] / self.n_active

        return temp_Torque_AVG


    # Returns the difference between averaged active and passive torque
    def __get_Diff_AVG(self):

        temp_Torque_AVG = [0.0] * len(self.__X_REF)

        if self.n_passive == 0 or self.n_active == 0:
            return temp_Torque_AVG

        # Time to be make a difference ._.
        for i in range(0, len(self.__X_REF)):

            temp_Torque_AVG[i] = self.__Active_Torque_AVG[i] - self.__Passive_Torque_AVG[i]

        return temp_Torque_AVG


    # Determine Start and Stop
    def __get_Start_Stop(self):

        # Select data
        data = self.__Diff_Torque_AVG
        n = len(data)-1    # last index of data

        self.__maxTorque = np.max(data)
        self.__TH_Start = (self.__maxTorque * self.Threshold_Start) / 100.0
        self.__TH_Stop = (self.__maxTorque * self.Threshold_Stop) / 100.0


        # Search Maximum
        idx_max = np.min(np.where(self.__Diff_Torque_AVG == self.__maxTorque))

        if idx_max <0:
            idx_max = 0
        elif idx_max > n-1:
            idx_max = n-1

        # Searching START by going left from the maximum
        for i in range(idx_max, -1, -1):

            current = data[i]
            before = data[i+1]

            # Start detection
            if current <= self.__TH_Start and before > self.__TH_Start and self.START is None:
                self.START = self.__X_REF[i]

        for i in range(n, idx_max-1, -1):

            current = data[i]

            if i == n:
                before = data[0]
            else:
                before = data[i + 1]

            # Start detection
            if current <= self.__TH_Start and before > self.__TH_Start and self.START is None:
                self.START = self.__X_REF[i]



        # Searching STOP by going right from the maximum
        for i in range(idx_max, n+1):

            current = data[i]
            before = data[i - 1]

            # Stop detection
            if current <= self.__TH_Stop and before > self.__TH_Stop and self.STOP is None:
                self.STOP = self.__X_REF[i]

        for i in range(0, idx_max+1):

            current = data[i]

            if i == 0:
                before = data[n]
            else:
                before = data[i - 1]

            # Stop detection
            if current <= self.__TH_Stop and before > self.__TH_Stop and self.STOP is None:
                self.STOP = self.__X_REF[i]


    # Returns the active Channels for stimulation
    def get_ActiveChannels(self):

        if self.__MODE == 1:
            return self.StimChannels

        return [False, False, False, False, False, False, False, False]

    # Returns the desired stimulation intensity.
    def get_Intensity(self):

        if self.__MODE == 1:
            return self.Intensity

        return 0

    # Returns the current Status of the Module
    # -1 ... Inactive
    #  0 ... Aquire passive traces
    #  1 ... Aquire active traces
    #  2 ... Finished aquisition
    def get_Status(self):
        return self.__MODE

    # Returns a JSON of the Results
    def get_JSON(self):

        start = -1
        stop = -1

        if self.START is not None:
            start = self.START

        if self.STOP is not None:
            stop = self.STOP


        auto_tune_result = {
            "Passive_AVG": self.__Passive_Torque_AVG,
            "Active_AVG": self.__Active_Torque_AVG,
            "Diff_AVG": self.__Diff_Torque_AVG,
            "X_REF": self.__X_REF,
            "Start": start,
            "Stop": stop
        }

        # Attention! This formatting might not work under python 3+
        encoder.FLOAT_REPR = lambda o: format(o, '.2f')
        encoder.c_make_encoder = None
        str = json.dumps(auto_tune_result)
        str = str.replace(".00,", ",")

        return str
