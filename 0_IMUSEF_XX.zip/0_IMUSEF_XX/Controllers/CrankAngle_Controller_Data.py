
class CrankAngle_Controller_Data(object):
    def __init__(self):

        # Stimulation Flags
        self.activeChannels = [False, False, False, False, False, False, False, False]

        # Cadence
        self.Cadence = 0.0
        self.RTCadence = 0.0
        self.RTCadenceSmooth = 0.0

