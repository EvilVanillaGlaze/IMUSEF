import numpy as np
from Gonio_Controller_Data import Gonio_Controller_Data

DEBUG = True

class Gonio_ThighAngle_Controller(object):

    def __init__(self):

        # Input Parameters
        self.__ThighAngle_Left = 0.0
        self.__ThighAngle_Right = 0.0

        # Output Parameters
        self.__Normalized_ThighAngle_Left = 0.0         # Value between 0...100
        self.__Normalized_ThighAngle_Right = 0.0        # Value between 0...100

        self.LQ = False
        self.RQ = False

        self.LH = False
        self.RH = False

        self.data = Gonio_Controller_Data()

        # Settings
        self.l_delay = 2
        self.r_delay = 2

        # Processing Variables
        self.__Last_Thigh_Angle_Left = 0.0
        self.last_r_t_angle = 0.0

        self.l_flexed = False
        self.r_flexed = False

        self.l_extended = False
        self.r_extended = False

        self.r_t_state = 0
        self.__Direction_Left = 0

        self.min_range_of_motion = 0.5 # 2
        self.min_range_between_pke_and_pkf = 5 #10

        # Limits
        self.__ROM_LIMIT = 20               # [°]
        self.__CADENCE_LIMIT_LOWER = 20     # [RPM]
        self.__CADENCE_LIMIT_UPPER = 75     # [RPM]

        # Peak detetction
        self.l_pk_e = False
        self.r_pk_e = False
        self.l_pk_f = False
        self.r_pk_f = False

        self.log_l_pk_e = False
        self.log_r_pk_e = False
        self.log_l_pk_f = False
        self.log_r_pk_f = False


        # Current Values
        self.__Left_Peak_Flexion = None #[]
        self.__Left_Peak_Extension = None

        self.__Right_Peak_Extension = None
        self.__Right_Peak_Flexion = None

        # New Values
        self.__Left_Peak_Flexion_NEW = 1000  # []
        self.__Left_Peak_Extension_NEW = -1000

        self.__Right_Peak_Extension_NEW = None
        self.__Right_Peak_Flexion_NEW = None


        # Configuration
        self.Min = 0
        self.Max = 100

        self.Start = [0, 0, 0, 0, 0, 0, 0, 0]
        self.Stop = [0, 0, 0, 0, 0, 0, 0, 0]

        self.activeChannels = [False, False, False, False, False, False, False, False]



    # Processes new Data and adjusts the controller
    def update(self, ThighAngle_Left, ThighAngle_Right):

        self.__ThighAngle_Left = ThighAngle_Left
        self.__ThighAngle_Right = ThighAngle_Right

        # Reset peak logs
        if self.log_l_pk_f or self.log_r_pk_f or self.log_l_pk_e or self.log_r_pk_e:
            self.log_l_pk_f = False
            self.log_r_pk_f = False
            self.log_l_pk_e = False
            self.log_r_pk_e = False



        ################
        ## LEFT SIDE  ##
        ################

        # Flexion or Extension detection
        Diff_Left = self.__ThighAngle_Left - self.__Last_Thigh_Angle_Left
        if np.abs(Diff_Left) >= self.min_range_of_motion:

            self.__Last_Thigh_Angle_Left = self.__ThighAngle_Left

            # Extension
            if np.sign(Diff_Left) == 1 and not self.__Direction_Left == 1:
                self.__Direction_Left = 1
                self.__Left_Peak_Extension = self.__Left_Peak_Extension_NEW
                if DEBUG: print ("New Peak Extension: " + str(self.__Left_Peak_Extension))
                self.__Left_Peak_Extension_NEW = -1000

            # Flexion
            elif np.sign(Diff_Left) == -1 and not self.__Direction_Left == -1:
                self.__Direction_Left = -1
                self.__Left_Peak_Flexion = self.__Left_Peak_Flexion_NEW
                if DEBUG: print ("New Peak Flexion: " + str(self.__Left_Peak_Flexion))
                self.__Left_Peak_Flexion_NEW = 1000




       # Determine Peak Flexion / Peak Extension

        # EXTENSION
        if self.__Direction_Left == 1:

            # Track new maximum
            if self.__Left_Peak_Extension_NEW < self.__ThighAngle_Left:
                self.__Left_Peak_Extension_NEW = self.__ThighAngle_Left

        elif self.__Direction_Left == -1:

            # Track new minimum
            if self.__Left_Peak_Flexion_NEW > self.__ThighAngle_Left:
                self.__Left_Peak_Flexion_NEW = self.__ThighAngle_Left


        # # FLEXION
        # if self.__Direction_Left == -1:
        #     if self.l_extended:  # FLEXION AFTER EXTENSION
        #         if (not self.__Left_Peak_Flexion) or (
        #                 abs(self.__Left_Peak_Flexion - self.__ThighAngle_Left) >= self.min_range_between_pke_and_pkf):
        #
        #             self.l_pk_e = True
        #             self.log_l_pk_e = True
        #
        #             if not self.__Left_Peak_Extension:  # first time
        #                 print(' L PEAK EXTENSION: ' + str(self.__ThighAngle_Left))
        #                 self.l_pk_e = False
        #             self.__Left_Peak_Extension = self.__ThighAngle_Left
        #         self.l_extended = False
        #     self.l_flexed = True
        #
        # # EXTENSION
        # elif self.__Direction_Left == 1:
        #     if self.l_flexed:  # EXTENSION AFTER FLEXION
        #         if (not self.__Left_Peak_Extension) or (
        #                 abs(self.__Left_Peak_Extension - self.__ThighAngle_Left) >= self.min_range_between_pke_and_pkf):
        #
        #             self.l_pk_f = True
        #             self.log_l_pk_f = True
        #
        #             if not self.__Left_Peak_Flexion:  # first time
        #                 print(' L PEAK FLEXION: ' + str(self.__ThighAngle_Left))
        #                 self.l_pk_f = False
        #             self.__Left_Peak_Flexion = self.__ThighAngle_Left
        #         self.l_flexed = False
        #     self.l_extended = True


        # Calculate normalized ThighAngle
        # Extension (0 - 50%)
        if self.__Direction_Left == 1:
            if self.__Left_Peak_Extension and self.__Left_Peak_Flexion:
                temp_norm_ThighAngle = (self.__ThighAngle_Left - self.__Left_Peak_Flexion) / (self.__Left_Peak_Extension - self.__Left_Peak_Flexion)

                if(temp_norm_ThighAngle<0.0):
                    temp_norm_ThighAngle = 0

                elif(temp_norm_ThighAngle >1.0):
                    temp_norm_ThighAngle = 1

                self.__Normalized_ThighAngle_Left = 50.0 * temp_norm_ThighAngle

            else:
                self.__Normalized_ThighAngle_Left = 0.0

        # Flexion (50 - 100%)
        elif self.__Direction_Left == -1:
            if self.__Left_Peak_Extension and self.__Left_Peak_Flexion:
                temp_norm_ThighAngle = (self.__Left_Peak_Extension - self.__ThighAngle_Left) / (self.__Left_Peak_Extension - self.__Left_Peak_Flexion)

                if (temp_norm_ThighAngle < 0.0):
                    temp_norm_ThighAngle = 0

                elif (temp_norm_ThighAngle > 1.0):
                    temp_norm_ThighAngle = 1

                self.__Normalized_ThighAngle_Left = 50 + (50.0 * temp_norm_ThighAngle)
            else:
                self.__Normalized_ThighAngle_Left = 50.0



        #################
        ## RIGHT SIDE  ##
        #################

        # Flexion or Extension detection
        diff_r = self.__ThighAngle_Right - self.last_r_t_angle
        if np.abs(diff_r) >= self.min_range_of_motion:
            if np.sign(diff_r) == 1:
                self.r_t_state = 1
            else:
                self.r_t_state = -1
            self.last_r_t_angle = self.__ThighAngle_Right

        # Determine Peak Flexion / Peak Extension
        if self.r_t_state == -1:  # FLEXION
            if self.r_extended:  # FLEXION AFTER EXTENSION
                if (not self.__Right_Peak_Flexion) or (abs(self.__Right_Peak_Flexion - self.__ThighAngle_Right) >= self.min_range_between_pke_and_pkf):

                    self.r_pk_e = True
                    self.log_r_pk_e = True

                    if not self.__Right_Peak_Extension:  # first time
                        print(' R PEAK EXTENSION: ' + str(self.__ThighAngle_Right))
                        self.r_pk_e = False
                    self.__Right_Peak_Extension = self.__ThighAngle_Right
                self.r_extended = False
            self.r_flexed = True
        elif self.r_t_state == 1:  # EXTENSION
            if self.r_flexed:  # EXTENSION AFTER FLEXION
                if (not self.__Right_Peak_Extension) or (abs(self.__Right_Peak_Extension - self.__ThighAngle_Right) >= self.min_range_between_pke_and_pkf):

                    self.r_pk_f = True
                    self.log_r_pk_f = True

                    if not self.__Right_Peak_Flexion:  # first time
                        print(' R PEAK FLEXION: ' + str(self.__ThighAngle_Right))
                        self.r_pk_f = False
                    self.__Right_Peak_Flexion = self.__ThighAngle_Right
                self.r_flexed = False
            self.r_extended = True


        # Calculate normalized ThighAngle
        # Extension (0 - 50%)
        if self.r_t_state == 1:
            if self.__Right_Peak_Extension and self.__Right_Peak_Flexion:
                temp_norm_ThighAngle = (self.__ThighAngle_Right - self.__Right_Peak_Flexion) / (
                        self.__Right_Peak_Extension - self.__Right_Peak_Flexion)

                if (temp_norm_ThighAngle < 0.0):
                    temp_norm_ThighAngle = 0

                elif (temp_norm_ThighAngle > 1.0):
                    temp_norm_ThighAngle = 1

                self.__Normalized_ThighAngle_Right = 50.0 * temp_norm_ThighAngle

            else:
                self.__Normalized_ThighAngle_Right = 0.0

        # Flexion (50 - 100%)
        elif self.r_t_state == -1:
            if self.__Right_Peak_Extension and self.__Right_Peak_Flexion:
                temp_norm_ThighAngle = (self.__Right_Peak_Extension - self.__ThighAngle_Right) / (
                        self.__Right_Peak_Extension - self.__Right_Peak_Flexion)

                if (temp_norm_ThighAngle < 0.0):
                    temp_norm_ThighAngle = 0

                elif (temp_norm_ThighAngle > 1.0):
                    temp_norm_ThighAngle = 1

                self.__Normalized_ThighAngle_Right = 50 + (50.0 * temp_norm_ThighAngle)

            else:
                self.__Normalized_ThighAngle_Right = 50.0






        # Process the new Data
        self.__process()


    # Updates the stimulation channels
    def __process(self):

        # LEFT side
        for ch in [0, 2, 4, 6]:# This is channels: 1, 3, 5, 7 on the stimulator

            start = self.Start[ch]
            stop = self.Stop[ch]
            result = False;

            if start == stop:
                result = False;

            elif start < stop:
                if start <= self.__Normalized_ThighAngle_Left and self.__Normalized_ThighAngle_Left <= stop:
                    result = True
                else:
                    result = False

            elif start > stop:
                if not (stop < self.__Normalized_ThighAngle_Left and self.__Normalized_ThighAngle_Left < start):
                    result = True
                else:
                    result = False

            self.activeChannels[ch] = result

        # RIGHT side
        for ch in [1, 3, 5, 7]: # This is channels: 2, 4, 6, 8 on the stimulator

            start = self.Start[ch]
            stop = self.Stop[ch]
            result = False;

            if start == stop:
                result = False;

            elif start < stop:
                if start <= self.__Normalized_ThighAngle_Right and self.__Normalized_ThighAngle_Right <= stop:
                    result = True
                else:
                    result = False

            elif start > stop:
                if not (stop < self.__Normalized_ThighAngle_Right and self.__Normalized_ThighAngle_Right < start):
                    result = True
                else:
                    result = False

            self.activeChannels[ch] = result




        # #############################################################################
        # # AROUND LAST PKF TRIG TO OTHER LIMB PKF
        # # Trig around last PKF to around last PKF of the other limb
        #
        # # Consider stimulating only if all necessary peaks have already been seen (One full turn was completed)
        # if (self.__Left_Peak_Flexion and self.__Right_Peak_Flexion and self.__Left_Peak_Extension and self.__Right_Peak_Extension):
        #
        #     # '''
        #     ## Stimulating before peak Flexion using preset Offset delays l_delay and r_delay
        #     # '''
        #     # LEFT : stim if : abs(Current_angle - angle_of_last_peak) < offset and stim_not_already_on
        #     if abs(self.__ThighAngle_Left - self.__Left_Peak_Flexion) <= self.l_delay and self.LQ == False:
        #
        #         # Stimulation left Quadriceps ON
        #         self.l_pk_f = False
        #         self.LQ = True
        #         self.RQ = False
        #
        #     # RIGHT : stim if : abs(Current_angle - angle_of_last_peak) < offset and stim_not_already_on
        #     if abs(self.__ThighAngle_Right - self.__Right_Peak_Flexion) <= self.r_delay and self.RQ == False:
        #
        #         # Stimulation left Quadriceps ON
        #         self.r_pk_f = False
        #         self.RQ = True
        #         self.LQ = False




    # Returns a Gonio_Controller_Data object containing the current state of the Controller
    def getData(self):

        self.data.LQ = self.LQ
        self.data.RQ = self.RQ
        self.data.LH = self.LH
        self.data.RH = self.RH

        self.data.L_peak_flexion = self.log_l_pk_f
        self.data.R_peak_flexion = self.log_r_pk_f

        self.data.L_peak_extension = self.log_l_pk_e
        self.data.R_peak_extension = self.log_r_pk_e

        self.data.NormalizedAngle_Left = self.__Normalized_ThighAngle_Left
        self.data.NormalizedAngle_Right = self.__Normalized_ThighAngle_Right

        self.data.activeChannels = self.activeChannels

        return self.data

    # Returns the active Channels
    def getActiveChannels(self):
        return self.activeChannels

    # Returns the current configuration
    def getConfig(self):
        data = {
            "Name": "CONTROLLER_THIGHANGLE",
            "Min": self.Min,
            "Max": self.Max,
            "Start": self.Start,
            "Stop": self.Stop
        }

        return data

    # Sets a new Configuration
    def setConfig(self, _config):

        self.Name = _config["Name"];
        self.Min = _config["Min"];
        self.Max = _config["Max"];
        self.Start = _config["Start"];
        self.Stop = _config["Stop"];