# -*- coding: utf-8 -*-
"""
The following Controller calculates the normalized ThighAngle based on a ThighAngle measurement
perfomed via IMU´s. The algorithm automatically detects peaks and adjusts itself to a given input.
Further the input-signal is filtered using an adaptive moving average filter. Most interruption occur at
lower cadences where higher filtering is applied. At higher cadences the signal is only minimally filtered
in order to keep the delay as short as possible. A change in smoothing factor is performed gradually to
avoid signal jumps.

All parameters are fully adjustable.

The normalized ThighAngle has following characteristics:

-1           ... ThighAngle not valid.
0 - 50 %     ... Extension phase of the leg
50 - 100 %   ... Flexion phase of the leg

@author: Martin Schmoll (CAMIN TEAM - INRIA)

"""

import numpy as np
import copy
from Controllers.Gonio_Controller_Data import Gonio_Controller_Data

DEBUG = True
LEFT = 0
RIGHT = 1

class Gonio_ThighAngle_Controller(object):

    def __init__(self):

        ## Input Parameters
        self.__ThighAngle_L = 0.0
        self.__ThighAngle_R = 0.0


        ## Settings
        self.IMU_DELAY = 35                             # [ms] Delay of intertial sensors
        self.MUSCLE_DELAY_ON = 200                      # [ms]
        self.MUSCLE_DELAY_OFF = 200                     # [ms]
        self.SAMPLE_PERIODE = 10                        # [ms] - expected time between 2 consecutive Datasamples

        self.CHANNELS_LEFT_SIDE = [0, 2, 4, 6]          # These are channels: 1, 3, 5, 7 on the stimulator
        self.CHANNELS_RIGHT_SIDE = [1, 3, 5, 7]         # These are channels: 2, 4, 6, 8 on the stimulator

        self.LineariseNormalisation = False

        self.Min = 0
        self.Max = 100

        self.Start = [0, 0, 0, 0, 0, 0, 0, 0]
        self.Stop = [0, 0, 0, 0, 0, 0, 0, 0]

        self.compensate4Delays = True
        self.__Start_compensated = [0, 0, 0, 0, 0, 0, 0, 0]
        self.__Stop_compensated = [0, 0, 0, 0, 0, 0, 0, 0]

        # Limits
        self.MIN_DIR_CHANGE = 1.0                 # Minimal difference effecting the direction change
        self.ROM_LIMIT = 15                       # Minimal Range of motion to allow for a valid signal interpretation in [deg]
        self.CADENCE_LIMIT_MIN = 1                # Minimal Cadence allowed in [RPM]
        self.CADENCE_LIMIT_MAX = 70               # Maximal Cadence allowed in [RPM]

        # Adaptive signal filtering (moving average)
        self.Activate_Adaptive_Smoothing = True
        self.Smoothing_Cadence_LOW = 20             # Lower Cadence limit for smoothing - a cadence below will get maximal smoothing
        self.Smoothing_Cadence_HIGH = 30            # Higher Cadence limit for smoothing - a cadence above will get minimal smoothing

        self.Smoothing_Factor_MAX = 35              # Maximal number of samples used for AVG smoothing
        self.Smoothing_Factor_MIN = 2               # Minimal number of samples used for AVG smoothing


        ## Processing Variables
        self.__TimeStamp = None

        self.__Last_TimeStamp_L = None
        self.__Last_TimeStamp_R = None

        self.__ThighAngle_List_L = []
        self.__ThighAngle_List_R = []

        self.__Smoothing_Factor_L = 1
        self.__Smoothing_Factor_R = 1

        self.__Last_Thigh_Angle_L = None
        self.__Last_Thigh_Angle_R = None

        self.__Direction_L = 1
        self.__Direction_R = 1

        self.__Direction_Changed_L = False
        self.__Direction_Changed_R = False

        # Current Peak Values
        self.__Peak_Flexion_L = None
        self.__Peak_Flexion_R = None

        self.__Peak_Extension_L = None
        self.__Peak_Extension_R = None


        # New Peak values
        self.__Peak_Flexion_NEW_L = 1000
        self.__Peak_Flexion_NEW_R = 1000

        self.__Peak_Extension_NEW_L = -1000
        self.__Peak_Extension_NEW_R = -1000



        ## Output Parameters
        self.__ThighAngle_Smoothed_L = -1
        self.__ThighAngle_Smoothed_R = -1

        self.__Cadence_L = -1
        self.__Cadence_R = -1

        self.__Normalized_ThighAngle_L =        -1.0  # Value between 0...100: -1 -> not valid
        self.__Normalized_ThighAngle_R =        -1.0  # Value between 0...100: -1 -> not valid

        self.data = Gonio_Controller_Data()

        self.activeChannels = [False, False, False, False, False, False, False, False]





    # Processes new Data and adjusts the controller
    def update(self, TimeStamp, ThighAngle_Left, ThighAngle_Right):

        self.__ThighAngle_L = ThighAngle_Left
        self.__ThighAngle_R = ThighAngle_Right

        self.__TimeStamp = TimeStamp

        self.calc_normalizedThighAngle(LEFT)
        self.calc_normalizedThighAngle(RIGHT)

        # Compensate for delays
        if self.compensate4Delays:
            self.__compensateDelays()

        # Process the new Data
        self.__process()


    # Calculates the normalised ThighAngle for a specified side
    def calc_normalizedThighAngle(self, side):

        # General values
        TimeStamp = self.__TimeStamp
        MIN_DIR_CHANGE = self.MIN_DIR_CHANGE
        ROM_Limit = self.ROM_LIMIT
        Cadence_Limit_LOWER = self.CADENCE_LIMIT_MIN
        Cadence_Limit_UPPER = self.CADENCE_LIMIT_MAX

        # Side specific values
        if side == LEFT:
            Last_TimeStamp = self.__Last_TimeStamp_L

            ThighAngle = self.__ThighAngle_L
            Last_Thigh_Angle = self.__Last_Thigh_Angle_L
            ThighAngle_List = self.__ThighAngle_List_L
            Normalized_ThighAngle = self.__Normalized_ThighAngle_L

            Cadence = self.__Cadence_L

            Direction = self.__Direction_L
            Direction_Changed = self.__Direction_Changed_L

            Smoothing_Factor = self.__Smoothing_Factor_L

            Peak_Extension = self.__Peak_Extension_L
            Peak_Flexion = self.__Peak_Flexion_L

            Peak_Extension_NEW = self.__Peak_Extension_NEW_L
            Peak_Flexion_NEW = self.__Peak_Flexion_NEW_L

        else:
            Last_TimeStamp = self.__Last_TimeStamp_R

            ThighAngle = self.__ThighAngle_R
            Last_Thigh_Angle = self.__Last_Thigh_Angle_R
            ThighAngle_List = self.__ThighAngle_List_R
            Normalized_ThighAngle = self.__Normalized_ThighAngle_R

            Cadence = self.__Cadence_R

            Direction = self.__Direction_R
            Direction_Changed = self.__Direction_Changed_R

            Smoothing_Factor = self.__Smoothing_Factor_R

            Peak_Extension = self.__Peak_Extension_R
            Peak_Flexion = self.__Peak_Flexion_R

            Peak_Extension_NEW = self.__Peak_Extension_NEW_R
            Peak_Flexion_NEW = self.__Peak_Flexion_NEW_R




        # Smooth ThighAngle - Adaptive smooting based on Cadence
        ThighAngle_List.append(ThighAngle)

        n = len(ThighAngle_List)

        if (n > Smoothing_Factor):
            ThighAngle_List = ThighAngle_List[n - Smoothing_Factor:n]

        ThighAngle_Smoothed = sum(ThighAngle_List) / len(ThighAngle_List)


        # Init Check
        if Last_Thigh_Angle is None:
            Last_Thigh_Angle = ThighAngle_Smoothed
            Peak_Extension = ThighAngle_Smoothed
            Peak_Flexion = ThighAngle_Smoothed


        # Flexion or Extension detection
        Diff = ThighAngle_Smoothed - Last_Thigh_Angle
        if np.abs(Diff) >= MIN_DIR_CHANGE:

            Last_Thigh_Angle = ThighAngle_Smoothed

            # Transition from Flexion to Extension
            if np.sign(Diff) == 1 and Direction == -1:
                Direction = 1
                Direction_Changed = 1
                Peak_Flexion = Peak_Flexion_NEW
                Peak_Flexion_NEW = 1000

                # Calculate Cadence
                if Last_TimeStamp is None:
                    Last_TimeStamp = TimeStamp
                    Cadence = -1
                else:
                    diff = TimeStamp - Last_TimeStamp
                    Last_TimeStamp = TimeStamp
                    Cadence = (0.5 / diff) * 60.0

            # Transition from Extension to Flexion
            elif np.sign(Diff) == -1 and Direction == 1:
                Direction = -1
                Direction_Changed = 1
                Peak_Extension = Peak_Extension_NEW
                Peak_Extension_NEW = -1000

                # Calculate Cadence
                if Last_TimeStamp is None:
                    Last_TimeStamp = TimeStamp
                    Cadence = -1
                else:
                    diff = TimeStamp - Last_TimeStamp
                    Last_TimeStamp = TimeStamp
                    Cadence = (0.5 / diff) * 60.0


        # Check for decreasing Cadence
        if Cadence > 0:
            diff = TimeStamp - Last_TimeStamp
            expected_diff = 30.0 / Cadence

            if diff > expected_diff:
                Cadence = (0.5 / diff) * 60


        # Calculate new smoothing factor based on cadence
        temp_SmoothingFactor = self.calcSmoothingFactor(Cadence)

        if temp_SmoothingFactor < Smoothing_Factor:
            Smoothing_Factor = Smoothing_Factor - 1
        elif temp_SmoothingFactor > Smoothing_Factor:
            Smoothing_Factor = Smoothing_Factor + 1


        # Trace new Peak Flexion / Peak Extension
        # EXTENSION
        if Direction == 1:

            # Track new maximum
            if ThighAngle_Smoothed > Peak_Extension_NEW:
                Peak_Extension_NEW = ThighAngle_Smoothed

        # FLEXION
        elif Direction == -1:

            # Track new minimum
            if ThighAngle_Smoothed < Peak_Flexion_NEW:
                Peak_Flexion_NEW = ThighAngle_Smoothed



        # Calculate normalized ThighAngle
        ROM = Peak_Extension - Peak_Flexion     # Range of Motion

        if ROM > 0:

            # Extension(0 - 50 %)
            if Direction == 1:

                # Calculate
                temp_norm_ThighAngle = (ThighAngle_Smoothed - Peak_Flexion) / ROM

                # Boundary Check
                temp_norm_ThighAngle = self.checkBoundaries(temp_norm_ThighAngle, 0.0, 1.0)

                # Linearisation of normalised signal
                if self.LineariseNormalisation:
                    temp_norm_ThighAngle = 2 * temp_norm_ThighAngle - 1
                    temp_norm_ThighAngle = np.arcsin(temp_norm_ThighAngle) + np.pi / 2
                    temp_norm_ThighAngle = temp_norm_ThighAngle / np.pi


                # Scale
                temp_norm_ThighAngle = 50.0 * temp_norm_ThighAngle

                # Only allow a rising values, unless the direction recently changed
                if temp_norm_ThighAngle > Normalized_ThighAngle or Direction_Changed == 1:
                    Normalized_ThighAngle = temp_norm_ThighAngle

            # Flexion(50 - 100 %)
            elif Direction == -1:

                # Calculate
                temp_norm_ThighAngle = (Peak_Extension - ThighAngle_Smoothed) / ROM

                # Boundary Check
                temp_norm_ThighAngle = self.checkBoundaries(temp_norm_ThighAngle, 0.0, 1.0)

                # Linearisation of normalised signal
                if self.LineariseNormalisation:
                    temp_norm_ThighAngle = 2 * temp_norm_ThighAngle - 1
                    temp_norm_ThighAngle = np.arcsin(temp_norm_ThighAngle) + np.pi / 2
                    temp_norm_ThighAngle = temp_norm_ThighAngle / np.pi

                # Scale
                temp_norm_ThighAngle = 50 + (50.0 * temp_norm_ThighAngle)

                # Only allow a rising values, unless the direction recently changed
                if temp_norm_ThighAngle > Normalized_ThighAngle or Direction_Changed == 1:
                    Normalized_ThighAngle = temp_norm_ThighAngle


        # Reset action of the direction change
        if Direction_Changed == 1:
            Direction_Changed = 0


        # Saftefy checkups
        if  ROM < ROM_Limit or \
            Cadence < Cadence_Limit_LOWER or \
            Cadence > Cadence_Limit_UPPER:

            Normalized_ThighAngle = -1


        # Write back values:
        if side == LEFT:
            self.__Last_TimeStamp_L = Last_TimeStamp

            self.__ThighAngle_L = ThighAngle
            self.__Last_Thigh_Angle_L = Last_Thigh_Angle
            self.__ThighAngle_List_L = ThighAngle_List
            self.__ThighAngle_Smoothed_L = ThighAngle_Smoothed
            self.__Normalized_ThighAngle_L = Normalized_ThighAngle

            self.__Cadence_L = Cadence

            self.__Direction_L = Direction
            self.__Direction_Changed_L = Direction_Changed

            self.__Smoothing_Factor_L = Smoothing_Factor

            self.__Peak_Extension_L = Peak_Extension
            self.__Peak_Flexion_L= Peak_Flexion

            self.__Peak_Extension_NEW_L = Peak_Extension_NEW
            self.__Peak_Flexion_NEW_L = Peak_Flexion_NEW

        else:
            self.__Last_TimeStamp_R = Last_TimeStamp

            self.__ThighAngle_R = ThighAngle
            self.__Last_Thigh_Angle_R = Last_Thigh_Angle
            self.__ThighAngle_List_R = ThighAngle_List
            self.__ThighAngle_Smoothed_R = ThighAngle_Smoothed
            self.__Normalized_ThighAngle_R = Normalized_ThighAngle

            self.__Cadence_R = Cadence

            self.__Direction_R = Direction
            self.__Direction_Changed_R = Direction_Changed

            self.__Smoothing_Factor_R = Smoothing_Factor

            self.__Peak_Extension_R = Peak_Extension
            self.__Peak_Flexion_R = Peak_Flexion

            self.__Peak_Extension_NEW_R = Peak_Extension_NEW
            self.__Peak_Flexion_NEW_R = Peak_Flexion_NEW





    # Checks Boundaries and corrects value if outside
    def checkBoundaries(self, VALUE, MIN, MAX):

        if VALUE < MIN:
            VALUE = MIN
        elif VALUE > MAX:
            VALUE = MAX

        return VALUE

    # Checks boundaries and adjusts value accordingly
    def calcSmoothingFactor(self, Cadence):

        # This is for temporary deactivation of the adaptive Smoothing
        if not self.Activate_Adaptive_Smoothing:
            return 1

        smoothingFactor = self.Smoothing_Factor_MIN

        if Cadence <= self.Smoothing_Cadence_LOW:
            smoothingFactor = self.Smoothing_Factor_MAX
        elif Cadence >= self.Smoothing_Cadence_HIGH:
            smoothingFactor = self.Smoothing_Factor_MIN

        else:
            norm_Cadence = ((Cadence - self.Smoothing_Cadence_LOW) / (self.Smoothing_Cadence_HIGH - self.Smoothing_Cadence_LOW))

            smoothingFactor = round((norm_Cadence * (self.Smoothing_Factor_MIN - self.Smoothing_Factor_MAX)) + self.Smoothing_Factor_MAX)

        return smoothingFactor


    # Calculates compensated Start and Stop times for each channel in order to compensate for
    # Muscle Delay and Smoothing Delay
    def __compensateDelays(self):

        # Determine calculation method
        method = 'sinus'
        if self.LineariseNormalisation:
            method = 'linear'

        # Make deep-copy to avoid overwritting of referenced values
        t_Start = copy.deepcopy(self.Start)
        t_Stop = copy.deepcopy(self.Stop)

        ## Calculate Smoothing Delays

        periode_L = (60/self.__Cadence_L)* 1000     # Duration of a full turn in [ms]
        periode_R = (60 / self.__Cadence_R) * 1000  # Duration of a full turn in [ms]

        smoothing_delay_L = 0

        if self.__Smoothing_Factor_L > 1:
            smoothing_delay_L = round(self.__Smoothing_Factor_L / 2.0) * self.SAMPLE_PERIODE

        smoothing_delay_R = 0

        if self.__Smoothing_Factor_R > 1:
            smoothing_delay_R = round(self.__Smoothing_Factor_R / 2.0) * self.SAMPLE_PERIODE

        ## LEFT SIDE
        # Overall delay
        delay_L = self.MUSCLE_DELAY_ON + smoothing_delay_L + self.IMU_DELAY

        # Compensate each channel of left side
        for ch in self.CHANNELS_LEFT_SIDE:

            # Only compensate if channel is active... i.e. Start and Stop are different
            # Only allow a shift which is half the periode time - a higher shift might be strange...
            if self.Start[ch] != self.Stop[ch] and delay_L <= (periode_L / 2):

                # Compensate StartValues by smoothing-delay and muscle-delay
                self.__Start_compensated[ch] = self.__calcShiftedValue(t_Start[ch], periode_L, delay_L, method)

                # Compensate StopValues only by smoothing-delay
                self.__Stop_compensated[ch] = self.__calcShiftedValue(t_Stop[ch], periode_L, (smoothing_delay_L + self.IMU_DELAY), method)

            else:
                self.__Start_compensated[ch] = t_Start[ch]
                self.__Stop_compensated[ch] = t_Stop[ch]

        ## RIGHT SIDE
        # Overall delay
        delay_R = self.MUSCLE_DELAY_ON + smoothing_delay_R + self.IMU_DELAY

        # Compensate each channel of left side
        for ch in self.CHANNELS_RIGHT_SIDE:

            # Only compensate if channel is active... i.e. Start and Stop are different
            # Only allow a shift which is half the periode time - a higher shift might be strange...
            if self.Start[ch] != self.Stop[ch] and delay_R <= (periode_R / 2):

                # Compensate StartValues by smoothing-delay and muscle-delay
                self.__Start_compensated[ch] = self.__calcShiftedValue(t_Start[ch], periode_R, delay_R, method)

                # Compensate StopValues only by smoothing-delay
                self.__Stop_compensated[ch] = self.__calcShiftedValue(t_Stop[ch], periode_R, (smoothing_delay_R + self.IMU_DELAY), method)

            else:
                self.__Start_compensated[ch] = t_Start[ch]
                self.__Stop_compensated[ch] = t_Stop[ch]


    # Returns the shifted value based on a the used calculation method
    # If the algorithm is working linearized use: method = 'linear"
    # If the algorithm is only normalizing use: method = 'sinus'
    def __calcShiftedValue(self, value_unshifted, periode_ms, shift_ms, method):

        value_shifted = 0

        # Normalized Values are also linearized
        if method == 'linear':
            shift =  round((shift_ms / periode_ms) * 100.0)

            value_shifted = value_unshifted - shift

            # Shift into previous cycle
            if value_shifted < 0:
                value_shifted = 100 + value_shifted

        # Normalized values follow the shape of a sinus
        elif method == 'sinus':

            # The shape of the signal is thesame from 0 - 50 as 50 - 100, thus modulo
            if value_unshifted == 0 or value_unshifted == 50:
                value = value_unshifted

            elif value_unshifted == 100:
                value = 50

            else:
                value = value_unshifted % 50 # Modulo


            # Scaling the value from 0..50 to - 1.. + 1
            # value = value / 50   -> normalizing
            # value = value * 2    -> scaling
            # value = value - 1    -> shifting
            value = (value / 25.0) - 1.0

            # Linearize value: Range - pi / 2... + pi / 2
            value = np.arcsin(value)

            # Delay needs to be calculated in [rad]
            delay_rad = (shift_ms / periode_ms) * 2 * np.pi

            # If value is below - pi / 2, we jump into the previous cycle
            if (value - delay_rad) < (-np.pi / 2):

                ## Find the shifted value
                # diff = value + pi / 2 -> required shift into the previous cycle
                # value_shifted = pi / 2 - (delay_rad - diff)   -> value in the previous cycle
                value_shifted = value - delay_rad + np.pi

                # Converting from [rad] into amplitude range
                value_shifted = np.sin(value_shifted)

                # Indicate that there has been a jump into the previous cycle
                cycle_jump = 1

            # Shift remains in the same cycle
            else:
                value_shifted = np.sin(value - delay_rad)
                cycle_jump = 0

            # Scaling into value range of 0..50
            value_shifted = round(50 * ((value_shifted + 1) / 2))

            # Shifted value is found in the previous cycle
            if value_unshifted < 50 and cycle_jump == 1:
                value_shifted = 50 + value_shifted

            # Shifted value remains in the same cycle
            elif value_unshifted > 50 and cycle_jump == 0:
                value_shifted = 50 + value_shifted

        # Return value
        return value_shifted


    # Updates the stimulation channels
    def __process(self):

        # LEFT side
        for ch in self.CHANNELS_LEFT_SIDE:

            start = self.Start[ch]
            stop = self.Stop[ch]

            if self.compensate4Delays:
                start = self.__Start_compensated[ch]
                stop = self.__Stop_compensated[ch]

            result = False 

            if start == stop or self.__Normalized_ThighAngle_L < 0:
                result = False 

            elif start < stop:
                if start <= self.__Normalized_ThighAngle_L and self.__Normalized_ThighAngle_L <= stop:
                    result = True
                else:
                    result = False

            elif start > stop:
                if not (stop < self.__Normalized_ThighAngle_L and self.__Normalized_ThighAngle_L < start):
                    result = True
                else:
                    result = False

            self.activeChannels[ch] = result



        # RIGHT side
        for ch in self.CHANNELS_RIGHT_SIDE:

            start = self.Start[ch]
            stop = self.Stop[ch]

            if self.compensate4Delays:
                start = self.__Start_compensated[ch]
                stop = self.__Stop_compensated[ch]

            result = False 

            if start == stop or self.__Normalized_ThighAngle_R < 0:
                result = False 

            elif start < stop:
                if start <= self.__Normalized_ThighAngle_R and self.__Normalized_ThighAngle_R <= stop:
                    result = True
                else:
                    result = False

            elif start > stop:
                if not (stop < self.__Normalized_ThighAngle_R and self.__Normalized_ThighAngle_R < start):
                    result = True
                else:
                    result = False

            self.activeChannels[ch] = result




    # Returns a Gonio_Controller_Data object containing the current state of the Controller
    def getData(self):

        self.data.NormalizedAngle_Left = self.__Normalized_ThighAngle_L
        self.data.NormalizedAngle_Right = self.__Normalized_ThighAngle_R

        self.data.Cadence_L = self.__Cadence_L
        self.data.Cadence_R = self.__Cadence_R

        self.data.activeChannels = self.activeChannels

        return self.data

    # Returns the active Channels
    def getActiveChannels(self):
        return self.activeChannels


    # Sets a new Configuration
    def setConfig(self, _config):

        # Standard Settings
        self.Name   = _config["Name"]
        self.Min    = _config["Min"]
        self.Max    = _config["Max"]
        self.Start  = _config["Start"]
        self.Stop   = _config["Stop"]


    # Returns the current configuration
    def getConfig(self):
        data = {
            "Name": "CONTROLLER_THIGHANGLE",
            "Min": self.Min,
            "Max": self.Max,
            "Start": self.Start,
            "Stop": self.Stop
        }

        return data


    # Sets a new Configuration
    def setAdvancedConfig(self, _config):

        # Standard Settings
        self.Name   = _config["Name"]
        self.Min    = _config["Min"]
        self.Max    = _config["Max"]
        self.Start  = _config["Start"]
        self.Stop   = _config["Stop"]

        # Advanced Settings
        self.Smoothing_Cadence_LOW  = _config["Smoothing_Cadence_LOW"]
        self.Smoothing_Cadence_HIGH = _config["Smoothing_Cadence_HIGH"]
        self.Smoothing_Factor_MIN   = _config["Smoothing_MIN"]
        self.Smoothing_Factor_MAX   = _config["Smoothing_MAX"]
        self.LineariseNormalisation = _config["LinearizeNormalisation"]
        self.ROM_LIMIT              = _config["Min_RangeOfMotion"]
        self.MIN_DIR_CHANGE         = _config["Min_DirectionChange"]


    # Returns the current configuration
    def getAdvancedConfig(self):
        data = {
            "@@@@@@@@@@@@Name": "CONTROLLER_THIGHANGLE",
            "@@@@@@@@@@@Min": self.Min,
            "@@@@@@@@@@Max": self.Max,
            "@@@@@@@@@Start": self.Start,
            "@@@@@@@@Stop": self.Stop,

            "@@@@@@@Smoothing_Cadence_LOW": self.Smoothing_Cadence_LOW,
            "@@@@@@Smoothing_Cadence_HIGH": self.Smoothing_Cadence_HIGH,
            "@@@@@Smoothing_MIN": self.Smoothing_Factor_MIN,
            "@@@@Smoothing_MAX": self.Smoothing_Factor_MAX,
            "@@@LinearizeNormalisation": self.LineariseNormalisation,
            "@@Min_RangeOfMotion": self.ROM_LIMIT,
            "@Min_DirectionChange": self.MIN_DIR_CHANGE
        }

        return data