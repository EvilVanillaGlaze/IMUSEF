import time
import random
import threading
from IMUSEF_Data import  IMUSEF_Data
from Controllers.PID_Controller_Data import PID_Controller_Data
from Controllers.CrankAngle_Controller import CrankAngle_Controller


class PID_Input(object):

    def __init__(self):

        self.RTCadence = 0
        self.RTCadenceSmooth = 0
        self.sum_CrankAngle = 0
        self.Min = 0
        self.Max = 360
        self.__CrankAngle = 0
        self.LastCadences = [0] * 10
        self.c = 0
        self.data = PID_Controller_Data()
        self.previous = 0

    def setConfig (self):
        config = CrankAngle_Controller.getConfig()
        self.Min = config["Min"],
        self.Max = config["Max"]

    def update(self,CrankAngle):

        # Check Boundaries
        if CrankAngle < self.Min:
            CrankAngle = self.Min

        if CrankAngle > self.Max:
            CrankAngle = self.Max

        now = time.time()
        delta_CrankAngle = CrankAngle - self.__CrankAngle
        if delta_CrankAngle <= -100:
            self.sum_CrankAngle = self.sum_CrankAngle + delta_CrankAngle + 360
        else:
            self.sum_CrankAngle = self.sum_CrankAngle + delta_CrankAngle
        if self.sum_CrankAngle > 45:
            self.RTCadence = (self.sum_CrankAngle / 360) / ((now - self.previous) / 60)
            self.sum_CrankAngle = 0
            self.previous = now

        # d = delta_CrankAngle
        # if d != 0:
        #     if d <= -100:
        #         d = d + 360
        #
        #     self.RTCadence = (d/360)/((now - self.previous)/60)
        #     self.previous = now

        if self.RTCadence > 0:
            rtdiff = now - self.previous
            rtexpected_diff = 7.5 / self.RTCadence

            if rtdiff > (rtexpected_diff+0.05):
                self.RTCadence = 7.5 / (rtdiff-0.05)

        #if self.RTCadence < self.Min:
        if self.RTCadence < 5:
            self.RTCadence = 0
            #self.rt = 0

        self.LastCadences[self.c] = self.RTCadence
        self.RTCadenceSmooth = sum(self.LastCadences) / len(self.LastCadences)
        self.c = self.c + 1
        if self.c >= len(self.LastCadences):
            self.c = 0

        # Update CrankAngle
        self.__CrankAngle = CrankAngle

        # Returns a PID_Controller_Data object containing the current state of the Controller
    def getData(self):

        self.data.RTCadence = self.RTCadence
        self.data.RTCadenceSmooth = self.RTCadenceSmooth

        return self.data



