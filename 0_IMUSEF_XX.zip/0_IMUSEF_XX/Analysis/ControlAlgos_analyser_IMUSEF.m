function ControlAlgos_analyser_IMUSEF()
close all
clear all
clc

True = 1;
False = 0;


IMUSEF_path = fileparts(mfilename('fullpath'))
IMUSEF_path = IMUSEF_path(1:end-9)

[file,path] = uigetfile(strcat(IMUSEF_path,'\Data\References\*.txt'));

if strcmp(num2str(file),'0') || strcmp(num2str(path),'0')
    disp('Error: Given file is invalid')
    return
end
File_path = strcat(path,file);
disp(file)
if exist(File_path, 'file') == 2
     % File exists. %%Explicit Format example : 'Format','%s%s%u%f%f%s'
     % Expliciting formating : Floats, then 4 booleans, then 5 floats again
     % for the phases, 5 active channels strings of 8 chars, and finally an
     % optional comment.
     NEW_DATA_FILE_FORMAT = True;

     if NEW_DATA_FILE_FORMAT == True
         file_format = [repmat('%f', 1, 19), repmat('%d', 1, 4), repmat('%f', 1, 5), repmat('%08s', 1, 5), '%s'];

         regen_data = readtable(File_path,'Delimiter','\t',...
             'ReadVariableNames',true,'ReadRowNames',false,'HeaderLines',0,'Format',file_format,'FileEncoding','US-ASCII');
     else
         regen_data = readtable(File_path,'Delimiter','\t',...
             'ReadVariableNames',true,'ReadRowNames',false,'HeaderLines',0,'FileEncoding','US-ASCII');
     end
else
     % File does not exist.
     disp('DATA FILE NOT FOUND'); disp(File_path); return
end



% Test figure at the beginning to check stuff if desired
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
test_figure = figure('Name','Test figure to look at some specific data','Numbertitle', 'off');
plot(regen_data{:,1},regen_data{:,5},'LineWidth',1,'DisplayName','Right Thigh Angle');
xlabel('Time (sec)') 
ylabel('Right Thigh Angle (deg)')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Formating data correctly
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finding first on zero angle value detecting a start
% start_index = find(regen_data{:,5} ~= 0,1);
% start_index = find(regen_data{:,1} >= regen_data{1,1}+17.0,1);
% regen_data{:,:}=regen_data{start_index:end,:};
% regen_data(1:start_index-1,:) = [];

%%Setting the TIMESTAMP OFFSET for start at 0sec
% regen_data{:,1} = regen_data{:,1} - regen_data{1,1};
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% end_index = find(regen_data{:,1} > 53,1)%%FOR FILE 31
% end_index = find(regen_data{:,1} > 53,1)
% regen_data(end_index:end,:) = [];

% Expliciting vector of values
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
timestamp = regen_data{:,1};
%%Setting the TIMESTAMP OFFSET for start at 0sec
timestamp = timestamp - timestamp(1);
crank_angle = regen_data{:,3};
crank_angle_norm = regen_data{:,3}/3.600;% crank_angle = regen_data{:,6};
left_thigh_angle = regen_data{:,4};
right_thigh_angle = regen_data{:,5};

 if NEW_DATA_FILE_FORMAT == True
    phase_gonio_norm_left = regen_data{:,24};
    phase_gonio_norm_right = regen_data{:,25};
    phase_observer = regen_data{:,28};
 else
    phase_gonio_norm_left = regen_data{:,21};
    phase_gonio_norm_right = regen_data{:,22};
    phase_observer = regen_data{:,25};
 end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Creating the desired phase Baseline
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[~,Baseline_pk] = findpeaks(right_thigh_angle,'MinPeakProminence',10,'MinPeakDistance',15);
[~,Baseline_neg_pk] = findpeaks(-right_thigh_angle,'MinPeakProminence',10,'MinPeakDistance',15);

while Baseline_neg_pk(1)<Baseline_pk(1)
    Baseline_neg_pk(1)=[];
end

start_peak_index = Baseline_pk(1);
end_peak_index = Baseline_pk(end);



% New BASELINE PHASE based on half cycles normalized angle
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Adding zeros before first peak
normalized_angle_phase_Baseline = zeros(start_peak_index-1,1);
% normalized_angle_phase_Baseline = [];
for cycle = 1:size(Baseline_pk,1)-1
    %Timestamp of the first point of the cycle 
%     t0 = timestamp(Baseline_pk(cycle));
    y0 = 0;
    angle0 = right_thigh_angle(Baseline_pk(cycle));
    
    %Timestamp of the middle point of the cycle 
%     t50 = timestamp(Baseline_neg_pk(cycle));
    y50 = 50;
    angle50=right_thigh_angle(Baseline_neg_pk(cycle));
    
    %Timestamp of the last point of the cycle 
%     t100 = timestamp(Baseline_pk(cycle+1)-1);
    y100 = 100;
    angle100 = right_thigh_angle(Baseline_pk(cycle+1));
    
    first_half_cycle = ((right_thigh_angle(Baseline_pk(cycle):Baseline_neg_pk(cycle)-1)-angle0)*(y50-y0)/(angle50-angle0))+y0;
    second_half_cycle = ((right_thigh_angle(Baseline_neg_pk(cycle):Baseline_pk(cycle+1)-1)-angle50)*(y100-y50)/(angle100-angle50))+y50;
    normalized_angle_phase_Baseline = [normalized_angle_phase_Baseline;[first_half_cycle;second_half_cycle]];
end
%Adding one zero to finish the last peak, and finishing data vector with
%zeros to fill up unprocessed samples after the last peak
normalized_angle_phase_Baseline = [normalized_angle_phase_Baseline; zeros(1 + length(timestamp)-end_peak_index,1)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% Time variable TWO SLOPES BASELINE based on Line formula 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Adding zeros before first peak
exp_phase_Baseline = zeros(start_peak_index-1,1);
% exp_phase_Baseline = [];
% exp_time_Baseline = [];
for cycle = 1:size(Baseline_pk,1)-1
    %Timestamp of the first point of the cycle 
    t0 = timestamp(Baseline_pk(cycle));
    y0 = 0;
    
    %Timestamp of the middle point of the cycle 
    t50 = timestamp(Baseline_neg_pk(cycle));
    y50 = 50;
    
    %Timestamp of the last point of the cycle 
    t100 = timestamp(Baseline_pk(cycle+1));
    y100 = 100;
    
    %Slope coefficient and intercept for the first half cycle
    k1 = (y50 - y0)/(t50 - t0);
    b1 = y0; % y0-k1*t0;
    
    %Slope coefficient and intercept for the second half cycle
    k2 = (y100 - y50)/(t100 - t50);
    b2 = y50; % y50-k2*t50;
    
    %Getting the timestamps of the samples from the first half of the cycle
    timestamps1 = timestamp(Baseline_pk(cycle):Baseline_neg_pk(cycle)-1);
    %Process the samples phase results through the line formula
    first_half_cycle = k1*(timestamps1-t0) + b1;
    
    %Getting the timestamps of the samples from the second half of the cycle
    timestamps2 = timestamp(Baseline_neg_pk(cycle):Baseline_pk(cycle+1)-1);
    %Process the samples phase results through the line formula
    second_half_cycle = k2*(timestamps2-t50) + b2;
    
    %Add processed cycle to the complete vector
    exp_phase_Baseline = [exp_phase_Baseline;[first_half_cycle;second_half_cycle]];
%     exp_time_Baseline = [exp_time_Baseline;[timestamps1;timestamps2]];
end
%Adding one zero to finish the last peak, and finishing data vector with
%zeros to fill up unprocessed samples after the last peak
exp_phase_Baseline = [exp_phase_Baseline; zeros(1 + length(timestamp)-end_peak_index,1)];

%     plot(exp_time_Baseline, exp_phase_Baseline, '-b');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% Basic linspace Time invariable ONE SLOPE BASELINE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Adding zeros before first peak
phase_Baseline = zeros(start_peak_index-1,1);
% phase_Baseline = [];
for i = 1:size(Baseline_pk,1)-1
    % Proccessing samples up to each cycle end peak but don't count the peak
    cycle = linspace(0,100,(Baseline_pk(i+1)-Baseline_pk(i))+1);
    phase_Baseline = [phase_Baseline; cycle(1:end-1)'];
end
%Adding one zero to finish the last peak, and finishing data vector with
%zeros to fill up unprocessed samples after the last peak
phase_Baseline = [phase_Baseline; zeros(1 + length(timestamp)-end_peak_index,1)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Preview figure with Baseline phase and right thigh angle
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%normalized_angle_phase_Baseline

preview_fig = figure('Name','Right Thigh angle against Baseline Phase','Numbertitle', 'off');

subfig1 = subplot(4, 1, 1,'Parent', preview_fig);
% subfig1 = subplot(3, 1, [1 2],'Parent', preview_fig);
plot(timestamp,normalized_angle_phase_Baseline,'LineWidth',1,'DisplayName','Norm Angle Baseline phase');
xlim([-1, timestamp(end)+1]);
ylim([-1,101])
xlabel('Time (sec)') 
ylabel('Baseline Phase (%) of the cycle') 
legend(gca,'show');

subfig2 = subplot(4, 1, 2,'Parent', preview_fig);
% plot(exp_time_Baseline,exp_phase_Baseline,'LineWidth',1,'DisplayName','Experimental Baseline phase');
plot(timestamp,exp_phase_Baseline,'LineWidth',1,'DisplayName','Exp Baseline phase');
xlim([-1, timestamp(end)+1]);
ylim([-1,101])
xlabel('Time (sec)') 
ylabel('Phase (%) of the cycle') 
legend(gca,'show');

subfig3 = subplot(4, 1, 3,'Parent', preview_fig);
plot(timestamp,phase_Baseline,'LineWidth',1,'DisplayName','Baseline phase');
xlim([-1, timestamp(end)+1]);
ylim([-1,101])
xlabel('Time (sec)') 
ylabel('Phase (%) of the cycle') 
legend(gca,'show');


subfig4 = subplot(4, 1, 4,'Parent', preview_fig);
plot(timestamp,right_thigh_angle,'LineWidth',1,'DisplayName','Right Thigh Angle');
xlabel('Time (sec)') 
ylabel('Right Thigh Angle (deg)') 
xlim([-1, timestamp(end)+1]);
ylim([-65,0])

legend(gca,'show');
linkaxes([subfig1,subfig2,subfig3,subfig4],'x');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
phase_Baseline = exp_phase_Baseline;
% phase_Baseline = normalized_angle_phase_Baseline;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% PHASE HILBERT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Adding zeros before first peak
phase_Hilbert = zeros(start_peak_index-1,1);
fs = length(right_thigh_angle(start_peak_index:end_peak_index));
fx = detrend(-right_thigh_angle(start_peak_index:end_peak_index),'constant');
z = hilbert(fx);

amplitude_Hilbert = abs(z);
tmp_phase_Hilbert = angle(z) / pi;
freq_Hilbert = diff(tmp_phase_Hilbert)/(2*pi)*fs;
tmp_phase_Hilbert = tmp_phase_Hilbert*50 + 50;

phase_Hilbert = [phase_Hilbert; tmp_phase_Hilbert];

%Adding one zero to finish the last peak, and finishing data vector with
%zeros to fill up unprocessed samples after the last peak
phase_Hilbert = [phase_Hilbert; zeros(length(timestamp)-end_peak_index,1)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






% Detail figure with desired phases for comparisons and understanding
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
detail_fig = figure('Name','Obs and MS_Gonio phases against Baseline Phase','Numbertitle', 'off');

subfig1 = subplot(3, 1, 1,'Parent', detail_fig);
plot(timestamp,phase_Hilbert,'LineWidth',1,'DisplayName','Hilbert phase');
xlim([-1, timestamp(end)+1]);
ylim([-1,101])
xlabel('Time (sec)') 
ylabel('Hilbert Phase(%)') 
legend(gca,'show');

subfig2 = subplot(3, 1, 2,'Parent', detail_fig);
plot(timestamp,phase_Baseline,'LineWidth',1,'DisplayName','Baseline phase');
xlim([-1, timestamp(end)+1]);
ylim([-1,101])
xlabel('Time (sec)') 
ylabel('Baseline Phase(%)') 
legend(gca,'show');

subfig3 = subplot(3, 1, 3,'Parent', detail_fig);
plot(timestamp,phase_gonio_norm_left,'LineWidth',1,'DisplayName','MS Gonio Phase');
xlim([-1, timestamp(end)+1]);
xlabel('Time (sec)') 
ylabel('MSGonio Phase(%)') 
xlim([-1, timestamp(end)+1]);
ylim([-1,101])

legend(gca,'show');
linkaxes([subfig1,subfig2,subfig3],'x');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





% Event extraction in the various input signals
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% event_list = [10,20,30,40,50,60,70,80,90,100];
event_list = [10,40,60,90];
% event_list = [25];
num_events = length(event_list);
Baseline_events = get_events_from_cyclic_phase(phase_Baseline(start_peak_index:end_peak_index), event_list);
Baseline_events{1,:} = [];
Baseline_events{end,:} = [];

Hilbert_events = get_events_from_cyclic_phase(phase_Hilbert(start_peak_index:end_peak_index), event_list);
Hilbert_events{1,:} = [];
Hilbert_events{end,:} = [];

%%WILL NEED SOME DELAY FIDGETTING AND SYNCHRONIZATION TO BE COMPARABLE
% BSgonio_events = get_events_from_cyclic_phase(phase_Baseline, event_list);
MSgonio_events = get_events_from_cyclic_phase(phase_gonio_norm_left(start_peak_index:end_peak_index), event_list);
MSgonio_events{1,:} = [];
MSgonio_events{end,:} = [];

Observer_events = get_events_from_cyclic_phase(phase_observer(start_peak_index:end_peak_index), event_list);
Observer_events{1,:} = [];
Observer_events{end,:} = [];

%%CHECKING MSgonio_events
figure('Name','Normalized Gonio phase and event detection','Numbertitle', 'off');
hold on
dot_size = 60;
plot(timestamp,phase_Baseline,'LineWidth',2,'DisplayName','Baseline phase');%Real Time normalized cycle phase
for i=1:num_events
    name = strcat('Hilbert event ',int2str(event_list(i)));
    factor = 0.07*(i-1);
    scatter(timestamp(Hilbert_events{i}(2:end)),phase_Hilbert(Hilbert_events{i}(2:end)),dot_size*1.2,'d','filled','DisplayName',name, 'MarkerFaceColor', [0+factor, 1-factor, 0+factor])
end % timestamp(Baseline_events{i})
for i=1:num_events
    name = strcat('Baseline event ',int2str(event_list(i)));
    factor = 0.07*(i-1);
    scatter(timestamp(Baseline_events{i}(2:end)),phase_Baseline(Baseline_events{i}(2:end)),dot_size*0.7,'filled','DisplayName',name, 'MarkerFaceColor', [1-factor, 0+factor, 0+factor])
end % timestamp(Baseline_events{i})
lgd = legend(gca,'show');
xlabel('Time (sec) of the test trial') 
ylabel('Phase (%) of the cycle') 
hold off

figure('Name','Overview of event detection over a few algorithms','Numbertitle', 'off');
hold on
plot(timestamp,phase_Baseline,'LineWidth',1,'DisplayName','Baseline phase');
for i=1:num_events
    strname = strcat('Hilbert event ',int2str(event_list(i)));
    plot(timestamp(Hilbert_events{i}),phase_Baseline(Hilbert_events{i}),'LineWidth',2,'DisplayName',strname);
    strname = strcat('observer event ',int2str(event_list(i)));
    plot(timestamp(Observer_events{i}(4:end)),phase_Baseline(Observer_events{i}(4:end)),'LineWidth',2,'DisplayName',strname);
    strname = strcat('MSGonio event ',int2str(event_list(i)));
    plot(timestamp(MSgonio_events{i}(2:end)),phase_Baseline(MSgonio_events{i}(2:end)),'LineWidth',2,'DisplayName',strname);
end
lgd = legend(gca,'show');
xlabel('Time (sec) of the test trial') 
ylabel('Phase (%) of the cycle') 
hold off



fig_multi_events = figure('Name', '2D Representation of Event detection comparisons of available algorithms','Numbertitle', 'off');
hold on
dot_size = 20;
for i=1:num_events
    name = strcat('MSgonio event ',int2str(event_list(i)));
    factor = 0.02*(i-1);
    scatter(phase_Baseline(MSgonio_events{i}(3:end)),phase_Baseline(MSgonio_events{i}(3:end)),dot_size,[1-factor, 0+factor, 0+factor],'DisplayName',name)
%     scatter(phase_Baseline(MSgonio_events{i}(3:end)),phase_Baseline(MSgonio_events{i}(3:end)),dot_size,'filled','DisplayName',name, 'MarkerFaceColor', [1-factor, 0+factor, 0+factor])
end % timestamp(Baseline_events{i})

for i=1:num_events
    name = strcat('Observer event ',int2str(event_list(i)));
    factor = 0.02*(i-1);
    scatter(phase_Baseline(Observer_events{i}(4:end)),phase_Baseline(Observer_events{i}(4:end)),dot_size,[0+factor, 0+factor, 1-factor],'DisplayName',name)
%     scatter(phase_Baseline(Observer_events{i}(4:end)),phase_Baseline(Observer_events{i}(4:end)),dot_size,'filled','DisplayName',name, 'MarkerFaceColor', [0+factor, 0+factor, 1-factor])
end % timestamp(Baseline_events{i})

for i=1:num_events
    name = strcat('Hilbert event ',int2str(event_list(i)));
    factor = 0.02*(i-1);
    scatter(phase_Baseline(Hilbert_events{i}),phase_Baseline(Hilbert_events{i}),dot_size/2,[0+factor, 1-factor, 0+factor],'DisplayName',name)
%     scatter(phase_Baseline(Hilbert_events{i}),phase_Baseline(Hilbert_events{i}),dot_size,'filled','DisplayName',name, 'MarkerFaceColor', [0+factor, 1-factor, 0+factor])
end % timestamp(Hilbert_events{i})

for i=1:num_events
    name = strcat('Baseline event ',int2str(event_list(i)));
    factor = 0.02*(i-1);
    scatter(phase_Baseline(Baseline_events{i}),phase_Baseline(Baseline_events{i}),dot_size,[0, 0, 0],'DisplayName',name)
%     scatter(phase_Baseline(Baseline_events{i}),phase_Baseline(Baseline_events{i}),dot_size,'filled','DisplayName',name, 'MarkerFaceColor', [0, 0, 0])
end % timestamp(Baseline_events{i})

xlim([-1,101])
lgd = legend(gca,'show');
xlabel('Baseline Cycle Phase when event was detected in %')
ylabel('Baseline Cycle Phase when event was detected in %')
hold off


modulo_jump = 100;
Hilbert_distances = get_distances_to_baseline_events(Hilbert_events, phase_Baseline, event_list, modulo_jump);
MSgonio_distances = get_distances_to_baseline_events(MSgonio_events, phase_Baseline, event_list, modulo_jump);
Observer_distances = get_distances_to_baseline_events(Observer_events, phase_Baseline, event_list, modulo_jump);
Baseline_distances = get_distances_to_baseline_events(Baseline_events, phase_Baseline, event_list, modulo_jump);


s_n_c = 1; % start_number_cycle 1 for even the first
e_n_c = 0; % end_number_cycle 0 for up to last

fig_distances_multi_events = figure('Name', 'Distance to Baseline comparisons for available algorithms in event detection','Numbertitle', 'off');
hold on
dot_size = 30;
for i=1:num_events
    name = strcat('Observer distances ',int2str(event_list(i)));
    factor = 0.08*(i-1);
    scatter(ones(length(Observer_distances{i}(s_n_c:end-e_n_c)),1)*event_list(i),Observer_distances{i}(s_n_c:end-e_n_c),dot_size,[0+factor, 0+factor, 1-factor],'o','DisplayName',name)
end % timestamp(Baseline_events{i})        Observer_events{i}(4:end)

for i=1:num_events
    name = strcat('MSgonio distances ',int2str(event_list(i)));
    factor = 0.02*(i-1);
    scatter(ones(length(MSgonio_distances{i}(s_n_c:end-e_n_c)),1)*event_list(i),MSgonio_distances{i}(s_n_c:end-e_n_c),dot_size,[1-factor, 0+factor, 0+factor],'x','DisplayName',name)
end % timestamp(Baseline_events{i})

for i=1:num_events
    name = strcat('Hilbert distances ',int2str(event_list(i)));
    factor = 0.02*(i-1);
    scatter(ones(length(Hilbert_distances{i}(s_n_c:end-e_n_c)),1)*event_list(i),Hilbert_distances{i}(s_n_c:end-e_n_c),dot_size,[0+factor, 1-factor, 0+factor],'+','DisplayName',name)
end % timestamp(Hilbert_events{i})

for i=1:num_events
    name = strcat('Baseline events ',int2str(event_list(i)));
    factor = 0.08*(i-1);
    scatter(ones(length(Baseline_distances{i}(s_n_c:end-e_n_c)),1)*event_list(i),Baseline_distances{i}(s_n_c:end-e_n_c),dot_size*3,[0, 0, 0],'d','DisplayName',name)
end % timestamp(Baseline_events{i})

for i=1:num_events
    name = strcat('Event ',int2str(event_list(i)));
    factor = 0.08*(i-1);
    scatter(event_list(i),0,dot_size,[0, 0, 0],'d','LineWidth',2,'DisplayName',name)
end % timestamp(Baseline_events{i})

xlim([-1,101])
lgd = legend(gca,'show');
xlabel('Cycle Phase in %') 
ylabel('Distance to target in phase %') 
hold off



s_n_c = 1; % start_number_cycle 1 for even the first
e_n_c = 0; % end_number_cycle 0 for up to last

for i=1:num_events
    S = [] ; grp =[] ;
    grouping_matrix = [1*ones(size(Baseline_distances{i}(s_n_c:end-e_n_c)));
        2*ones(size(Hilbert_distances{i}(s_n_c:end-e_n_c)));
        3*ones(size(MSgonio_distances{i}(s_n_c:end-e_n_c)));
        4*ones(size(Observer_distances{i}(s_n_c:end-e_n_c)));];
    name = strcat('Box plots of event detection for available algorithms for event',int2str(event_list(i)));
    boxplot_event(i) = figure('Name', name,'Numbertitle', 'off');
    hold on
    boxplot([Baseline_distances{i}(s_n_c:end-e_n_c);...
            Hilbert_distances{i}(s_n_c:end-e_n_c);...
            MSgonio_distances{i}(s_n_c:end-e_n_c);...
            Observer_distances{i}(s_n_c:end-e_n_c)],...
            grouping_matrix,'labels',{'Baseline','Hilbert','MS_Gonio','Observer'})
    Xlabel_str = strcat('Boxplots of algorithms for event ',int2str(event_list(i)));
    xlabel(Xlabel_str) 
    ylabel('Error Distance to target in phase %') 
    hold off
end % timestamp(Baseline_events{i})




