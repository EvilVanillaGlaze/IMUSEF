%get_distances_to_baseline_events


function event_distances_list = get_distances_to_baseline_events(data_event_indexes_list, ...
    baseline_data, target_values, modulo_jump)

%     jump_safety_size = 30;
    event_distances_list = {};
    number_of_events = length(target_values);
    for event = 1:number_of_events
        target_value = target_values(event);
        %%Vector containing this loops event indexes
        event_distances_vector=[];
        %Get length of index vector for this event loop
%         data_event_indexes_vector = data_event_indexes_list{event};%(:);
%         size_indexes_vector = length(data_event_indexes_vector);
        size_indexes_vector = length(data_event_indexes_list{event});
        
        for i = 1:size_indexes_vector
            event_value_relative_to_baseline = baseline_data(data_event_indexes_list{event}(i));
            %%Two distance tests, first for normal case, subtracting the
            %%target value. Distance positive if late, negative if early.
            normal_diff = event_value_relative_to_baseline - target_value;
            
            %%Second case for modulo reset tests.
            %if ev < target
            if event_value_relative_to_baseline < target_value
                %%event - target + jump
                modulo_diff = event_value_relative_to_baseline - target_value + modulo_jump;
            %elseif ev > target 
            %elseif event_value_relative_to_baseline > target_value 
            else
                %%event - target - jump
                modulo_diff = event_value_relative_to_baseline - target_value - modulo_jump;
            end
            %Retreiving the closest of the two, considered to be the real distance
            results = [normal_diff modulo_diff];
            [~, res_index] = min(abs(results));
            distance_to_target = results(res_index);
            
            event_distances_vector = [event_distances_vector; distance_to_target];
        end
        event_distances_list{event} = event_distances_vector;
    end
            
end

% function event_distances_list = get_distances_to_baseline_events(data_event_indexes_list, data_event_values_list,...
%     baseline_event_indexes_list, baseline_event_values_list, target_values, modulo_jump)
% 
%     jump_safety_size = 30;
%     event_distances_list = {};
%     number_of_events = length(target_values);
%     for event = 1:number_of_events
%         target_value = target_values(event);
%         %%Vector containing this loops event indexes
%         event_distances_vector=[];
%         %Get length of index vector for this event loop
%         data_event_indexes_vector = cell2mat(data_event_indexes_list{event}(:));
%         size_indexes_vector = length(data_event_indexes_vector);
%         baseline_event_indexes_vector = cell2mat(baseline_event_indexes_list{event}(:));
%         size_baseline_indexes_vector = length(baseline_event_indexes_vector);
%         
%         for i = 1:size_indexes_vector
%             
%             event_index_after = find(baseline_event_indexes_vector(:) > data_event_indexes_vector(i),1);
%             if isempty(event_index_after)
%                 event_index = baseline_event_indexes_vector(end);
%             elseif event_index_after > 1 %%If Not the first one, get previous one also
%                 event_index_before = event_index_after - 1;
%                 diff_index_before = data_event_indexes_vector(i) - baseline_event_indexes_vector(event_index_before);
%                 diff_index_after = baseline_event_indexes_vector(event_index_after) - data_event_indexes_vector(i);
%                 %%Chose closest event of the 2
%                 if diff_index_before <= diff_index_after
%                     event_index = event_index_before;
%                 else 
%                     event_index = event_index_after;
%                 end
%             else
%                 event_index = event_index_after;
%             end
%             
%             %%Comparing event value with corresponding closest baseline
%             %%event value.
%             dist_to_target = data_event_values_list(baseline_event_indexes_vector(event_index)) - ...
%                 baseline_event_values_list(baseline_event_indexes_vector(event_index));
%             %%OR comparing to target values directly ? 
% %             dist_to_target = data_event_values_list(baseline_event_indexes_vector(event_index)) - target_values(event);
%             
%             
%             event_distances_vector = [event_distances_vector; dist_to_target];
%         end
%         event_distances_list{event} = event_distances_vector;
%     end
%             
% end


