%get_events_from_cyclic_phase


function event_indexes_list = get_events_from_cyclic_phase(data_vector, target_values)
    jump_safety_size = 30;
    event_indexes_list = {};
    number_of_events = length(target_values);
    for event = 1:number_of_events
        %%Number of samples around which an other target cannot be validated
        neighborhood_safety = 5;
        size_data_vector = size(data_vector,1);
        %%For every sample of the input vector
        target_value = target_values(event);
        %%Vector containing this loops event indexes
        event_indexes_vector=[];
        for i = 1:size_data_vector-1
            %%Normal case : Phase raising above event threshold
            if data_vector(i+1)>=data_vector(i) 
                if data_vector(i)<target_value && data_vector(i+1)>=target_value
                    %%Check if another target wasn't detected in the few
                    %%previous samples. But first, if the arrray is empty, add.
                    if isempty(event_indexes_vector)
                        event_indexes_vector = [event_indexes_vector; (i+1)];
                    %%Check to avoid 2 following samples being of the same values 
                    %%and on the event value.
                    elseif i > neighborhood_safety + event_indexes_vector(end)
                        event_indexes_vector = [event_indexes_vector; (i+1)];
                    end
                end
            %%Either modulo reset limit case or phase is going backward
            %%Limit case : Phase raising above event threshold but going
            %%back to 0 in the process i.e. Next sample is a modulo reset case
            elseif data_vector(i+1) + jump_safety_size < data_vector(i) 
                %%Case where event is just before the modulo reset
                if data_vector(i)<target_value && data_vector(i+1)<=target_value
                    %%Check if another target wasn't detected in the few
                    %%previous samples. But first, if the arrray is empty, add.
                    if isempty(event_indexes_vector)
                        event_indexes_vector = [event_indexes_vector; (i+1)];
                    %%Check to avoid 2 following samples being of the same values 
                    %%and on the event value.
                    elseif i > neighborhood_safety + event_indexes_vector(end)
                        event_indexes_vector = [event_indexes_vector; (i+1)];
                    end
                %%Case where event is just after the modulo reset
                elseif data_vector(i)>target_value && data_vector(i+1)>=target_value
                    %%Check if another target wasn't detected in the few
                    %%previous samples. But first, if the arrray is empty, add.
                    if isempty(event_indexes_vector)
                        event_indexes_vector = [event_indexes_vector; (i+1)];
                    %%Check to avoid 2 following samples being of the same values 
                    %%and on the event value.
                    elseif i > neighborhood_safety + event_indexes_vector(end)
                        event_indexes_vector = [event_indexes_vector; (i+1)];
                    end
                end
            else
                %%We are in the case where the bad little phase is going
                %%backwards. Not triggering events on those cases to simplify
            end
        end
        event_indexes_list{event} = event_indexes_vector;
    end
            
end
