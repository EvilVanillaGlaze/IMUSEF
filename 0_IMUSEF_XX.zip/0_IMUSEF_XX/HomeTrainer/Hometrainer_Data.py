
class Hometrainer_Data(object):

    def __init__(self):

        self.Speed = 0.0
        self.Distance = 0.0
        self.Torque = 0.0
        self.Power = 0.0
        self.Power_AVG = 0.0