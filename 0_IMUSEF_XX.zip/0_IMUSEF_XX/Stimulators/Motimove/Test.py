#!/usr/bin/python3
import serial           # import the module
import time
from MM_Message_Builder import MM_Message_Builder

def my_sleep(duration):
    time2sleep = time.time() + duration - 0.0001;
    while time.time() < time2sleep:
        time.sleep(0.0001)

def getMessage(intensity):

    # Pulse by Pulse control
    header = b'\xff\x22'
    type = b'\x08'  # 0x08-pulse by pulse, 0X02-start train of pulses, 0X03-stop train of pulses
    delay = b'\x00'  # 0x00 for delay between adjacent channels equal to T/8, where T is period of stimulation;
    # or 0xAB for no delay between pulses on adjacent channels)
    T = b'\x0A'  # the period (T) in ms (defined by the master controller)
    power = int.to_bytes(intensity,1,'big')  # power modulation (max value 100 = 100%)
    I_Ch1 = b'\x14'  # Stimulation intensity in mA (max 170mA)
    I_Ch2 = b'\x00'  # Stimulation intensity in mA (max 170mA)
    I_Ch3 = b'\x00'  # Stimulation intensity in mA (max 170mA)
    I_Ch4 = b'\x00'  # Stimulation intensity in mA (max 170mA)
    I_Ch5 = b'\x00'  # Stimulation intensity in mA (max 170mA)
    I_Ch6 = b'\x00'  # Stimulation intensity in mA (max 170mA)
    I_Ch7 = b'\x00'  # Stimulation intensity in mA (max 170mA)
    I_Ch8 = b'\x00'  # Stimulation intensity in mA (max 170mA)
    PhW_Ch1 = b'\x32'  # phasewidth in multiple of 10μs (max value is 100 = 1000μs)
    PhW_Ch2 = b'\x32'  # phasewidth in multiple of 10μs (max value is 100 = 1000μs)
    PhW_Ch3 = b'\x32'  # phasewidth in multiple of 10μs (max value is 100 = 1000μs)
    PhW_Ch4 = b'\x32'  # phasewidth in multiple of 10μs (max value is 100 = 1000μs)
    PhW_Ch5 = b'\x32'  # phasewidth in multiple of 10μs (max value is 100 = 1000μs)
    PhW_Ch6 = b'\x32'  # phasewidth in multiple of 10μs (max value is 100 = 1000μs)
    PhW_Ch7 = b'\x32'  # phasewidth in multiple of 10μs (max value is 100 = 1000μs)
    PhW_Ch8 = b'\x32'  # phasewidth in multiple of 10μs (max value is 100 = 1000μs)
    PreScaler_Ch1 = b'\x01'  # PreScaler
    PreScaler_Ch2 = b'\x01'  # PreScaler
    PreScaler_Ch3 = b'\x01'  # PreScaler
    PreScaler_Ch4 = b'\x01'  # PreScaler
    PreScaler_Ch5 = b'\x01'  # PreScaler
    PreScaler_Ch6 = b'\x01'  # PreScaler
    PreScaler_Ch7 = b'\x01'  # PreScaler
    PreScaler_Ch8 = b'\x01'  # PreScaler
    doublets = b'\x00'  # doublets on/off, one bit for each channel
    delay_doublets = b'\x1B'  # TimeDelay for doublets in multiple of 100μs (min 27 = 2.7ms, max 100 = 10ms, max PW=500μs)
    sensor_input = b'\x00'  # choice of sensor input (0x00-analog inputs from AI connector,
    # 0x01-signals from wireless module on S1 connector,
    # 0x02-signals from ISO EXTENDER on S2 connector)
    highVoltage = b'\x01'  # turning on high voltage (0x01 - on, 0x00 - off, 0x02 – do not change)

    # Build message
    message = bytearray()
    message += header
    message += type
    message += delay
    message += T
    message += power
    message += I_Ch1
    message += I_Ch2
    message += I_Ch3
    message += I_Ch4
    message += I_Ch5
    message += I_Ch6
    message += I_Ch7
    message += I_Ch8
    message += PhW_Ch1
    message += PhW_Ch2
    message += PhW_Ch3
    message += PhW_Ch4
    message += PhW_Ch5
    message += PhW_Ch6
    message += PhW_Ch7
    message += PhW_Ch8
    message += PreScaler_Ch1
    message += PreScaler_Ch2
    message += PreScaler_Ch3
    message += PreScaler_Ch4
    message += PreScaler_Ch5
    message += PreScaler_Ch6
    message += PreScaler_Ch7
    message += PreScaler_Ch8
    message += doublets
    message += delay_doublets
    message += sensor_input
    message += highVoltage

    # Checksum
    chksum = 0
    for i in range(1, len(message)):  # from 2. byte
        # print(str(i) + ': ' + str(message[i]))
        chksum += message[i]
        chksum = chksum & 0x7F

    message += chksum.to_bytes(1, 'big')

    return message


def main():
    print("Hello MORTEN")

# COM Settings
ComPort = serial.Serial("/dev/ttyUSB0")  # open ttyUSB0
ComPort.baudrate = 115200  # set Baud rate to 115200
ComPort.bytesize = 8  # Number of data bits = 8
ComPort.parity = 'N'  # No parity
ComPort.stopbits = 1  # Number of Stop bits = 1

intensity = 50

message_builder = MM_Message_Builder()


while True:

    message = message_builder.getMessage()
    No = ComPort.write(message)
    # print(data.hex())  # print the data
    print(message.hex())  # print the data


    dataIn = ComPort.read(16)  # Wait and read data
    #print(dataIn.hex())
    intensity = dataIn[14]
    print('Intensity' + str(intensity) + "%")                      # print the received data

    my_sleep(1)

    if __name__ == '__main__':

        try:
            main()

        except KeyboardInterrupt:

            print('\nUser requested Application STOP\n')
            ComPort.close()

        except Exception as error:
            ComPort.close()
            print('\nException error: \n')



        # Close the Com port

