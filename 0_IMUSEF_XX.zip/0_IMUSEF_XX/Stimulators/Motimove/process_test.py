from Stimulators.Motimove.MM_Manager import MM_Manager
import time
# Testroutine
if __name__ == '__main__':

    myMM_manager = MM_Manager()

    #mm_manager.connect()

    myMM_manager.setStimFrequency(100)
    myMM_manager.setActiveChannels([True, False, False, False, True, False, False, False])
    myMM_manager.setStimPhasewidth([100, 100, 100, 100, 100, 100, 100, 100])
    myMM_manager.setMaxAmplitude([100, 100, 100, 100, 100, 100, 100, 100])

    myMM_manager.start()

    while True:

        print("Lauft")
        time.sleep(1)