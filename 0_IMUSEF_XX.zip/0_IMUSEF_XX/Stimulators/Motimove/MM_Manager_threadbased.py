## Control Interface for MOTIMOVE 8
## (c) Dipl.-Ing. Dr. Martin Schmoll, BSc


# !/usr/bin/python3
import serial  # import the module
import time
import threading
from Stimulators.Motimove.MM_Message_Builder_Threadbased import MM_Message_Builder
from IMUSEF_Data import  IMUSEF_Data
from Controllers.PID_Controller import PID_Controller

# Debugflag
DEBUG = True


# Motimove Manager
class MM_Manager(object):

    # Constructor
    def __init__(self):

        # TODO: implement
        ## State
        # -2 ... Error
        # -1 ... Module not active
        #  0 ... Connecting
        #  1 ... Connected
        self.State = -1

        #self.READY = True
        self.BEEP_OK = False
        #self.notify_Parameter_update = False

        # Initialisation
        self.Phasewidths = [1000, 500, 500, 500, 500, 500, 500, 500]
        self.Phasewidths_Boost = [1000, 500, 500, 500, 500, 500, 500, 500]
        self.Amplitudes = [100, 100, 100, 100, 100, 100, 100, 100]
        self.Intensity = 0
        self.Frequency = 40
        self.Frequency_Boost = 80
        self.BOOST = False

        self.PIDInitialized = False
        self.DesiredCadence = 0
        self.interr = 0
        self.data=IMUSEF_Data()
        self.LastCadence = 0
        self.Previous = 0

        # Configuration
        self.message_builder = MM_Message_Builder()
        self.message_builder.setPhasewidths(self.Phasewidths)
        self.message_builder.setAmplitude(self.Amplitudes)
        self.message_builder.setIntensity(self.Intensity)
        self.message_builder.setStimFrequency(self.Frequency)
        self.message_builder.setHighVoltage(MM_Message_Builder.HIGH_VOLTAGE_OFF)

    # Configures the MM_Manager and the MM_Messagebuilder
    def configure(self, config_JSON):

        # Read from JSON
        self.Phasewidths = config_JSON["PhW"]
        self.Phasewidths_Boost = config_JSON["PhW_Boost"]
        self.Amlitudes = config_JSON["I_Max"]
        self.Frequency = config_JSON["F"]
        self.Frequency_Boost = config_JSON["F_Boost"]

        # Obsolete
        # self.__Monophasic = config_JSON["Monophasic"]
        # self.__IPG = config_JSON["IPG"]
        # self.__RampUP = config_JSON["RampUP"]
        # self.__RampDOWN = config_JSON["RampDOWN"]

        # Configuration
        self.message_builder.setPhasewidths(self.Phasewidths)
        self.message_builder.setAmplitude(self.Amplitudes)
        self.message_builder.setIntensity(self.Intensity)
        self.message_builder.setStimFrequency(self.Frequency)
        self.message_builder.setHighVoltage(MM_Message_Builder.HIGH_VOLTAGE_OFF)

    # Returns the current configuration
    def getStimConfig(self):
        data = {
            "F": self.Frequency,
            "F_Boost": self.Frequency_Boost,
            "Monophasic": [True, True, True, True, True, True, True, True],
            "PhW": self.Phasewidths,
            "PhW_Boost": self.Phasewidths_Boost,
            "IPG": [0, 0, 0, 0, 0, 0, 0, 0],
            "I_Max": self.Amplitudes,
            "RampUP": [0, 0, 0, 0, 0, 0, 0, 0],
            "RampDOWN": [0, 0, 0, 0, 0, 0, 0, 0]
        }

        return data

    def updateConfiguration(self,params):
        self.Frequency = params["F"]
        self.message_builder.setStimFrequency(self.Frequency)
        self.Frequency_Boost = params["F_Boost"]
        self.Phasewidths = params["PhW"]
        self.message_builder.setPhasewidths(self.Phasewidths)
        self.Phasewidths_Boost = params["PhW_Boost"]
        self.Amplitudes = params["I_Max"]
        self.message_builder.setAmplitude(self.Amplitudes)
        return True






    # Updates the stimulation amplitude
    def updateAmplitude(self, I):

        # Boundary Check
        if (I > 100):
            I = 100
        elif (I < 0):
            I = 0

        if not (self.Intensity == I):
            self.Intensity = I

        return True


    # Returns the current stimulation intensity in [%]
    def getStimulationIntensity(self):
        return self.message_builder.getIntensity()

    # Updates the state of the BOOST Button
    def updateBOOST(self, BOOST):

        # Convert from integer to boolean
        bool_BOOST = (BOOST == 1)

        if not (self.BOOST == bool_BOOST):
            self.BOOST = bool_BOOST

            if self.BOOST:
                self.message_builder.setPhasewidths(self.Phasewidths_Boost)
                self.message_builder.setStimFrequency(self.Frequency_Boost)
            else:
                self.message_builder.setPhasewidths(self.Phasewidths)
                self.message_builder.setStimFrequency(self.Frequency)

        return True

    # Function to start independent Thread generating pulses
    def start(self, exit_Event):

        # Exit Event
        self.__exit_Event = exit_Event

        # Start Thread
        self.__thread_Worker = threading.Thread(name='Stimulation_Thread', target=self.__run, args=())
        self.__thread_Worker.daemon = True
        self.__thread_Worker.start()




    # Worker method for Pulsegeneration
    def __run(self):

        # Connect stimulator
        self.connect()


        ## Main Loop
        while not self.__exit_Event.isSet():

            # Prepare and send message Pulse by Pulse




            self.message_builder.setHighVoltage(MM_Message_Builder.HIGH_VOLTAGE_ON)
            message = self.message_builder.getMessage()
            self.com.write(message)

            dataIn = self.com.read(16)  # Wait and read data
            # print(dataIn.hex())
            try:
                intensity = dataIn[14]
                ## first try to implement PID directly. now moved outside
                # if IMUSEF_Data.Status_PID == 1:
                #     self.message_builder.setIntensity(int(PID_Controller.PID()))
                # else:
                #     self.message_builder.setIntensity(int(self.Intensity))
                #self.message_builder.setIntensity(int(result))
                self.message_builder.setIntensity(int(self.Intensity))
                self.State = 1
                # print('Intensity' + str(intensity) + "%")  # print the received data
            except:
                self.State = -2
                self.connect()

            T = self.message_builder.getStimPeriode() / 1000
            time.sleep(T)



    # Initializes Connection
    def connect(self):

        # Reconnect
        if self.State == -2:
            self.com.close()
            time.sleep(1)

        while self.State != 1:

            # Trying to connect
            self.State = 0

            # COM Settings
            self.com = serial.Serial("/dev/MOTIMOVE")  # open ttyMM0
            self.com.baudrate = 115200  # set Baud rate to 115200
            self.com.bytesize = 8  # Number of data bits = 8
            self.com.parity = 'N'  # No parity
            self.com.stopbits = 1  # Number of Stop bits = 1
            self.com.timeout = 1  # Timeout 1 s

            # Test connection
            self.message_builder.setIntensity(0)
            self.message_builder.setHighVoltage(MM_Message_Builder.HIGH_VOLTAGE_OFF)
            message = self.message_builder.getMessage()
            self.com.write(message)

            try:
                dataIn = self.com.read(16)
                # if there was a response from the Stimulator it is considered ready
                if dataIn:
                    self.State = 1
                else:
                    self.State = -2
            except:
                self.State = -2

    # Closes the connection
    def disconnect(self):
        try:
            self.com.close()
        except:
            pass

    # Sets the active Channels
    def setActiveChannels(self, activeChannels):
        self.message_builder.setActiveChannels(activeChannels)

    # Sets the Stimulation Frequency in [Hz]
    def setStimFrequency(self, F):
        self.message_builder.setStimFrequency(F)

    # Sets the stimulation Phasewidth in [µs]
    def setStimPhasewidth(self,PhW):
        self.message_builder.setPhasewidths(PhW)



# Testroutine
if __name__ == '__main__':

    exit = threading.Event()

    mm_manager = MM_Manager()
    mm_manager.setStimFrequency(30)
    mm_manager.setActiveChannels([True, False, False, False, True, False, False, False])
    mm_manager.updateAmplitude(5)
    mm_manager.start(exit)
    time.sleep(10)
    print("Amp 0")
    mm_manager.updateAmplitude(0)
    #mm_manager.connect()





    # mm_manager.message_builder.setHighVoltage(MM_Message_Builder.HIGH_VOLTAGE_ON)
    # message = mm_manager.message_builder.getMessage()
    # mm_manager.com.write(message)

    #time.sleep(500)



    i = 1
    while (True):
        # if i == 1:
        #     mm_manager.setStimFrequency(5)
        #     mm_manager.setActiveChannels([True, False, False, False, False, False, False, False])
        # elif i == 2:
        #     mm_manager.setStimFrequency(10)
        #     mm_manager.setActiveChannels([False, True, False, False, False, False, False, False])
        # elif i == 3:
        #     mm_manager.setStimFrequency(20)
        #     mm_manager.setActiveChannels([False, False, True, False, False, False, False, False])
        # elif i == 4:
        #     mm_manager.setStimFrequency(80)
        #     mm_manager.setActiveChannels([False, False, False, True, False, False, False, False])
        # elif i == 5:
        #     mm_manager.setActiveChannels([False, False, False, False, False, False, False, False])
        #     i = 0
        #
        print("Stimulation on CH: " + str(i))
        # i += 1

        time.sleep(1)
