import Stimulators.BerkelBike_FESBox.API_BerkelStim
import Stimulators.BerkelBike_FESBox.BB_messages
import threading
import time
import json
from queue import Queue
from myGPIO.GPIO_Manager import GPIO_Manager

DEBUG = True


class FESBox_Manager(object):

    def __init__(self):

        # DataContainer
        self.__sendingQueue = Queue()

        # Stimulator
        self.stimulator = Stimulators.BerkelBike_FESBox.API_BerkelStim.BERKELSTIM();
        self.READY = False

        self.stimulator.COM_Port = 6
        self.stimulator.MAC_Address = '34:81:F4:2B:E7:6B' #'34:81:F4:36:E4:33'

        ## State
        # -2 ... Error
        # -1 ... Module not active
        #  0 ... Connecting
        #  1 ... Connected
        self.State = -1

        # Stimulation Channels
        self.__CH_active = [False, False, False, False, False, False, False, False]

        # Update flags
        self.__update_CHANNELS_ON_OFF = False
        self.__acknowledge_ChangeActiveChannels = False
        self.__update_AMPLITUDE = False
        self.__update_BOOST = False
        self.__update_PARAMETERS = False                          # During configuration this flag will cause the update of all channels
        self.__request_Amplitude = False

        # Stimulation Parameters
        self.__F = 100                                                                  # Global Stimulation Frequency in [Hz]
        self.__I = 0                                                                    # Global relative Stimulation Amplitude in [%]
        self.__I_New = 0                                                                # Global relative Stimulation Amplitude in [%]
        self.__PhW = [100, 100, 100, 100, 100, 100, 100, 100]                           # Phasewidth for each channel in [us]
        self.__PhW_Boost = [100, 100, 100, 100, 100, 100, 100, 100]                     # Phasewidth for each channel in [us] during BOOST
        self.__Monophasic = [False, False, False, False, False, False, False, False]    # Phasewidth for each channel in [us]
        self.__IPG = [0, 0, 0, 0, 0, 0, 0, 0]                                           # Interphase gap for each channel in [us]
        self.__Imax =[10, 10, 10, 10, 10, 10, 10, 10]                                   # Maximal stimulation current in [mA]
        self.__RampUP = [0, 0, 0, 0, 0, 0, 0, 0]                                        # Rising Time for Stimulation intensity in [ms]
        self.__RampDOWN = [0, 0, 0, 0, 0, 0, 0, 0]                                      # Falling Time for Stimulation intensity in [ms]

        # BOOST MODE
        self.BOOST = False                                                                # Defines wheter BOOST-Mode is active or not
        self.__F_BOOST = 60                                                               # Stimulation Frequency during activation of the BOOST-Button in [Hz]
        self.__Doublet_BOOST = [False, False, False, False, False, False, False, False]   # Sets the IPG for defined channels to 2 ms

        # Channel configuration
        self.__Ch1_config = Stimulators.BerkelBike_FESBox.BB_messages.StimChannelParameters();
        self.__Ch2_config = Stimulators.BerkelBike_FESBox.BB_messages.StimChannelParameters();
        self.__Ch3_config = Stimulators.BerkelBike_FESBox.BB_messages.StimChannelParameters();
        self.__Ch4_config = Stimulators.BerkelBike_FESBox.BB_messages.StimChannelParameters();
        self.__Ch5_config = Stimulators.BerkelBike_FESBox.BB_messages.StimChannelParameters();
        self.__Ch6_config = Stimulators.BerkelBike_FESBox.BB_messages.StimChannelParameters();
        self.__Ch7_config = Stimulators.BerkelBike_FESBox.BB_messages.StimChannelParameters();
        self.__Ch8_config = Stimulators.BerkelBike_FESBox.BB_messages.StimChannelParameters();

        # Do BEEP
        self.BEEP_OK = False
        self.notify_Parameter_update = False


    # loads a new Configuration to the stimulator
    def configure(self, params):

        # TODO: Validate Params

        self.__Monophasic = params["Monophasic"]
        self.__PhW = params["PhW"]
        self.__PhW_Boost = params["PhW_Boost"]
        self.__IPG = params["IPG"]
        self.__Imax = params["I_Max"]

        self.__F = params["F"]
        self.__F_BOOST = params["F_Boost"]

        self.__RampUP = params["RampUP"]
        self.__RampDOWN = params["RampDOWN"]


    # Configures the stimulator Individually for each channel
    def __config(self):

        # Parameters for Channel 1
        ch = 0
        self.__Ch1_config.Byte_Channel = ch
        self.__Ch1_config.Int16_PulsePosWidthInuS = self.__PhW[ch]
        self.__Ch1_config.Int16_PulseInterWidthInuS = self.__IPG[ch]
        if self.__Monophasic[ch]:
            self.__Ch1_config.Int16_PulseNegWidthInuS = 0
        else:
            self.__Ch1_config.Int16_PulseNegWidthInuS = self.__PhW[ch]
        self.__Ch1_config.Int32_CurrentInuA = self.__Imax[ch] * 1000
        self.__Ch1_config.Int16_RampUp = self.__calcRampParams(self.__RampUP[ch])
        self.__Ch1_config.Int16_RampDown = self.__calcRampParams(self.__RampDOWN[ch])


        # Parameters for Channel 2
        ch = 1
        self.__Ch2_config.Byte_Channel = ch
        self.__Ch2_config.Int16_PulsePosWidthInuS = self.__PhW[ch]
        self.__Ch2_config.Int16_PulseInterWidthInuS = self.__IPG[ch]
        if self.__Monophasic[ch]:
            self.__Ch2_config.Int16_PulseNegWidthInuS = 0
        else:
            self.__Ch2_config.Int16_PulseNegWidthInuS = self.__PhW[ch]
        self.__Ch2_config.Int32_CurrentInuA = self.__Imax[ch] * 1000
        self.__Ch2_config.Int16_RampUp = self.__calcRampParams(self.__RampUP[ch])
        self.__Ch2_config.Int16_RampDown = self.__calcRampParams(self.__RampDOWN[ch])

        # Parameters for Channel 3
        ch = 2
        self.__Ch3_config.Byte_Channel = ch
        self.__Ch3_config.Int16_PulsePosWidthInuS = self.__PhW[ch]
        self.__Ch3_config.Int16_PulseInterWidthInuS = self.__IPG[ch]
        if self.__Monophasic[ch]:
            self.__Ch3_config.Int16_PulseNegWidthInuS = 0
        else:
            self.__Ch3_config.Int16_PulseNegWidthInuS = self.__PhW[ch]
        self.__Ch3_config.Int32_CurrentInuA = self.__Imax[ch] * 1000
        self.__Ch3_config.Int16_RampUp = self.__calcRampParams(self.__RampUP[ch])
        self.__Ch3_config.Int16_RampDown = self.__calcRampParams(self.__RampDOWN[ch])

        # Parameters for Channel 4
        ch = 3
        self.__Ch4_config.Byte_Channel = ch
        self.__Ch4_config.Int16_PulsePosWidthInuS = self.__PhW[ch]
        self.__Ch4_config.Int16_PulseInterWidthInuS = self.__IPG[ch]
        if self.__Monophasic[ch]:
            self.__Ch4_config.Int16_PulseNegWidthInuS = 0
        else:
            self.__Ch4_config.Int16_PulseNegWidthInuS = self.__PhW[ch]
        self.__Ch4_config.Int32_CurrentInuA = self.__Imax[ch] * 1000
        self.__Ch4_config.Int16_RampUp = self.__calcRampParams(self.__RampUP[ch])
        self.__Ch4_config.Int16_RampDown = self.__calcRampParams(self.__RampDOWN[ch])

        # Parameters for Channel 5
        ch = 4
        self.__Ch5_config.Byte_Channel = ch
        self.__Ch5_config.Int16_PulsePosWidthInuS = self.__PhW[ch]
        self.__Ch5_config.Int16_PulseInterWidthInuS = self.__IPG[ch]
        if self.__Monophasic[ch]:
            self.__Ch5_config.Int16_PulseNegWidthInuS = 0
        else:
            self.__Ch5_config.Int16_PulseNegWidthInuS = self.__PhW[ch]
        self.__Ch5_config.Int32_CurrentInuA = self.__Imax[ch] * 1000
        self.__Ch5_config.Int16_RampUp = self.__calcRampParams(self.__RampUP[ch])
        self.__Ch5_config.Int16_RampDown = self.__calcRampParams(self.__RampDOWN[ch])

        # Parameters for Channel 6
        ch = 5
        self.__Ch6_config.Byte_Channel = ch
        self.__Ch6_config.Int16_PulsePosWidthInuS = self.__PhW[ch]
        self.__Ch6_config.Int16_PulseInterWidthInuS = self.__IPG[ch]
        if self.__Monophasic[ch]:
            self.__Ch6_config.Int16_PulseNegWidthInuS = 0
        else:
            self.__Ch6_config.Int16_PulseNegWidthInuS = self.__PhW[ch]
        self.__Ch6_config.Int32_CurrentInuA = self.__Imax[ch] * 1000
        self.__Ch6_config.Int16_RampUp = self.__calcRampParams(self.__RampUP[ch])
        self.__Ch6_config.Int16_RampDown = self.__calcRampParams(self.__RampDOWN[ch])

        # Parameters for Channel 7
        ch = 6
        self.__Ch7_config.Byte_Channel = ch
        self.__Ch7_config.Int16_PulsePosWidthInuS = self.__PhW[ch]
        self.__Ch7_config.Int16_PulseInterWidthInuS = self.__IPG[ch]
        if self.__Monophasic[ch]:
            self.__Ch7_config.Int16_PulseNegWidthInuS = 0
        else:
            self.__Ch7_config.Int16_PulseNegWidthInuS = self.__PhW[ch]
        self.__Ch7_config.Int32_CurrentInuA = self.__Imax[ch] * 1000
        self.__Ch7_config.Int16_RampUp = self.__calcRampParams(self.__RampUP[ch])
        self.__Ch7_config.Int16_RampDown = self.__calcRampParams(self.__RampDOWN[ch])

        # Parameters for Channel 8
        ch = 7
        self.__Ch8_config.Byte_Channel = ch
        self.__Ch8_config.Int16_PulsePosWidthInuS = self.__PhW[ch]
        self.__Ch8_config.Int16_PulseInterWidthInuS = self.__IPG[ch]
        if self.__Monophasic[ch]:
            self.__Ch8_config.Int16_PulseNegWidthInuS = 0
        else:
            self.__Ch8_config.Int16_PulseNegWidthInuS = self.__PhW[ch]
        self.__Ch8_config.Int32_CurrentInuA = self.__Imax[ch] * 1000
        self.__Ch8_config.Int16_RampUp = self.__calcRampParams(self.__RampUP[ch])
        self.__Ch8_config.Int16_RampDown = self.__calcRampParams(self.__RampDOWN[ch])


        self.stimulator.ChannelDataList = [self.__Ch1_config,
                                           self.__Ch2_config,
                                           self.__Ch3_config,
                                           self.__Ch4_config,
                                           self.__Ch5_config,
                                           self.__Ch6_config,
                                           self.__Ch7_config,
                                           self.__Ch8_config]

        # Configure global Settings
        self.stimulator.StimVarParams.Byte_Frequency = self.__F;
        self.stimulator.StimVarParams.Byte_CurrentStepAsPercentage = 3;
        self.stimulator.StimVarParams.Int32_ManualCurrentStepInuA = 3000;
        self.stimulator.StimVarParams.Int32_MaxManualCurrentStepInuA = 150000;
        self.stimulator.StimVarParams.Byte_MaxVoltage = 200; # 200 activates the maximal possible voltage of 180V





    # Calculates the next fitting Params for the Ramp parameters
    def __calcRampParams(self, time_ms):

        steps = round(time_ms/(1000/self.__F));

        if steps < 1:
            return 1
        else:
            return steps




    # Doing the work, sends a message to the stimulator if there is one. Otherwise just waiting
    def __update_Worker(self):

        while not self.__exit_Event.isSet():



            # Wait until something needs to be updated
            try:
                while not (self.__update_PARAMETERS or\
                           self.__update_AMPLITUDE or \
                           self.__request_Amplitude or \
                           self.__update_CHANNELS_ON_OFF or\
                           self.__update_BOOST):

                    self.READY = self.stimulator.READY

                    time.sleep(0.002)
            except:
                if DEBUG: print(e)
                return

            if self.READY:
                try:

                    # Updates the stimulation parameters of the stimulator
                    if(self.__update_PARAMETERS and self.READY):

                        # Turn off stimulation
                        self.__CH_active = [False, False, False, False, False, False, False, False]
                        self.stimulator.set_ActiveChannels(self.__CH_active, send_acknowledged=True)

                        # Update internal Intensity
                        self.__I = 0

                        # Initialize stimulator
                        self.stimulator.init()

                        self.__update_PARAMETERS = False

                        # Verify that stimulator is still connected
                        self.READY = self.stimulator.READY

                        self.notify_Parameter_update = True


                    # Updates whether a set of channels is active or not
                    if(self.__update_CHANNELS_ON_OFF and self.READY):

                        # Send message
                        self.stimulator.set_ActiveChannels(self.__CH_active, send_acknowledged=self.__acknowledge_ChangeActiveChannels)

                        # Reset update channels flag
                        self.__update_CHANNELS_ON_OFF = False


                    # Updates the stimulator with a new amplitude
                    if (self.__update_AMPLITUDE and self.READY):
                        result = self.stimulator.set_IntensityPercentage(self.__I_New)

                        if result:
                            self.__I = self.__I_New

                        self.__update_AMPLITUDE = False

                    # Requests the current stimulation intensity of the Stimulator
                    if (self.__request_Amplitude and self.READY):
                        self.__I = self.stimulator.get_stim_sytem_current(send_acknowledged = True)

                        self.__request_Amplitude = False

                    # Updates the stimulator with a new global Frequency during BOOST mode
                    if (self.__update_BOOST and self.READY):

                        start = time.time()

                        # Switch off stimulation
                        self.stimulator.set_ActiveChannels([False, False, False, False, False, False, False, False])

                        if(self.BOOST):
                            self.stimulator.set_Phasewidths(self.__PhW_Boost, self.__Monophasic)
                            self.stimulator.set_StimFrequency(self.__F_BOOST)

                        else:
                            self.stimulator.set_Phasewidths(self.__PhW, self.__Monophasic)
                            self.stimulator.set_StimFrequency(self.__F)

                        # Validate Parameters
                        if not self.stimulator.validateNewParameter():
                            return

                        # Switch ON stimulation
                        self.stimulator.set_ActiveChannels(self.__CH_active)

                        if DEBUG: print("Changing Frequency takes: " + str((time.time() - start) * 1000) + "ms")

                        self.__update_BOOST = False

                except Exception as e:
                    if DEBUG: print(e)
                    pass

            else:
                time.sleep(0.5)


    # Connects to the stimulaor and starts independent Sending Thread
    def start(self, exit_Event, MAC_Stimulator):

        # Exit Event
        self.__exit_Event = exit_Event

        # Device Address
        self.stimulator.MAC_Address = MAC_Stimulator

        # Start Connecting Thread
        self.__thread_Connecting_Worker = threading.Thread(name='FESBox_Manager_Connection_Thread', target=self.__Connection_Worker, args=())
        self.__thread_Connecting_Worker.daemon = True
        self.__thread_Connecting_Worker.start()


        # Starting Thread
        self.thread_update = threading.Thread(name='FESBox_Manager_Update_Thread',target=self.__update_Worker, args=())
        self.thread_update.daemon = True
        self.thread_update.start()

    # Tries to connect to stimulaor
    def __Connection_Worker(self):

        self.stimulator.start_reading_thread()

        while not self.__exit_Event.isSet():


            # Not Connected
            if not self.State == 1:

                self.State = 0
                if DEBUG: print("\nTry connecting to stimulator")

                if self.stimulator.connect():

                    self.__config()
                    self.stimulator.init()
                    self.__update_PARAMETERS = False
                    self.READY = self.stimulator.READY
                    self.State = 1

                    if DEBUG: print("Connected to Stimulator")
                else:
                    self.State = -2
                    if DEBUG: print("NOT connected")

            # Connected
            else:

                self.READY = self.stimulator.READY

                # Check Connection State
                if not self.READY:
                    if DEBUG: print("FESBox_Manager: Stimulator not ready - reconnect")
                    self.__I = 0
                    self.State = -2

            time.sleep(5)




    # Switches off stimulation and disconnects from device
    def disconnect(self):
        self.stimulator.clean_exit()
        if DEBUG: print("FESBox_Manager performed a clean exit!")



    # Updates the configuration for each individual channel
    def updateConfiguration(self, Config):

        # Reject current update as the last update was not executed yet
        if self.__update_PARAMETERS:
            return False

        # Transfer configuration to FESBox_Manager
        self.configure(Config)

        # Configure API_Berkelstim
        self.__config()

        # Initiate the update Process
        if self.stimulator.READY:
            self.__update_PARAMETERS = True
        else:
            self.__update_PARAMETERS = False

        # Check if stimulator is ready
        return self.stimulator.READY


    # Updates the stimulation amplitude
    def updateAmplitude(self, I):

        # Reject current update as the last update was not executed yet
        if self.__update_AMPLITUDE:
            return False

        # Boundary Check
        if(I > 100):
            I = 100
        elif(I < 0):
            I = 0

        if not (self.__I == I):
            self.__I_New = I
            self.__update_AMPLITUDE = True

        return True


    # Requests the stimulation amplitude from the stimulator
    def requestAmplitude(self):

        # Reject current update as the last update was not executed yet
        if self.__request_Amplitude:
            return False

        self.__request_Amplitude = True

        return True

    # Updates wheter BOOST - Mode is active or not
    def updateBOOST(self, BOOST):

        # Convert from integer to boolean
        bool_BOOST = (BOOST == 1)

        # Reject current update as the last update was not executed yet
        if self.__update_BOOST:
            return False

        if (not (self.BOOST == bool_BOOST)):
            self.BOOST = bool_BOOST
            self.__update_BOOST = True

        return True

    # Updates the activity of the channels for each muscle
    def updateChannels(self, active_channels, acknowledged = False):

        # Reject current update as the last update was not executed yet
        if self.__update_CHANNELS_ON_OFF or self.stimulator.READY == False:
            return False

        for i in range(8):
            if not (self.__CH_active[i] == active_channels[i]):
                self.__CH_active = active_channels[:] # A copy is needed here
                self.__update_CHANNELS_ON_OFF = True
                self.__acknowledge_ChangeActiveChannels = acknowledged
                break

        return True

    # Applies a test burst of defined length
    def applyTestBurst(self,active_channels, I_percent, duration_ms):

        # Set Amplitude
        if not (self.__I == I_percent):
            self.__I = I_percent
            self.stimulator.set_IntensityPercentage(self.__I)

        # Turn ON stimulation
        self.__CH_active = active_channels
        self.stimulator.set_ActiveChannels(self.__CH_active, send_acknowledged = False)

        # Wait for Burstduration
        time.sleep(duration_ms/1000.0)

        # Turn OFF Stimulation
        self.__CH_active = [False, False, False, False, False, False, False, False]
        self.stimulator.set_ActiveChannels(self.__CH_active, send_acknowledged = True)

        # Set Amplitude to 0
        if not (self.__I == 0):
            self.__I = 0
            self.stimulator.set_IntensityPercentage(self.__I)

    # Returns the current Stimulation Intensity of the Stimulator
    def getStimulationIntensity(self):
        return self.__I

    # Returns the current configuration
    def getStimConfig(self):
        data = {
                "F": self.__F,
                "F_Boost": self.__F_BOOST,
                "Monophasic": self.__Monophasic,
                "PhW": self.__PhW,
                "PhW_Boost": self.__PhW_Boost,
                "IPG": self.__IPG,
                "I_Max": self.__Imax,
                "RampUP": self.__RampUP,
                "RampDOWN": self.__RampDOWN
        }

        return data



if __name__ == '__main__':

    e = threading.Event()

    myFESBox_Manager = FESBox_Manager()
    myFESBox_Manager.start(e)

    myGPIOManager = GPIO_Manager(e)



    try:

        myGPIOManager.setDEBUG_PIN(False)

        while True:


            if myFESBox_Manager.READY:

                time.sleep(4)

                # myFESBox_Manager.stimulator.set_stim_frequency(110)
                myFESBox_Manager.stimulator.set_IntensityPercentage(100)
                #myFESBox_Manager.stimulator.set_ActiveChannels([True, False, False, False, False, False, False, False])



                sleep = 0.5

                start = time.time()
                for i in range(1, 100):
                    #myGPIOManager.setDEBUG_PIN(True)
                    #myFESBox_Manager.stimulator.set_IntensityPercentage(i)
                    #myGPIOManager.setDEBUG_PIN(False)
                    #time.sleep(sleep)

                    myGPIOManager.setDEBUG_PIN(True)
                    myFESBox_Manager.stimulator.set_ActiveChannels([True, False, False, False, False, False, False, False], send_acknowledged = False)
                    time.sleep(sleep)
                    myGPIOManager.setDEBUG_PIN(False)
                    myFESBox_Manager.stimulator.set_ActiveChannels([False, False, False, False, False, False, False, False], send_acknowledged = True)
                    time.sleep(sleep)




                stop = time.time()
                myFESBox_Manager.stimulator.set_IntensityPercentage(0)
                myGPIOManager.setDEBUG_PIN(False)
                print("Average settingtime: "+ str(((stop - start)/100)*1000) + "ms" )






            # if myFESBox_Manager.READY:
            #
            #     myFESBox_Manager.updateAmplitude(51)
            #     print ("1) " + str(time.time()))
            #     myFESBox_Manager.updateChannels([True, False, False, False, False, False, False, False])
            #     time.sleep(1)
            #
            # if myFESBox_Manager.READY:
            #     myFESBox_Manager.updateAmplitude(50)
            #     print ("2) " + str(time.time()))
            #     myFESBox_Manager.updateChannels([False, True, False, False, False, False, False, False])
            #     time.sleep(1)
            #
            # if myFESBox_Manager.READY:
            #     myFESBox_Manager.updateAmplitude(51)
            #     print ("3) " + str(time.time()))
            #     myFESBox_Manager.updateChannels([False, False, True, False, False, False, False, False])
            #     time.sleep(1)
            #
            # if myFESBox_Manager.READY:
            #     myFESBox_Manager.updateAmplitude(50)
            #     print ("4) " + str(time.time()))
            #     myFESBox_Manager.updateChannels([False, False, False, True, False, False, False, False])
            #     time.sleep(1)
            #
            # if myFESBox_Manager.READY:
            #     myFESBox_Manager.updateAmplitude(52)
            #     print ("Toogle BOOST-MODE) " + str(time.time()))
            #     myFESBox_Manager.updateBOOST(not myFESBox_Manager.BOOST)
            #     time.sleep(1)

            time.sleep(0.1)


    except KeyboardInterrupt:
        myFESBox_Manager.disconnect()
        print("Au revoir")