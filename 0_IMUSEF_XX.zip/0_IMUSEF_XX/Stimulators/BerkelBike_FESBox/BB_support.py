#BB_support.py


mask16_8  = 0x00FF
mask32_8  = 0x000000FF




CrcTable = bytearray([
	  0, 94,188,226, 97, 63,221,131,194,156,126, 32,163,253, 31, 65,
	157,195, 33,127,252,162, 64, 30, 95,  1,227,189, 62, 96,130,220,
	 35,125,159,193, 66, 28,254,160,225,191, 93,  3,128,222, 60, 98,
	190,224,  2, 92,223,129, 99, 61,124, 34,192,158, 29, 67,161,255,
	 70, 24,250,164, 39,121,155,197,132,218, 56,102,229,187, 89,  7,
	219,133,103, 57,186,228,  6, 88, 25, 71,165,251,120, 38,196,154,
	101, 59,217,135,  4, 90,184,230,167,249, 27, 69,198,152,122, 36,
	248,166, 68, 26,153,199, 37,123, 58,100,134,216, 91,  5,231,185,
	140,210, 48,110,237,179, 81, 15, 78, 16,242,172, 47,113,147,205,
	 17, 79,173,243,112, 46,204,146,211,141,111, 49,178,236, 14, 80,
	175,241, 19, 77,206,144,114, 44,109, 51,209,143, 12, 82,176,238,
	 50,108,142,208, 83, 13,239,177,240,174, 76, 18,145,207, 45,115,
	202,148,118, 40,171,245, 23, 73,  8, 86,180,234,105, 55,213,139,
	 87,  9,235,181, 54,104,138,212,149,203, 41,119,244,170, 72, 22,
	233,183, 85, 11,136,214, 52,106, 43,117,151,201, 74, 20,246,168,
	116, 42,200,150, 21, 75,169,247,182,232, 10, 84,215,137,107, 53])


# Might compute with the NOT_DLE Bytes if there is any, so be careful
# Only used for message reception because the socket reading function takes care of NOT_DLEs then.
def compute_crc_from_full_message(full_message):
	crc = 0xff
	for i in range (2,(len(full_message)-3)):
		#print (hex(full_message[i]))
		crc = CrcTable[crc ^ int(full_message[i])]

	#print ("computed crc from full message is ",crc)
	return crc
	
# Only used for message generation because the NOT_DLEs are not yet added to the message. 
# cmd_id and parameters only. Not crc or any other bytes
def compute_crc_from_core_message(core_message):
	crc = 0xff
	for i in range (0,(len(core_message))):
		#print (hex(core_message[i]))
		crc = CrcTable[crc ^ int(core_message[i])]

	#print ("computed crc from core message is ",crc," core_message ", binascii.hexlify(core_message))
	return crc
	




def right_array_to_left_array(left,right):
	if(len(left)!=len(right)):
		print("ERROR : right_array_to_left_array unequal length")
		return -1
	for i in range (0,len(right)) :
		left[i] = right[i]
	return left





def append_right_array_to_left(array1, array2):
	for i in range (0,len(array2)) :
		array1.append(array2[i])
	#return array1



def append_right_array_to_left_DLE_SAFE(array1, array2):

	dle = 0x10
	not_dle = 0xAA

	for i in range (0,len(array2)) :
		array1.append(array2[i])
		if array2[i] == dle :
			array1.append(not_dle)
			# print ('not_dle had to be added : left of message : ',str(array1),'  right of message : ',str(array2))

	#return array1








"""*
   *
   * Function taking integers, hexadecimal integers, strings integers
   * and strings hexadecimal integers. It returns the 2 separated bytes
   * which concatenated, gives back the input number but with inverted bytes
   *
   *						BYTE LITTLE ENDIAN OUTPUT 
   *	eg :  0x00ff -> [255,0]    so "0x00ff" needs to be separated to "0xff 0x00"
   *	but not bit wise LITTLE ENDIAN    eg : 0x0005 needs to be separated to "0x05 0x00"
   *	for the communication protocol used with the BerkelBox.
   *			ie : The value "5" of a 16 bits parameter will be "0x05 0x00"
   *
   *		USE swap16 or swap32 to get reversed output : back to Byte Big endian
   *			eg : swap16(uint16_split_8(0x0005)) => "0x00 0x05" [0,5] 
   *
   *""" 




def uint16_split_8(x):
	try :
#        print 'uint16 case 1'
		return [mask16_8 & x,(mask16_8<<8 & x)>>8] 
		# (mask16_8<<8 & x)>>8] could be x>>8 but it wouldn't be as safe
	except TypeError:
		try :
#            print 'uint16 case 2'
			return [mask16_8 & (int(x)),(mask16_8<<8 & (int(x)))>>8]
		except ValueError:
			try :
#                print 'uint16 case 3'
				return [mask16_8 & (int(x,16)),(mask16_8<<8 & (int(x,16)))>>8]
			except ValueError:
				print ('uint16 case 4 ! : ValueError: invalid literal for int() with base 16: ', x)
				return None




def uint32_split_8(x):
	try :
#        print 'uint32 case 1'
		return [mask32_8 & x,(mask32_8<<8 & x)>>8,(mask32_8<<16 & x)>>16,(mask32_8<<24 & x)>>24]
	except TypeError:
		try :
#            print 'uint32 case 2'
			return [mask32_8 & (int(x)),(mask32_8<<8 & (int(x)))>>8,
				(mask32_8<<16 & (int(x)))>>16,(mask32_8<<24 & (int(x)))>>24]
		except ValueError:
			try :
#                print 'uint32 case 3'
				return [mask32_8 & (int(x,16)),(mask32_8<<8 & (int(x,16)))>>8,
					(mask32_8<<16 & (int(x,16)))>>16,(mask32_8<<24 & (int(x,16)))>>24]
			except ValueError:
				print ('uint32 case 4 ! : ValueError: invalid literal for int() with base 16: ', x)
				return None













def swap32(x):
	try:
		return (((x << 24) & 0xFF000000) |
			((x <<  8) & 0x00FF0000) |
			((x >>  8) & 0x0000FF00) |
			((x >> 24) & 0x000000FF))
	except TypeError:
		try :
#            print 'uint32 case 2'
			return (((int(x) << 24) & 0xFF000000) |
				((int(x) <<  8) & 0x00FF0000) |
				((int(x) >>  8) & 0x0000FF00) |
				((int(x) >> 24) & 0x000000FF))
		except ValueError:
			try :
#                print 'uint32 case 3'
				return (((int(x,16) << 24) & 0xFF000000) |
					((int(x,16) <<  8) & 0x00FF0000) |
					((int(x,16) >>  8) & 0x0000FF00) |
					((int(x,16) >> 24) & 0x000000FF))
			except ValueError:
				print ('swap32 case 4 ! : ValueError: invalid literal for int() with base 16: ', x)
				return None




def swap16(x):
	try:
		return (((x <<  8) & 0xFF00) |
			((x >>  8) & 0x00FF))
	except TypeError:
		try :
#            print 'uint32 case 2'
			return (((int(x) <<  8) & 0xFF00) |
				((int(x) >>  8) & 0x00FF))
		except ValueError:
			try :
#                print 'uint32 case 3'
				return (((int(x,16) <<  8) & 0xFF00) |
					((int(x,16) >>  8) & 0x00FF))
			except ValueError:
				print ('swap32 case 4 ! : ValueError: invalid literal for int() with base 16: ', x)
				return None











def mask_byte(x):
	try:
		return mask16_8 & x
	except TypeError:
		try:
			return mask16_8 & int(x)
		except ValueError:
			try:
				return mask16_8 & int(x,16)
			except ValueError:
				print ('mask_byte case 4 ! : ValueError: invalid literal for int() with base 16: ', x)
				return None








# testBit() returns a nonzero result, 2**offset, if the bit at 'offset' is one.
def testBit_bool(int_type, offset):
	mask = 1 << offset
	return bool(int_type & mask)

# testBit() returns a nonzero result, 2**offset, if the bit at 'offset' is one.
def testBit(int_type, offset):
	mask = 1 << offset
	return(int_type & mask)


# setBit() returns an integer with the bit at 'offset' set to 1.
def setBit(int_type, offset):
	mask = 1 << offset
	return(int_type | mask)


# clearBit() returns an integer with the bit at 'offset' cleared.
def clearBit(int_type, offset):
	mask = ~(1 << offset)
	return(int_type & mask)


# toggleBit() returns an integer with the bit at 'offset' inverted, 0 -> 1 and 1 -> 0.
def toggleBit(int_type, offset):
	mask = 1 << offset
	return(int_type ^ mask)

