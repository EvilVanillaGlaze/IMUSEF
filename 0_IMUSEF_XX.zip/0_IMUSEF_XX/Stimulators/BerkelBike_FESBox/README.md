<h1 align="center">BerkelStim Project to make readily available a new direct control Electrical Stimulator.</h1>

# Presentation

The BerkelStim Project provides an Application Programing Interface (API) allowing the use of the new BerkelBox v2.0 as a directly controlled Electrical Stimulator.

This grants the team another option than HASOMED or VIVALTIS for current and future projects.

In order to verify that it works well on your system, it is advised that you run the API on its own first and test the features.

The file BB_manager.py is DEPRECATED and not to be used but can be usefull if the deep understanding of the API is required.
It's the old version (still working) with raw functions instead of the class BERKELSTIM. 

In any case, the main file is API_BerkelStim.py which calls BB_messages.py, and through it, BB_support.py.

### Link to the CAMIN WIKI

You will find more informations about this project on the ADT_STIMBIO wiki page.

http://demarteam.gforge.inria.fr/wiki/doku.php?id=adtstimbio:adtstimbio_start


# Documentation

This communication interface was developped in Python language for Linux. 
It could be adapted to Windows but it would require some changes, it may be done later if required.

To test the BerkelBox stimulators from BerkelBike, it is advised for the first time to redirect the desired channels to an oscilloscope 
in order for the pulses to be delivered against a resistance and to launch API_BerkelStim.py.

<!-- Add Image of the Berkel stimulator and the channels being redirected to the oscilloscope. -->

<!-- <p align="center">
  <img align="center" src="torquemeter_wiring_nidaq.png"/>
</p> -->


## Instructions For Use

(HOW TO)

### User test interface

Here is the interface shown in the terminal when directly running the API_BerkelStim.py :



```python
Select channel by entering channel number.    Press enter without character to toggle stim (current channel). \n\
  '+p' '-p' to increase or decrease the pulse width (current channel).\n\
  '-f' '+f' to increase or decrease the frequency (all channels).\n\
  'p' 'f' 'i' 'r' to precisely define pw, freq, intensity(uA) or ramp (current channel except f).\n\
  'pw' to set the total pulse width (current channel).\n\
  'ii' to set the current intensity percentage (all channels).\n\
  'gi' to get the current intensity percentage (all channels).\n\
  Enter 'exit' to quit the test program.\n\n")
 ```

### Initialization

To control the BerkelStimulator, create the Object BERKELSTIM of the API, it contains everything needed to communicate with it
 and control the Electrical Stimulation.

First you will need to import the API_BerkelStim like so :

```python
from API_BerkelStim import *
```

Then you have to create an object BERKELSTIM, and start the initialization procedure.

The code to initialize the BerkelStim, is :

```python
	BERKEL = BERKELSTIM()

	BERKEL.init_connect()
```

To speed up the connection process, you can call the initialization method with the MAC address of the Berkel Stimulator you want to connect to, 
like the following example :
```python
	BERKEL.init_connect("34:81:F4:36:E4:2D")
```

It might as well resolve problems of auto connection from a known device which can render the stimulator no longer visible on the bluetooth network.

### Exiting the communication

To cleanly exit the communication with the Berkel Stimulator, simply call the clean_exit method. 
It takes care of setting all stimulation channels OFF, stopping the reading thread and disconnecting the communication socket.

```python
	BERKEL.clean_exit()
```


### Using the predefined functions :

You are now able to use the various functionnalities given by the BerkelStim object in order to communicate and control the stimulator.

Here are the predefined commands available :

```python
	BERKEL.toggle_stim_for_1_channel(channel)

	BERKEL.set_stim_for_1_channel(channel,bool_on = False)


	# If used without parameters, it sets all channels to false.
	# Otherwise give a list of 8 bools representing the states you want the channels in.
	# Do so like this : state_of_channels = list(BERKEL.StimOnOff.List_of_8_BOOL_ChannelOn)
	BERKEL.set_stim_for_all_channels(List_of_8_BOOL = None) 


	BERKEL.set_stim_frequency(frequency = 30)


	# Fast modification (~40ms) of the intensity in percent used globally for each channel,
	# resulting respective intensity depends of the intensity range of each channel
	BERKEL.set_stim_direct_intensity_in_percent(percent_intensity = 30)


	# Max intensity range for the specified channel
	BERKEL.set_stim_intensity_in_mA_for_1_channel(channel,intensity = 30)


	BERKEL.set_stim_pw_for_1_channel(channel,pw_positive = 200,pw_inter = 50,pw_negative = 200)


	# Complete pulse duration. Half on Positive Phase, Half on negative Phase, 0 on Intermediate Phase
	BERKEL.set_pw(channel,pw = 400)
	

	BERKEL.set_stim_ramp_for_1_channel(channel,ramp_up = 1,ramp_down = 1)
	
	BERKEL.get_stim_sytem_current()

	BERKEL.init_connect(mac_addr = None, port = None)

	BERKEL.clean_exit()
```

__Channels to be used are between 1 to 8. Both included.__

The channels are internally coded from 0 to 7 in the BerkelStimulator, but since on the device the channels are displayed respectively from 1 to 8, 
in order to keep it clear for users, the channel is decremented internally. 
Be careful then if using the parameters object StimOnOff which contains the list of the booleans representing the states of the channels.

The ranges are :
Frequency : 0.5 to 200Hz
Intensity : 0 to 200mA
Pulse Width : 
Positive Phase/Inter Pulse/Negative Phase 
50/0/50 to 2000/2000/2000 (us)(Micro seconds)

The resolution steps were not found nor experimentally observed. 

### Using direct manual messages : 

NOT RECOMMENDED : While you should be able to do anything with the above features, you can directly modify the various parameters objects contained in
 the BERKELSTIM instance you created. But you will be bypassing the software range of security limitations for the parameters so it might be dangerous to use. 
In any case, you can do it like so :


```python
	BERKEL.SystemCurrentPercent.Byte_CurrentInPercent = percent_intensity;

	BERKEL.generate_and_send_message(BERKEL.SystemCurrentPercent,SET_SYSTEM_CURRENT_PERCENTAGE_CMD_ID)
```



For example, to completely reshape the pulse of desired channel in one call :

```python
	BERKEL.ChannelDataList[desired_channel].Int16_PulsePosWidthInuS = 100;

	BERKEL.ChannelDataList[desired_channel].Int16_PulseInterWidthInuS = 50;

	BERKEL.ChannelDataList[desired_channel].Int16_PulseNegWidthInuS = 100;

	BERKEL.ChannelDataList[desired_channel].Bool_PulsePositivePulseFirst = True;

	BERKEL.ChannelDataList[desired_channel].Int16_RampUp = 1;

	BERKEL.ChannelDataList[desired_channel].Int16_RampDown = 1;

	BERKEL.ChannelDataList[desired_channel].Int32_CurrentInuA += 5000;

	BERKEL.generate_and_send_message(BERKEL.ChannelDataList[desired_channel],SET_STIM_CHAN_PARAMS_CMD_ID)
```

When this type of message is sent, the parameters have to be validated and put on the working memory of the BerkelStimulator. 
Which takes time, around 460 milliseconds instead of under 40 milliseconds for toggling the stimulation on the channels, or setting the global intensity in percent. 

This validation is however done automatically upon acknowledge of the parameter modification from the stimulator. 
You can deactivate this automatic validation by setting the corresponding flag to False, but you will have to do it manually with the dedicated method.

```python
	BERKEL.validate_new_parameters()
```

An other good example would be for the status of stimulation channels, to gain a few messages, 
if you have to set the stimulation for several channels at the same time, you could do the following :

```python
	BERKEL.StimOnOff.List_of_8_BOOL_ChannelOn[0] = True;
	BERKEL.StimOnOff.List_of_8_BOOL_ChannelOn[1] = True;
	BERKEL.StimOnOff.List_of_8_BOOL_ChannelOn[2] = False;
	BERKEL.StimOnOff.List_of_8_BOOL_ChannelOn[3] = False;
	BERKEL.StimOnOff.List_of_8_BOOL_ChannelOn[4] = False;
	BERKEL.StimOnOff.List_of_8_BOOL_ChannelOn[5] = False;
	BERKEL.StimOnOff.List_of_8_BOOL_ChannelOn[6] = False;
	BERKEL.StimOnOff.List_of_8_BOOL_ChannelOn[7] = False;

	BERKEL.generate_and_send_message(BERKEL.StimOnOff,SET_STIM_ON_OFF_CMD_ID)


```
But it is advised to use the dedicated method. Be careful though because the channels are here represented by a list 
beginning at index 0 for channel 1 and finishing at index 7 for channel 8. You can use this functionnality like so :

```python
	state_of_channels = list(BERKEL.StimOnOff.List_of_8_BOOL_ChannelOn)
	state_of_channels[0] = True # For channel 1 QUADRI LEFT to be ON
	state_of_channels[1] = True # For channel 2 QUADRI RIGHT to be ON
	BERKEL.set_stim_for_all_channels(state_of_channels) 
```
<!--
### Example of use
-->
