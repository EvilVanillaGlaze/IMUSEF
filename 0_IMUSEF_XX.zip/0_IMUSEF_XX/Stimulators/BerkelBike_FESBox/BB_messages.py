from Stimulators.BerkelBike_FESBox.BB_support import *

from collections import deque
import binascii

DEBUG = True

# Constants
ES_START_SEND_SETTINGS_CMD_ID 			= 0x32 		# Tx STX02 : Rx STX40
ES_SEND_BT_ADDRESS_CMD_ID 				= 0x38 		# Tx STX02 : Rx STX40

SET_STIM_SYSTEM_CMD_ID 					= 0x20
GET_STIM_SYSTEM_CMD_ID 					= 0x21

SET_STIM_VAR_CMD_ID 					= 0x24		#
GET_STIM_VAR_CMD_ID  					= 0x25 		# NEW UNUSED

SET_STIM_CRANK_SENSE_VAR_CMD_ID 		= 0x28 		# NEW UNUSED
READ_STIM_CRANK_SENSE_VAR_CMD_ID 		= 0x29 		# NEW UNUSED

SET_STIM_ON_OFF_CMD_ID 					= 0x2A		# Activates or deactivates certain channels
SEND_STIM_MEASUREMENTS_CMD_ID 			= 0x2B 		# NEW UNUSED
SEND_CRANK_POSITION_CMD_ID 				= 0x2C 		# NEW UNUSED
MAKE_NEW_PARAMETERS_VALID_CMD_ID 		= 0x2D
SET_SYSTEM_CURRENT_PERCENTAGE_CMD_ID 	= 0x2F		# Sets the global stimulation intensity in percentage

SEND_SYSTEM_CURRENT_CMD_ID 				= 0x30 		#NEW UNUSED
SEND_CHANNEL_CURRENTS_CMD_ID 			= 0x32 		#NEW UNUSED

SET_STIM_PROGRAM_CMD_ID 				= 0x33

SET_EXERCISE_UPDATE_CMD_ID 				= 0x34 		#NEW UNUSED
SET_EXERCISE_VAR_CMD_ID 				= 0x35 		#NEW UNUSED

READ_RTC_CMD_ID 						= 0x46

SET_STIM_CHAN_PARAMS_CMD_ID 			= 0x47		# Sets the stimulation parameters for a particular channel
GET_STIM_CHAN_PARAMS_CMD_ID 			= 0x48 		# NEW UNUSED

SET_STIM_CRANK_SENSE_PARAMS_CMD_ID 		= 0x49 		# NEW UNUSED
GET_STIM_CRANK_SENSE_PARAMS_CMD_ID 		= 0x4A 		# NEW UNUSED

GET_FLASH_STATUS_CMD_ID 				= 0x4C
GET_FLASH_DATA_CMD_ID 					= 0x4D 		# NEW UNUSED
SET_FLASH_DATA_CMD_ID 					= 0x4E 		# NEW UNUSED

SEND_ELECTRODE_TEST_DATA_CMD_ID 		= 0x55 		# NEW UNUSED
SET_ELECTRODE_TEST_SETUP_CMD_ID 		= 0x56 		# NEW UNUSED
GET_ELECTRODE_TEST_SETUP_CMD_ID 		= 0x57 		# NEW UNUSED


#cmdId_unsollicited = 0x4C

dle 	= 0x10			# Start byte of new Message

stx02 	= 0x02			#
stx40 	= 0x40			# Second byte of Message TODO: Meaning?
stx44 	= 0x44			# Second byte of Message TODO: Meaning?

not_dle = 0xAA
etx 	= 0x03			# End byte finishing a Message




# Forward declaration of the global parameters objects
Base_FlashStatusParameters = None
Base_GeneralStatusParameters = None



# Static method to generate a new message
def generate_message(params,cmd_ID,stx=stx44):

	## Initialize the core message as a bytearray, starting with only the cmd_ID
	core_message = bytearray([cmd_ID])

	if params != None:
		## Adding parameters to the core message if there is any to add.
		append_right_array_to_left(core_message, params.get_parameters_as_byte_list())

	## Computing and adding the CRC from the core message, to the core message.
	core_message.append((compute_crc_from_core_message(core_message)))

	## Creating the message header, without the cmd_id which is already in place.
	message = bytearray([dle, stx])

	## Adding to the message header just created the core of the message with the crc already computed
	## Only the right array is checked for DLE bytes, so the first byte (DLE) is not going to be seen.
	append_right_array_to_left_DLE_SAFE(message,core_message)

	## Creating the message ending, without the crc which is already in place.
	message_ending = bytearray([dle, etx])

	## Adding to the message header just created the core of the message with the crc already computed
	append_right_array_to_left(message,message_ending)

	# print("From generate_message : Full message is as hex : "+str(binascii.hexlify(message)))

	return message






	# TODO: Remove?
	# parameter_list = []

	# if params != None:
	# 	parameter_list = params.get_parameters_as_byte_list()
	# else:
	# 	#print("None Parameters")
	# 	pass

	# tmp_crc = 0xff

	# tmp_message = bytearray([dle, stx, cmd_ID])
	# # print("tmp_message is, as hex : ",binascii.hexlify(tmp_message))


	# if (len(parameter_list) != 0):
	# 	append_right_array_to_left_DLE_SAFE(tmp_message,parameter_list)
	# 	# print("tmp_message is, with params as hex : ",binascii.hexlify(tmp_message))


	# end_of_msg=[ tmp_crc, dle, etx]

	# append_right_array_to_left(tmp_message,end_of_msg)
	# # print("tmp_message is, with end_of_msg as hex : ",binascii.hexlify(tmp_message))


	# tmp_message[len(tmp_message)-3] = compute_crc_from_full_message(tmp_message)

	# if tmp_message[len(tmp_message)-3] == dle :
	# 	print("crc was equal to dle so not_dle was added")
	# 	tmp_message[len(tmp_message)-2] = not_dle
	# 	tmp_message[len(tmp_message)-1] = dle
	# 	tmp_message.append(etx)


	# #print("generated final message is, as hex : ",binascii.hexlify(tmp_message))

	# return tmp_message




########################################################################################################################
#
#	PARAMETERS CLASSES
#
########################################################################################################################


# GeneralStatusParameters
class GeneralStatusParameters :
        
	BadCrcCount = 0;
	BadLengthCount = 0;
	UnknownMessageTypeCount = 0;
	UnexpectedValueCount = 0;
	BadDataDecodeCount = 0;
	UnexpectedMessageCount = 0;

	CrankPosition = 0;
	SystemCurrent = 0; # % of global intensity
	ChannelCurrents = [0,0,0,0, 0,0,0,0]; # % of intensity by channel
	#DebugStringChars = _DebugStringChars;
	#StimMeasurements = _StimMeasurements;
	#ElectrodeTestData = _ElectrodeTestData;

	#UnsolicitedIncommingMessageCollection.Add(new CrankPositionIncommingMessage(_CrankPosition));
	#UnsolicitedIncommingMessageCollection.Add(new SystemCurrentIncommingMessage(_SystemCurrent));
	#UnsolicitedIncommingMessageCollection.Add(new ChannelCurrentsIncommingMessage(_ChannelCurrents));
	#UnsolicitedIncommingMessageCollection.Add(new DebugStringIncommingMessage(_DebugStringChars));
	#UnsolicitedIncommingMessageCollection.Add(new StimMeasurementsExParametersIncommingMessage(_StimMeasurements));
	#UnsolicitedIncommingMessageCollection.Add(new SendElectrodeTestDataIncommingMessage(_ElectrodeTestData));

	all_parameters_bytes_list = []


	# //******************************************************
	def get_parameters_as_byte_list(self):
		#parameters not to be given for outgoing messages
		self.all_parameters_bytes_list = []
		print("GeneralStatusParameters message creation len(param) = "+str(len(self.all_parameters_bytes_list)))
		return self.all_parameters_bytes_list




Base_GeneralStatusParameters = GeneralStatusParameters()


# FlashStatusParameters
class FlashStatusParameters :
		
	Flash_Status_ErrorCode = "NoError"
	Flash_Status_WordLocked = True
	Flash_Status_FlashLocked = True
	Flash_Status_Bank = True
	Flash_Status_Busy = True

	all_parameters_bytes_list = []


	# //******************************************************
	def get_parameters_as_byte_list(self):
		#parameters not to be given for outgoing messages
		self.all_parameters_bytes_list = []
		print("FlashStatusParameters message creation len(param) = "+str(len(self.all_parameters_bytes_list)))
		return self.all_parameters_bytes_list


Base_FlashStatusParameters = FlashStatusParameters()



# SystemCurrentPercentage
class SystemCurrentPercentage :

	Byte_CurrentInPercent = 0x00

	all_parameters_bytes_list = []


	# //******************************************************
	def get_parameters_as_byte_list(self):
		#reset bytes list and recreate
		self.all_parameters_bytes_list = []
		self.all_parameters_bytes_list.append(mask_byte(self.Byte_CurrentInPercent))

		return self.all_parameters_bytes_list


# StimProgramsParameters
class StimProgramsParameters :

	Byte_ProgramNumber = 0x00
	Bool_Valid= False
	List_4_Byte_StimPrograms = [0x00,0x00,0x00,0x00]

	all_parameters_bytes_list = []


	# //******************************************************
	def get_parameters_as_byte_list(self):
		#reset bytes list and recreate
		self.all_parameters_bytes_list = []

		self.all_parameters_bytes_list.append(mask_byte(self.Byte_ProgramNumber))
		self.all_parameters_bytes_list.append(mask_byte(self.Bool_Valid))
		
		append_right_array_to_left(self.all_parameters_bytes_list,self.List_4_Byte_StimPrograms)
		

		return self.all_parameters_bytes_list



# StimSystemParameters
class StimSystemParameters :

	#SensorTypeAsByte
	# 0x00 ... None
	# 0x01 ... Crank
	# 0x02 ... Timeing
	# 0x03 ... Exercise
	# 0x04 ... PcStim
	# 0x05 ... ElectrodeTest
	Byte_SensorTypeAsByte = 0x04

	List_14_char_Padding = [0x00,0x00,0x00,0x00,0x00,0x00,0x00, 0x00,0x00,0x00,0x00,0x00,0x00,0x00]
	List_3_char_FirmwareVersion = [0x00,0x00,0x00]#[0x22,0x3f,0x22]
	List_3_char_PcbVersion =  [0x00,0x00,0x00]#[0x22,0x3f,0x22]
	Int16_Crc = 0

	all_parameters_bytes_list = []

	# Returns the current parameters as a byte_list
	def get_parameters_as_byte_list(self):
		#reset bytes list and recreate
		self.all_parameters_bytes_list = []

		self.all_parameters_bytes_list.append(mask_byte(self.Byte_SensorTypeAsByte))
		
		append_right_array_to_left(self.all_parameters_bytes_list,self.List_14_char_Padding)
		append_right_array_to_left(self.all_parameters_bytes_list,self.List_3_char_FirmwareVersion)
		append_right_array_to_left(self.all_parameters_bytes_list,self.List_3_char_PcbVersion)
		append_right_array_to_left(self.all_parameters_bytes_list,uint16_split_8((self.Int16_Crc)))
		

		return self.all_parameters_bytes_list




# Class for the following global parameter
# - Frequency
# - Current Step per button press in percent
# - Manual Current Step in uA -> ???? TODO: Explain
# - Manual Current Maximum in uA -> ??? TODO: Explain
# - Maximal Compliance Voltage of the Stimulator
class StimVarParameters :

	Byte_Frequency = 0
	Byte_CurrentStepAsPercentage = 0
	Int32_ManualCurrentStepInuA = 0
	Int32_MaxManualCurrentStepInuA = 0
	Byte_MaxVoltage = 0
	Int16_Crc = 0

	all_parameters_bytes_list = []


	# Returns the current parameters as a byte_list
	def get_parameters_as_byte_list(self):
		#reset bytes list and recreate
		self.all_parameters_bytes_list = []

		self.all_parameters_bytes_list.append(mask_byte(self.Byte_Frequency))
		self.all_parameters_bytes_list.append(mask_byte(self.Byte_CurrentStepAsPercentage))
		
		append_right_array_to_left(self.all_parameters_bytes_list,uint32_split_8((self.Int32_ManualCurrentStepInuA)))
		append_right_array_to_left(self.all_parameters_bytes_list,uint32_split_8((self.Int32_MaxManualCurrentStepInuA)))
		
		self.all_parameters_bytes_list.append(mask_byte(self.Byte_MaxVoltage))
		
		append_right_array_to_left(self.all_parameters_bytes_list,uint16_split_8((self.Int16_Crc)))
		
		return self.all_parameters_bytes_list





# StimChannelParameters
class StimChannelParameters :

	Byte_Channel = 0						# StimulationChannel -1; e.g. Channel 1 = 0; Channel 8 = 7
	Bool_BurstModeEnable = False			# Not functional
	Int16_BurstFrequency = 0				# Not functional
	Int16_BurstWidthinuS = 0				# Not functional
	Int16_PulsePosWidthInuS = 0				# Positive Phasewidth of Pulse in [us]; Range: 50 - 2000 us
	Int16_PulseInterWidthInuS = 0			# Time between the two Phases in [us]; Range: 25 - 2000 us
	Int16_PulseNegWidthInuS = 0				# Negative Phasewidth of Pulse in [us]; Range: 50 - 2000 us
	Bool_PulsePositivePulseFirst = False 	# Defines wheter a Pulse should be delivered Anodic or Cathodic first
	Int16_RampUp = 1						# Ramping up for stimulation intensity: Number of pulses until reached desired Amplitude. Attention!!! Depends on F; Minimum Value = 1
	Int16_RampDown = 1						# Ramping down for stimulation intensity: Number of pulses until 0uA. Attention!!! Depends on F; Minimum Value = 1
	Int32_CurrentInuA = 0					# Maximal stimulation intensity in [uA]: 0 - 200000 uA
	Int32_MaxCurrentInuA = 0				# Not functional
	Bool_On = True

	all_parameters_bytes_list = []


	# Returns the current parameters as a byte_list
	def get_parameters_as_byte_list(self):


		self.all_parameters_bytes_list = []

		self.all_parameters_bytes_list.append(mask_byte(self.Byte_Channel))
		self.all_parameters_bytes_list.append(mask_byte(self.Bool_BurstModeEnable))
		
		append_right_array_to_left(self.all_parameters_bytes_list,uint16_split_8((self.Int16_BurstFrequency)))
		append_right_array_to_left(self.all_parameters_bytes_list,uint16_split_8((self.Int16_BurstWidthinuS)))
		append_right_array_to_left(self.all_parameters_bytes_list,uint16_split_8((self.Int16_PulsePosWidthInuS)))
		append_right_array_to_left(self.all_parameters_bytes_list,uint16_split_8((self.Int16_PulseInterWidthInuS)))
		append_right_array_to_left(self.all_parameters_bytes_list,uint16_split_8((self.Int16_PulseNegWidthInuS)))
		
		self.all_parameters_bytes_list.append(mask_byte(self.Bool_PulsePositivePulseFirst))

		append_right_array_to_left(self.all_parameters_bytes_list,uint16_split_8((self.Int16_RampUp)))
		append_right_array_to_left(self.all_parameters_bytes_list,uint16_split_8((self.Int16_RampDown)))
		append_right_array_to_left(self.all_parameters_bytes_list,uint32_split_8((self.Int32_CurrentInuA)))
		append_right_array_to_left(self.all_parameters_bytes_list,uint32_split_8((self.Int32_MaxCurrentInuA)))
		self.all_parameters_bytes_list.append(mask_byte(self.Bool_On))

		return self.all_parameters_bytes_list




# StimOnOffParameters
class StimOnOffParameters :

	List_of_8_BOOL_ChannelOn = [False,False,False,False,False,False,False,False]

	all_parameters_bytes_list = []


	# //******************************************************
	def get_parameters_as_byte_list(self):
		#reset bytes list and recreate
		self.all_parameters_bytes_list = []

		ChannelOnAsByte = 0x00
		Mask = 0x01
		for i in range (0,len(self.List_of_8_BOOL_ChannelOn)):

			if (self.List_of_8_BOOL_ChannelOn[i]):

				ChannelOnAsByte |= Mask;


			Mask <<= 1;

		tmp_masked_byte = mask_byte(ChannelOnAsByte)

		self.all_parameters_bytes_list.append(tmp_masked_byte)
		

		return self.all_parameters_bytes_list



# HANDLE RESPONSE TO MESSAGES FUNCTIONS
def handle_ES_START_SEND_SETTINGS(message):
	#print("handle_ES_START_SEND_SETTINGS completed \n")
	pass


def handle_GET_STIM_SYSTEM(message):
	#print("handle_GET_STIM_SYSTEM completed \n")
	pass


def handle_ES_SEND_BT_ADDRESS(message):
	#print("handle_ES_SEND_BT_ADDRESS completed \n")
	pass


def handle_READ_RTC(message):
	#print("handle_READ_RTC completed \n")
	pass


def handle_SET_SYSTEM_CURRENT_PERCENTAGE(message):
	#print("handle_SET_SYSTEM_CURRENT_PERCENTAGE completed \n")
	pass


def handle_SEND_SYSTEM_CURRENT(message):
	global Base_GeneralStatusParameters
	global_system_current = message[3] 
	if DEBUG: print("handle_SEND_SYSTEM_CURRENT : New value for global intensity :",global_system_current)
	Base_GeneralStatusParameters.SystemCurrent = global_system_current
	#print("handle_SEND_SYSTEM_CURRENT completed \n")
	#pass
    

#def handle_SEND_CHANNEL_CURRENTS(message):
	#print("handle_SEND_CHANNEL_CURRENTS completed \n")
	#pass


def handle_SET_STIM_PROGRAM_PARAMS(message):
	#print("handle_SET_STIM_PROGRAM_PARAMS completed \n")
	pass


def handle_SET_STIM_SYSTEM_PARAMS(message):
	#print("handle_SET_STIM_SYSTEM_PARAMS completed \n")
	pass


def handle_SET_STIM_VAR_PARAMS(message):
	#print("handle_SET_STIM_VAR_PARAMS completed \n")
	pass


def handle_SET_STIM_CHAN_PARAMS(message):
	#print("handle_SET_STIM_CHAN_PARAMS completed \n")
	pass


def handle_MAKE_NEW_PARAMETERS_VALID(message):
	#print("handle_MAKE_NEW_PARAMETERS_VALID completed \n")
	pass


def handle_SET_STIM_ON_OFF(message):
	#print("handle_SET_STIM_ON_OFF completed \n")
	pass


def handle_GET_FLASH_STATUS(message):
	global Base_FlashStatusParameters
	ErrorCode = "NoError"
	WordLocked = False
	FlashLocked = False
	Bank = False
	Busy = False

	# print("\n Base Flash Status was : ",
	# 	Base_FlashStatusParameters.Flash_Status_ErrorCode,
	# 	Base_FlashStatusParameters.Flash_Status_WordLocked,
	# 	Base_FlashStatusParameters.Flash_Status_FlashLocked,
	# 	Base_FlashStatusParameters.Flash_Status_Bank,
	# 	Base_FlashStatusParameters.Flash_Status_Busy)

	byte_parameters = message[3] 
	#print("byte_parameters is ",byte_parameters)


	if byte_parameters >> 4 == 0:
		ErrorCode = "NoError"
	else:
		ErrorCode = str(byte_parameters >> 4)


	WordLocked = testBit_bool(byte_parameters, 3)

	FlashLocked = testBit_bool(byte_parameters, 2)

	Bank = testBit_bool(byte_parameters, 1)

	Busy = testBit_bool(byte_parameters, 0)

	Base_FlashStatusParameters.Flash_Status_ErrorCode = ErrorCode
	Base_FlashStatusParameters.Flash_Status_WordLocked = WordLocked
	Base_FlashStatusParameters.Flash_Status_FlashLocked = FlashLocked
	Base_FlashStatusParameters.Flash_Status_Bank = Bank
	Base_FlashStatusParameters.Flash_Status_Busy = Busy

	# print('BerkelBike_FESBox Base Flash Status is: ',ErrorCode,WordLocked,
	# 	FlashLocked,Bank,Busy)
	if DEBUG: print('BerkelBike_FESBox Base Flash Status is: '+ str(ErrorCode)+ str(WordLocked)\
		+ str(FlashLocked)+ str(Bank)+ str(Busy)+'\n')















# Handles for received messages
def handle_data(data):

	if data is None:
		if DEBUG: print("BB_messages: ERROR - Can not handle empty data!")
		return

	message = data
	# print("Message received and being handled : "+str(binascii.hexlify(message)))

	current_stx = message[1]
	current_id = message[2]

	# Compute and Check CRC
	crc = compute_crc_from_full_message(message)
	MSG_CRC = message[len(message)-3]
	if crc != MSG_CRC:
		if DEBUG: print("BB_messages: ERROR handling data : UNVALID CRC")
		return


	if current_id == GET_FLASH_STATUS_CMD_ID:
		#print("GET_FLASH_STATUS_CMD_ID comparison valid")
		handle_GET_FLASH_STATUS(message)

	elif current_id == ES_START_SEND_SETTINGS_CMD_ID and current_stx == stx40:
		#print("ES_START_SEND_SETTINGS_CMD_ID comparison valid")
		handle_ES_START_SEND_SETTINGS(message)

	elif current_id == GET_STIM_SYSTEM_CMD_ID:
		#print("GET_STIM_SYSTEM_CMD_ID comparison valid")
		handle_GET_STIM_SYSTEM(message)

	elif current_id == ES_SEND_BT_ADDRESS_CMD_ID and current_stx == stx40:
		#print("ES_SEND_BT_ADDRESS_CMD_ID comparison valid")
		handle_ES_SEND_BT_ADDRESS(message)
	elif current_id == READ_RTC_CMD_ID:
		#print("READ_RTC_CMD_ID comparison valid")
		handle_READ_RTC(message)
	## Acknowledged intensity percentage being set to the stimulator
	elif current_id == SET_SYSTEM_CURRENT_PERCENTAGE_CMD_ID:
		if DEBUG: print("SET_SYSTEM_CURRENT_PERCENTAGE_CMD_ID comparison valid")
		# print("Received message :"+str(binascii.hexlify(message)))
		handle_SET_SYSTEM_CURRENT_PERCENTAGE(message)

	## Request for intensity percentage currently used by the stimulator received
	elif current_id == SEND_SYSTEM_CURRENT_CMD_ID:
		if DEBUG: print("SEND_SYSTEM_CURRENT_CMD_ID comparison valid")
		handle_SEND_SYSTEM_CURRENT(message)

	elif current_id == SET_STIM_PROGRAM_CMD_ID:
		#print("SET_STIM_PROGRAM_CMD_ID comparison valid")
		handle_SET_STIM_PROGRAM_PARAMS(message)
	elif current_id == SET_STIM_SYSTEM_CMD_ID:
		#print("SET_STIM_SYSTEM_CMD_ID comparison valid")
		handle_SET_STIM_SYSTEM_PARAMS(message)

	elif current_id == SET_STIM_VAR_CMD_ID:
		#print("SET_STIM_VAR_CMD_ID comparison valid")
		handle_SET_STIM_VAR_PARAMS(message)
	elif current_id == SET_STIM_CHAN_PARAMS_CMD_ID:
		#print("SET_STIM_CHAN_PARAMS_CMD_ID comparison valid")
		handle_SET_STIM_CHAN_PARAMS(message)

	elif current_id == MAKE_NEW_PARAMETERS_VALID_CMD_ID:
		#print("MAKE_NEW_PARAMETERS_VALID_CMD_ID comparison valid")
		handle_MAKE_NEW_PARAMETERS_VALID(message)

	elif current_id == SET_STIM_ON_OFF_CMD_ID:
		#print("SET_STIM_ON_OFF_CMD_ID comparison valid")
		handle_SET_STIM_ON_OFF(message)
	else:
		print("No handler implemented for this command. Comparison invalid")
		

