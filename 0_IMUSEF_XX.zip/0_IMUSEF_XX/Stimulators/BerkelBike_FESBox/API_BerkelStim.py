#!/usr/bin/env python
"""
API_BerkelStim   -- use in proximity of a BerkelBike Stimulator v2

Communication Layer to control the BerkelBike FES-Box

@author: Ronan LE GUILLOU and Martin Schmoll

WARNING: Use with external USB-Dongle and switch off Power-saving mode.
         Onboard Bluetooth is not working properly in combination with WIFI.
WARNING: Developed for little endian. Refer to BB_support bits manipulation functions to change it.

"""


import Stimulators.BerkelBike_FESBox.BB_messages as BB_messages
import bluetooth
import os, sys
import time
import threading

DEBUG = True



class BERKELSTIM(object):


    def __init__(self):

        # Settings
        self.MAC_Address = None #"34:81:F4:36:E4:2D" // "88:83:22:FD:8A:43"
        self.COM_Port = 6
        self.__maxMessageLength = 1000

        # Parameter Limitations
        self.__Frequency_Min = 0.5			# [Hz]
        self.__Frequency_Max = 500.0 		# [Hz]   -> TODO: Change to 120

        self.__Intensity_Min = 0.0			# [mA]
        self.__Intensity_Max = 200.0		# [mA]

        self.__PhaseWidth_Min = 50.0  		# [us]
        self.__PhaseWidth_Max = 2000.0  	# [us]

        self.__InterPhaseGap_Min = 0.0  	# [us]
        self.__InterPhaseGap_Max = 2000.0  	# [us]


        # Communication
        self.client_socket= bluetooth.BluetoothSocket( bluetooth.RFCOMM )

        # Messages
        self.SystemCurrentPercent = BB_messages.SystemCurrentPercentage()
        self.StimProgramData = BB_messages.StimProgramsParameters()
        self.StimSystemData = BB_messages.StimSystemParameters()
        self.StimVarParams = BB_messages.StimVarParameters()									#
        self.ChannelDataList = [ BB_messages.StimChannelParameters() for i in range(8) ]		# Create the 8 channels Data List
        self.StimOnOff = BB_messages.StimOnOffParameters()

        # Flags
        self.flag_read = False
        self.flag_quit = False
        self.READY = False
        
        ##Flag specifying the automatic send of a validate_new_parameters message
        ## after an acknowledge from parameters changed
        self.automatic_params_validation = True

        # Messages
        self.__waitingForResponse = threading.Event()
        self.__waitingTimeOut = 2.0
        self.__maxRetrySending = 3
        self.__waitingMessage = None
        self.__responseMessage = None

        self.__DEBUG_START = 0.00000;
        self.__n_ack = 0
        self.__n = 0

        # Initialize basic Parameter
        self.StimVarParams.Byte_Frequency = 30   						## TODO ??? Maybe set right away
        self.StimVarParams.Byte_CurrentStepAsPercentage = 3  			## Defines the size of the steps for each button push 3 for 33 steps
        self.StimVarParams.Int32_ManualCurrentStepInuA = 10000  		## No impact
        self.StimVarParams.Int32_MaxManualCurrentStepInuA = 150000  	## No impact
        self.StimVarParams.Byte_MaxVoltage = 160



    # Starts the Thread reading data
    def start_reading_thread(self):
        self.reading_thread = threading.Thread(name='API_BerkelStim_Read_Thread', target=self.__read_from_socket)
        self.reading_thread.daemon = True
        self.reading_thread.start()


    # Tries to connect to the stimulator
    def connect(self):

        try:
            self.client_socket.connect((self.MAC_Address, self.COM_Port))

            # Clear Old states
            #self.reInit()
            #self.MessageQueue.clear()
            #self.init_stim_sequence2()

        except bluetooth.btcommon.BluetoothError as bt_error:
            if DEBUG: print ("API_BerkelStim: Caught BluetoothError : "+str(bt_error))

            # try to Disconnect the current device
            os.system("bt-device --disconnect " + str(self.MAC_Address))
            self.client_socket = bluetooth.BluetoothSocket(bluetooth.RFCOMM)
            return False

        except Exception as err:
            if DEBUG: print("API_BerkelStim: " + str(err))

            return False

        return True



    # Initializes and configures the Stimulator
    def init(self):
        self.flag_read = True
        self.__configureStimulator()

        if DEBUG: print('API_Berkelstim: Stimulator configured successfully:' + str(self.READY) + '\n\n')


    # Initialises and configures the stimulator
    def __configureStimulator(self):

        init_successful = True

        start = time.time()

        # 0 - Get the current Flash Status of the stimulator
        outgoing_message = BB_messages.generate_message(None, BB_messages.GET_FLASH_STATUS_CMD_ID)
        response = self.__send_acknowledged(outgoing_message)

        if response is None:
            self.READY = False
            return

        BB_messages.handle_data(response)

        if DEBUG: print("0) " + str((time.time() - start)*1000))
        start = time.time()


        # 1 - TODO: Describe
        outgoing_message = BB_messages.generate_message(None, BB_messages.ES_START_SEND_SETTINGS_CMD_ID, BB_messages.stx02)
        response = self.__send_acknowledged(outgoing_message)

        if response is None:
            self.READY = False
            return

        BB_messages.handle_data(response)

        if DEBUG: print("1) " + str((time.time() - start)*1000))
        start = time.time()


        # 2 - TODO: Describe
        outgoing_message = BB_messages.generate_message(None,BB_messages.GET_STIM_SYSTEM_CMD_ID)
        response = self.__send_acknowledged(outgoing_message)

        if response is None:
            self.READY = False
            return

        BB_messages.handle_data(response)

        if DEBUG: print("2) " + str((time.time() - start)*1000))
        start = time.time()

        # 3 - TODO: Describe
        outgoing_message = BB_messages.generate_message(None, BB_messages.ES_SEND_BT_ADDRESS_CMD_ID, BB_messages.stx02)
        response = self.__send_acknowledged(outgoing_message)

        if response is None:
            self.READY = False
            return

        BB_messages.handle_data(response)

        if DEBUG: print("3) " + str((time.time() - start)*1000))
        start = time.time()

        # 6 - TODO: Describe
        outgoing_message = BB_messages.generate_message(None, BB_messages.READ_RTC_CMD_ID)
        response = self.__send_acknowledged(outgoing_message)

        if response is None:
            self.READY = False
            return

        BB_messages.handle_data(response)

        if DEBUG: print("6) " + str((time.time() - start)*1000))
        start = time.time()

        # 7 - Set global system current in percent
        self.SystemCurrentPercent.Byte_CurrentInPercent = 0x00;
        outgoing_message = BB_messages.generate_message(self.SystemCurrentPercent, BB_messages.SET_SYSTEM_CURRENT_PERCENTAGE_CMD_ID)
        response = self.__send_acknowledged(outgoing_message)

        if response is None:
            self.READY = False
            return

        BB_messages.handle_data(response)

        if DEBUG: print("7) " + str((time.time() - start)*1000))
        start = time.time()

        # 8 SET_STIM_PROGRAM_CMD_ID has to be sent is a program is to be selected.
        # But it will block direct PC control if sent. By default the BB is on working memory.
        # self.StimProgramData.Byte_ProgramNumber = 0
        # self.StimProgramData.Bool_Valid = True
        # outgoing_message = BB_messages.generate_message(self.StimProgramData,BB_messages.SET_STIM_PROGRAM_CMD_ID)
        # response = self.__send_acknowledged(outgoing_message)
        # BB_messages.handle_data(response)
        # if response is None:
        # 	init_successful = False

        # 9 - Set Control Mode
        # SensorTypeAsByte
        # 0x00 ... None
        # 0x01 ... crank
        # 0x02 ... timing
        # 0x03 ... exercise
        # 0x04 ... PcStim
        # 0x05 ... ElectrodeTest
        self.StimSystemData.Byte_SensorTypeAsByte = 0x04
        outgoing_message = BB_messages.generate_message(self.StimSystemData, BB_messages.SET_STIM_SYSTEM_CMD_ID)
        response = self.__send_acknowledged(outgoing_message)

        if response is None:
            self.READY = False
            return

        BB_messages.handle_data(response)

        if DEBUG: print("9) " + str((time.time() - start)*1000))
        start = time.time()

        # 10 - Set stimulation frequency and other global parameters
        outgoing_message = BB_messages.generate_message(self.StimVarParams, BB_messages.SET_STIM_VAR_CMD_ID)
        response = self.__send_acknowledged(outgoing_message)

        if response is None:
            self.READY = False
            return

        BB_messages.handle_data(response)

        #self.validate_new_parameters()

        if DEBUG: print("10) " + str((time.time() - start)*1000))
        start = time.time()

        # # 10a - Validate Parameters
        # outgoing_message = BB_messages.generate_message(None, MAKE_NEW_PARAMETERS_VALID_CMD_ID)
        # response = self.__send_acknowledged(outgoing_message)
        # BB_messages.handle_data(response)
        # if response is None:
        # 	init_successful = False
        # if DEBUG: print("10a) " + str((time.time() - start) * 1000))
        # start = time.time()


        # 11 - 18) Set Pulse and Stimulation Parameter for each channel
        for channel in range(8):
            outgoing_message = BB_messages.generate_message(self.ChannelDataList[channel], BB_messages.SET_STIM_CHAN_PARAMS_CMD_ID)
            response = self.__send_acknowledged(outgoing_message)

            if response is None:
                self.READY = False
                return

            BB_messages.handle_data(response)

            if DEBUG: print(str(11+channel)+") " + str((time.time() - start) * 1000))
            start = time.time()

        # 19 - Validate Parameters
        outgoing_message = BB_messages.generate_message(None, BB_messages.MAKE_NEW_PARAMETERS_VALID_CMD_ID)
        response = self.__send_acknowledged(outgoing_message)

        if response is None:
            self.READY = False
            return

        BB_messages.handle_data(response)

        if DEBUG: print("19) " + str((time.time() - start) * 1000))
        start = time.time()



        # 20 - Switch OFF all stimulation channels
        self.StimOnOff.List_of_8_BOOL_ChannelOn = [False, False, False, False, False, False, False, False];
        outgoing_message = BB_messages.generate_message(self.StimOnOff, BB_messages.SET_STIM_ON_OFF_CMD_ID)
        response = self.__send_acknowledged(outgoing_message)

        if response is None:
            self.READY = False
            return

        BB_messages.handle_data(response)

        if DEBUG: print("20) " + str((time.time() - start)*1000))
        start = time.time()



        # 21 - Set socket - timeout
        #self.client_socket.settimeout(1)		# Allows fast detection when stimulator is not connected anymore
        self.READY = init_successful
        if DEBUG: print("API_Berkelstim: Init successful: " + str(self.READY))
        start = time.time()




    # Validates new Parameters
    # Only Commands "SET_STIM_CHAN_PARAMS_CMD_ID" and "SET_STIM_VAR_CMD_ID" need validation
    def validate_new_parameters(self):
        self.__generate_and_send_message(None, BB_messages.MAKE_NEW_PARAMETERS_VALID_CMD_ID)



    # Sends a message to the stimulator and waits for a response Message (Attention: blocking)
    def __send_acknowledged(self, msg):

        if self.__waitingForResponse.isSet():
            return None

        result = None

        n = 1

        self.__waitingMessage = msg
        self.__waitingForResponse.set()
        self.__responseMessage = None


        while n <= self.__maxRetrySending and result is None:

            # Send Message
            try:
                self.client_socket.send(bytes(msg))
            except Exception as error:
                if DEBUG: print("API-Berkelstim: SendingError: " + str(error))
                break


            # Wait for response
            start = time.time()
            while (time.time() - start) < self.__waitingTimeOut:

                # Response - hurray
                if self.__responseMessage is not None:
                    result = self.__responseMessage
                    break


                time.sleep(0.001)

            if result is not None:
                break

            if DEBUG: print("API_BerkelStim: Resending Message (Try=" + str(n) + ")")
            n += 1


        # Clean up
        self.__waitingMessage = None
        self.__waitingForResponse.clear()
        self.__responseMessage = None

        if result is None:
            if DEBUG: print("API_BerkelStim: ERROR: Didn't receive reply!")
            self.__connectionLost()

        return result

    # Called to clean up after the connection is detected to be lost
    def __connectionLost(self):
        self.flag_read = False
        self.READY = False

        # try to Disconnect the current device
        os.system("bt-device --disconnect " + str(self.MAC_Address))
        self.client_socket = bluetooth.BluetoothSocket(bluetooth.RFCOMM)


    # Reads the next message from the bluetooth socket
    def __readMessage(self):

        # Read new Message
        data = bytearray()

        while len(data) < self.__maxMessageLength:

            new_byte = ord(self.client_socket.recv(1))
            data.append(new_byte)

            # Data after Header
            if len(data) >= 3:

                if data[len(data) - 2] == BB_messages.dle:

                    ## Message Ending test condition
                    if data[len(data) - 1] == BB_messages.etx:
                        ## If end detected, return message data
                        # print("From read_message : Full message is as hex : "+str(binascii.hexlify(data)))
                        break

                    ## Message DLE/NOT_DLE Protocol test condition
                    if data[len(data) - 1] == BB_messages.not_dle:
                        ## Flush not_dle byte and keep on going
                        del data[len(data) - 1]
                        # print('NOT_DLE was detected in a message. Not adding its byte into the message.')
                        pass

                    ## Message Header test condition
                    elif data[len(data) - 1] == BB_messages.stx44 or data[len(data) - 1] == BB_messages.stx40:
                        ## Beginning of the message, keeping the byte
                        pass

                    ## Invalid state, DLE/NOT_DLE Protocol was not followed.
                    else:
                        # del data[len(data)-1]
                        # print("ERROR reading message : Invalid state,\
                        # Unknown stx or DLE/NOT_DLE Protocol was not followed by BerkelBike_FESBox")
                        pass

                ## Normal byte, not a dle byte, so proceed as normal.
                else:
                    pass

        return data

    # Validates the Header of the received Message
    def __validateMessage(self, data):

        # print("printing Header ",(data[0]),(data[1]),(data[2]))
        # print("stx02=",stx02,"  stx44=",stx44)
        # print("current cmd id is",data[2])

        if len(data) < 3:
            if DEBUG: print("WARNING : ERROR reading message : handle_prefix data message length is invalid")
            return False

        if (data[0] == BB_messages.dle and ((data[1] == BB_messages.stx44) or (data[1] == BB_messages.stx40))):
            return True

        else:
            if DEBUG: print("ERROR reading message : First two Bytes invalid")
            # no recognised message error
            return False

    # Reads from socket. If timeout occurs stimulator is gone
    def __read_from_socket(self):

        while not self.flag_quit:

            if self.flag_read:

                try:
                    data = self.__readMessage()

                    if self.__validateMessage(data):



                        # Anybody waiting for a response?
                        if   self.__waitingForResponse.isSet() and \
                            (data[2] == self.__waitingMessage[2] and \
                            (data[1] == self.__waitingMessage[1] or data[1] == BB_messages.stx40)):

                            # Deliver Message and reset waiting
                            self.__responseMessage = data
                            self.__waitingMessage = None
                            self.__waitingForResponse.clear()

                            #print ("Received Message: " + str((time.time() - self.__DEBUG_START) * 1000) + "ms")
                        #else:
                            #print ("Received other Message: " + str((time.time() - self.__DEBUG_START) * 1000) + "ms")


                except Exception as error:
                    if DEBUG: print("API-Berkelstim: ReadError: " + str(error))

                    # Lost Communication -> initiate Reconnect
                    self.flag_read = False
                    self.READY = False

            else:
                time.sleep(0.5)


    # Generates and sends a new message to the stimulaor
    def __generate_and_send_message(self, params, cmd_ID, stx=BB_messages.stx44):
        ## STX is stx44 by default for generate_and_send_message AND BB_messages.generate_message if not specified
        outgoing_message = BB_messages.generate_message(params, cmd_ID, stx)

        if len(outgoing_message) < 5:
            if DEBUG: print ("ERROR : Unvalid outgoing message generated for cmd_ID : ", cmd_ID)
            return

        self.client_socket.send(bytes(outgoing_message))


    # Performs a clean exit and disconnect from the stimulator attempting to switch off all stimulation channels
    def clean_exit(self):

        ## Set all channels to OFF by default
        if DEBUG: print("Setting stim OFF for all channels")

        try:
            self.StimOnOff.List_of_8_BOOL_ChannelOn = [False, False, False, False, False, False, False, False]
            self.__generate_and_send_message(self.StimOnOff, BB_messages.SET_STIM_ON_OFF_CMD_ID)
        except:
            pass

        self.flag_read = False
        self.flag_quit = True


        if DEBUG: print("Calling disconnect")
        try:
            self.client_socket.close()
        except bluetooth.btcommon.BluetoothError as error:
            if DEBUG: print ("Caught BluetoothError : " + str(error))
            pass




    ###################################################################################################################
    #   Stimulator Controll Functions
    ###################################################################################################################

    # Validates new
    def validateNewParameter(self):

        # Stimulator not ready
        if not self.READY:
            return False

        # Validate new Parameters
        msg = BB_messages.generate_message(None, BB_messages.MAKE_NEW_PARAMETERS_VALID_CMD_ID)
        if self.__send_acknowledged(msg) is None:
            return False
        else:
            return True


    # Changes the PhaseWidth for each channel
    def set_Phasewidths(self, PhWs, Monophasic, send_acknowledged = False):

        # Stimulator not ready
        if not self.READY:
            return False

        for channel in range(8):

            self.ChannelDataList[channel].Int16_PulsePosWidthInuS = PhWs[channel]
            if Monophasic[channel]:
                self.ChannelDataList[channel].Int16_PulseNegWidthInuS = 0
            else:
                self.ChannelDataList[channel].Int16_PulseNegWidthInuS = PhWs[channel]

            outgoing_message = BB_messages.generate_message(self.ChannelDataList[channel], BB_messages.SET_STIM_CHAN_PARAMS_CMD_ID)

            # Send acknowledged
            if (send_acknowledged):

                response = self.__send_acknowledged(outgoing_message)

                if response is None:
                    self.READY = False
                    return False

                BB_messages.handle_data(response)

            # Send unacknowledged
            else:
                self.__generate_and_send_message(self.ChannelDataList[channel], BB_messages.SET_STIM_CHAN_PARAMS_CMD_ID)


    # Changes the global Stimulation Frequency
    def set_StimFrequency(self, frequency, send_acknowledged = False):

        # Stimulator not ready
        if not self.READY:
            return False

        # Boundary Check
        if frequency > self.__Frequency_Max:
            if DEBUG: print('Frequency too high, set to highest : ' + str(self.__Frequency_Max))
            frequency = self.__Frequency_Max
        elif frequency < self.__Frequency_Min:
            if DEBUG: print('Frequency too low, set to lowest : ' + str(self.__Frequency_Min))
            frequency = self.__Frequency_Min

        # Change Frequency
        self.StimVarParams.Byte_Frequency = frequency

        # Send acknowledged
        if send_acknowledged:
            msg = BB_messages.generate_message(self.StimVarParams, BB_messages.SET_STIM_VAR_CMD_ID)
            response = self.__send_acknowledged(msg)

            if response is None:
                self.READY = False
                return False
            else:
                return True

        # Send unacknowlegded
        else:
            self.__generate_and_send_message(self.StimVarParams, BB_messages.SET_STIM_VAR_CMD_ID)
            return True


    # Sets global stimulation intensity in percentage
    def set_IntensityPercentage(self, percent_intensity):

        if percent_intensity > 100:
            if DEBUG: print('Percent Intensity too high, set to max : 100%')
            percent_intensity = 100
        elif percent_intensity < 0:
            if DEBUG: print('Percent Intensity too low, set to min : 0%')
            percent_intensity = 0

        # Wait for response
        self.SystemCurrentPercent.Byte_CurrentInPercent = percent_intensity;
        msg = BB_messages.generate_message(self.SystemCurrentPercent, BB_messages.SET_SYSTEM_CURRENT_PERCENTAGE_CMD_ID)
        result = self.__send_acknowledged(msg)


        # Give the stimulator time to process the comand - even though it was acknowleged
        #time.sleep(0.1)

        if result is None:
            return False
        else:
            return True

        # Do not wait for response
        # self.SystemCurrentPercent.Byte_CurrentInPercent = percent_intensity;
        # self.__generate_and_send_message(self.SystemCurrentPercent, SET_SYSTEM_CURRENT_PERCENTAGE_CMD_ID)


   # Allows setting the state of every channels at the same time
    def set_ActiveChannels(self, activeChannels, send_acknowledged = False):


        if len(activeChannels) == 8:
            self.StimOnOff.List_of_8_BOOL_ChannelOn = activeChannels
        else:
            if DEBUG: print('API_BerkelStim: ERROR - List of BOOLs given to set_stim_for_all_channels does not correspond')
            return

        # Wait for response -Safety measure
        if (send_acknowledged):
            msg = BB_messages.generate_message(self.StimOnOff, BB_messages.SET_STIM_ON_OFF_CMD_ID)
            self.__send_acknowledged(msg)

        # Do not wait for response
        else:
            self.__generate_and_send_message(self.StimOnOff, BB_messages.SET_STIM_ON_OFF_CMD_ID)


    # Toggle (ON/OFF) the Stimulation State for one particular channel
    def toggle_stim_for_1_channel(self,channel):
        if channel > 0 and channel < 9: channel -= 1;
        else:
            if DEBUG: print('Wrong channel number')
            return
        if self.StimOnOff.List_of_8_BOOL_ChannelOn[channel] == False:
            self.StimOnOff.List_of_8_BOOL_ChannelOn[channel] = True
        else :
            self.StimOnOff.List_of_8_BOOL_ChannelOn[channel] = False
        self.__generate_and_send_message(self.StimOnOff, BB_messages.SET_STIM_ON_OFF_CMD_ID)


    # Turn on Stimultion for one particular Channel
    def set_stim_for_1_channel(self,channel,bool_on = False):
        if channel > 0 and channel < 9:
            channel -= 1
        else:
            if DEBUG: print('Wrong channel number')
            return

        self.StimOnOff.List_of_8_BOOL_ChannelOn[channel] = bool_on
        self.__generate_and_send_message(self.StimOnOff, BB_messages.SET_STIM_ON_OFF_CMD_ID)


    # Returns the Stimulation State for one particular Channel
    def get_stim_for_1_channel(self,channel):
        if channel > 0 and channel < 9: channel -= 1;
        else:
            if DEBUG: print('Wrong channel number')
            return
        bool_on = self.StimOnOff.List_of_8_BOOL_ChannelOn[channel]
        return bool_on


    # Intensity range : 0mA to 200mA
    # The intensity given to the BerkelStimulator is in mA
    # So a factor 1000 is used to allow the user to stay in the mA range
    # TODO: Verify if working
    def set_stim_intensity_in_mA_for_1_channel(self, channel, intensity_mA):
        if channel > 0 and channel < 9: channel -= 1;
        else :
            if DEBUG: print('Wrong channel number')
            return

        if intensity_mA > self.__Intensity_Max :
            if DEBUG: print('Intensity too high, set to Maximum: ' + str(self.__Intensity_Max) + 'mA')
            intensity_mA = self.__Intensity_Max
        elif intensity_mA < self.__Intensity_Min :
            if DEBUG: print('Intensity too low, set to Minimum: ' + str(self.__Intensity_Min) + 'mA')
            intensity_mA = self.__Intensity_Min

        self.ChannelDataList[channel].Int32_CurrentInuA = intensity_mA * 1000;
        self.__generate_and_send_message(self.ChannelDataList[channel], BB_messages.SET_STIM_CHAN_PARAMS_CMD_ID)
        if DEBUG: print('STIMULATOR MESSAGE SENT\n')


    # Sets the Pulse parameter for an individual Channel
    # Pulse detailed:
    # PhaseWidth (PhW) / InterPhaseGap (IPG) / PhaseWidth (PhW)
    def set_stim_pw_for_1_channel(self, channel, PhW, IPG):

        if channel < 0 or channel > 9:
            if DEBUG: print('Wrong channel number')
            return


        if PhW < self.__PhaseWidth_Min or PhW > self.__PhaseWidth_Max or\
           IPG < self.__InterPhaseGap_Min or IPG > self.__InterPhaseGap_Max:
            if DEBUG: print('Given Pulse Width is not allowed')
            return

        self.ChannelDataList[channel].Int16_PulsePosWidthInuS = PhW;
        self.ChannelDataList[channel].Int16_PulseInterWidthInuS = IPG;
        self.ChannelDataList[channel].Int16_PulseNegWidthInuS = PhW;
        self.__generate_and_send_message(self.ChannelDataList[channel], BB_messages.SET_STIM_CHAN_PARAMS_CMD_ID)


    # Sets the stimulation Ramp for an particular Channel
    def set_stim_ramp_for_1_channel(self,channel,ramp_up = 1,ramp_down = 1):
        if channel > 0 and channel < 9: channel -= 1;
        else:
            if DEBUG: print('Wrong channel number')
            return

        ## A ramp equal to 1 seems to be the shortest ramp outputing a stable stimulation.
        ## Lower, the shape of the pulse width never rise and only the stimulation artifacts are visible.
        if ramp_up < 1 :
            ramp_up = 1

        if ramp_down < 1 :
            ramp_down = 1

        self.ChannelDataList[channel].Int16_RampUp = ramp_up
        self.ChannelDataList[channel].Int16_RampDown = ramp_down

        self.__generate_and_send_message(self.ChannelDataList[channel], BB_messages.SET_STIM_CHAN_PARAMS_CMD_ID)


    # Get the current stimulation intensity from the stimulator
    def get_stim_sytem_current(self, send_acknowledged = True):
        if (send_acknowledged):
            msg = BB_messages.generate_message(None, BB_messages.SEND_SYSTEM_CURRENT_CMD_ID)
            result = self.__send_acknowledged(msg)
            StimCurrent = result[3]

            return StimCurrent
            # ## Comparison between the two implemented ways
            # if DEBUG: print("Actual stim intensity percentage received and returned by the send_acknowledged function:",
            #                 result[3]);  ## The third byte of the response is the stim intensity percentage value.
            # if DEBUG: print("Actual stim intensity percentage received and returned by the BB_message handling func:",
            #                 BB_messages.Base_GeneralStatusParameters.SystemCurrent)
            # return BB_messages.Base_GeneralStatusParameters.SystemCurrent
        else:
            self.__generate_and_send_message(None, BB_messages.SEND_SYSTEM_CURRENT_CMD_ID)
            if DEBUG: print("Stim intensity percentage requested")












##############################################################
##############################################################
############		MAIN PROGRAM for testing		##########
##############################################################
##############################################################

if __name__ == '__main__':

    print("Main side : Creating instance of BERKELSTIM")
    BERKEL = BERKELSTIM()
 
## Initialization function called with the BerkelBike_FESBox mac_address to speed up the connection process
    BERKEL.init_connect('34:81:F4:36:E4:2D')
    # BERKEL.init_connect()


## Initialization done, creating user interface :

    response = ""
    current_channel = 1
    ## If version is python3 replace raw_input by input
    if sys.version_info[0] == 3:
        raw_input = input

##### START OF MAIN LOOP FOR USER INTERFACING #####
    try :
        while not BERKEL.flag_quit and response != "exit" :
            print("\nCurrent_channel = " + str(current_channel))

            response = raw_input("\nSelect channel by entering channel number.\
      Press enter without character to toggle stim (current channel). \n\
  '+p' '-p' to increase or decrease the pulse width (current channel).\n\
  '-f' '+f' to increase or decrease the frequency (all channels).\n\
  'p' 'f' 'i' 'r' to precisely define pw, freq, intensity(mA) or ramp (current channel except f).\n\
  'pw' to set the total pulse width (current channel).\n\
  'ii' to set the current intensity percentage (all channels).\n\
  'gi' to get the current intensity percentage (all channels).\n\
  Enter 'exit' to quit the test program.\n\n")

            for channel in range (1,9) :
                if response == str(channel) :
                    current_channel = channel
                    print("Changing current channel to : " + str(current_channel))

            if response == "":
                print("Toggling stim on current channel : " + str(current_channel))
                BERKEL.toggle_stim_for_1_channel(current_channel)

            elif response == "+p" :
                # BERKEL.ChannelDataList[current_channel].Byte_Channel = current_channel;
                BERKEL.ChannelDataList[current_channel].Int16_PulsePosWidthInuS += 100;
                BERKEL.ChannelDataList[current_channel].Int16_PulseInterWidthInuS += 50;
                BERKEL.ChannelDataList[current_channel].Int16_PulseNegWidthInuS += 100;
                # BERKEL.ChannelDataList[current_channel].Bool_PulsePositivePulseFirst = True;
                # BERKEL.ChannelDataList[current_channel].Int16_RampUp = 1;
                # BERKEL.ChannelDataList[current_channel].Int16_RampDown = 1;
                # BERKEL.ChannelDataList[current_channel].Int32_CurrentInuA += 5000;

                BERKEL.__generate_and_send_message(BERKEL.ChannelDataList[current_channel], \
                                                   BB_messages.SET_STIM_CHAN_PARAMS_CMD_ID)
                # outgoing_message = BB_messages.generate_message(ChannelDataList,SET_STIM_CHAN_PARAMS_CMD_ID)
                # MessageQueue.append(outgoing_message)
                # #t0 = time.time()
                # client_socket.send(bytes(outgoing_message))
                #validate_new_parameters(client_socket)


            elif response == "-p" :
                BERKEL.ChannelDataList[current_channel].Int16_PulsePosWidthInuS -= 100;
                BERKEL.ChannelDataList[current_channel].Int16_PulseInterWidthInuS -= 50;
                BERKEL.ChannelDataList[current_channel].Int16_PulseNegWidthInuS -= 100;
                # BERKEL.ChannelDataList[current_channel].Int32_CurrentInuA -= 5000;

                BERKEL.__generate_and_send_message(BERKEL.ChannelDataList[current_channel], \
                                                   BB_messages.SET_STIM_CHAN_PARAMS_CMD_ID)

            elif response == "p" :
                PhW = int(input("Enter Phasewidth in [us] : \n"))
                IPG = int(input("Enter InterPhaseGap in [us] : \n"))

                BERKEL.set_stim_pw_for_1_channel(current_channel, PhW, IPG)

            elif response == "pw" :
                pw = int(input("enter entire pulse width value : \n"))
                BERKEL.set_stim_pw_for_1_channel(current_channel, pw/2, 0.0)

            elif response == "+f" :
                BERKEL.set_StimFrequency(BERKEL.StimVarParams.Byte_Frequency + 10)#(24)

            elif response == "-f" :
                BERKEL.set_StimFrequency(BERKEL.StimVarParams.Byte_Frequency - 10)#(13.5)

            elif response == "f" :
                frequency = int(input("enter frequency value : \n"))

                BERKEL.set_StimFrequency(frequency)

            elif response == "i" :
                intensity = int(input("enter intensity value in mA for current_channel : \n"))

                BERKEL.set_stim_intensity_in_mA_for_1_channel(current_channel, intensity)

            elif response == "ii" :
                intensity = int(input("enter intensity value for all channels in percent : \n"))

                BERKEL.set_IntensityPercentage(intensity)
                
            elif response == "gi" :
                BERKEL.get_stim_sytem_current()

            elif response == "r" :
                ramp_up = int(input("enter ramp_up value for current_channel : \n"))
                ramp_down = int(input("enter ramp_down value for current_channel : \n"))

                BERKEL.set_stim_ramp_for_1_channel(current_channel, ramp_up, ramp_down)


    ## Just a sleep to make the user interface arrive later and at the bottom.
            time.sleep(0.25)

    except KeyboardInterrupt:
        print("KeyboardInterrupt during MAIN LOOP of user interface")
##### END OF MAIN LOOP FOR USER INTERFACING #####



    BERKEL.clean_exit()


    print("\nEND OF TEST PROGRAM\n")
##############################################################
############	End of MAIN PROGRAM for testing		##########
##############################################################
