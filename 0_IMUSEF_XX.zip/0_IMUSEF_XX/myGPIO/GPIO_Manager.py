# -*- coding: utf-8 -*-
"""
Module to handle the GPIO

Functionality:	# Controlling Beep (Buzzer)
				# Reading Left Button
				# Reading Right Button
				# Reading Boost Button
				# Reading of Encoder
"""

# IMPORTS
import threading
import time

try:
    import RPi.GPIO as GPIO
except ImportError:
    GPIO = False


class GPIO_Manager(object):

    def __init__(self, exit_Event):

        self.__exit_Event = exit_Event

        # Settings

        # Ports
        self.__port_System_LED = 5
        self.__port_Buzzer = 26
        self.__port_BOOST_Button = 22
        self.__port_LEFT_Button = 17
        self.__port_RIGHT_Button = 27
        self.__port_SPEED = 6
        self.__port_SWITCH_MAN_AUTO = 23
        self.__port_Emergency_Button = 24

        # Quang Encoder
        self.__port_CH_COUNT = 20
        self.__port_CH_DIR = 21
        self.__port_CHZ = 12

        self.__Encoder_DIR = 1                      # Direction of Q-Encoder, -1... subtract, 1... add
        self.__Encoder_Counter = 0                  # Value of Q-Encoder

        self.__Encoder = 0                          # 0 - 360
        self.__Encoder_Offset = 0                   # 0 - 360, to obtain the absolute Position
        self.__TriggerEncoderInit = 0               # Initiates the Encoder Initialisation

        self.__FLAG_ENCODER_INITIALIZED = False



        # Speed
        self.SPEED = True
        self.__lastSpeedTimstamp = 0.0
        self.__minSpeedPeriode = 0.0    # [s] ~36 km/h max Speed



        # Init GPIO
        global GPIO

        if GPIO == False:
            print("ERROR: Module <myGPIO> is not available!")
            return

        GPIO.setmode(GPIO.BCM) 											# Broadcom pin-numbering scheme
        GPIO.setwarnings(False)

        # Setup System LED
        GPIO.setup(self.__port_System_LED, GPIO.OUT)
        GPIO.output(self.__port_System_LED, GPIO.LOW)  # SYSTEM_LED OFF
        self.LED_blink_CNT = 0
        self.LED_State = False


        # Setup Buzzer
        self.__duration_Beep = 0.02
        self.__duration_break_Beep = 0.02
        self.__mode_Beep = 0
        self.__event_Beep = threading.Event()
        GPIO.setup(self.__port_Buzzer, GPIO.OUT) 							# Pin set as output
        GPIO.output(self.__port_Buzzer, GPIO.LOW) 							# Pin set as low (no sound)
        thread_Beep = threading.Thread(name='BEEP_Thread', target = self.__thread_Beep_function, args = ())
        thread_Beep.start()

        # Emergency-Button
        GPIO.setup(self.__port_Emergency_Button, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # Pin set as input

        # BOOST-Button
        GPIO.setup(self.__port_BOOST_Button, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # Pin set as input

        # Maunal Buttons LEFT / RIGHT
        GPIO.setup(self.__port_LEFT_Button, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # Pin set as input
        GPIO.setup(self.__port_RIGHT_Button, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # Pin set as input

        # MAN-AUTO-Switch
        GPIO.setup(self.__port_SWITCH_MAN_AUTO, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # Pin set as input

        # SPEED
        GPIO.setup(self.__port_SPEED, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # Pin set as input
        GPIO.add_event_detect(self.__port_SPEED, GPIO.RISING, callback=self.__SPEED_callback) #, bouncetime=400)


        # Encoder
        GPIO.setup(self.__port_CH_COUNT, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # Pin set as input
        GPIO.setup(self.__port_CH_DIR, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # Pin set as input
        GPIO.setup(self.__port_CHZ, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # Pin set as input

        GPIO.add_event_detect(self.__port_CH_COUNT, GPIO.BOTH, callback=self.__ENCODER_Count)
        GPIO.add_event_detect(self.__port_CH_DIR, GPIO.BOTH, callback=self.__ENCODER_CheckDirection)
        GPIO.add_event_detect(self.__port_CHZ, GPIO.RISING, callback=self.__ENCODER_Channel_Z_callback, bouncetime=50)



    # Creates a single Beep
    def Beep(self, duration = 0.02):
        self.__duration_Beep = duration
        self.__mode_Beep = 0
        self.__event_Beep.set()

    # Creates a double Beep
    def DoubleBeep(self, duration = 0.02, duration_break = 0.1):
        self.__duration_Beep = duration
        self.__duration_break_Beep = duration_break
        self.__mode_Beep = 1
        self.__event_Beep.set()

    # Thread function to be executed from the Beep-Thread
    def __thread_Beep_function(self):
        global GPIO

        if GPIO==False:
            print("No GPIO. Closing audio cue thread.")
            return

        while not self.__exit_Event.isSet():

            # Wait for Event to happen
            self.__event_Beep.wait(0.5)

            # Do the Beep
            if self.__event_Beep.isSet():

                if self.__mode_Beep == 0:
                    GPIO.output(self.__port_Buzzer, GPIO.HIGH)
                    time.sleep(self.__duration_Beep)
                    GPIO.output(self.__port_Buzzer, GPIO.LOW)
                elif self.__mode_Beep == 1:
                    GPIO.output(self.__port_Buzzer, GPIO.HIGH)
                    time.sleep(self.__duration_Beep)
                    GPIO.output(self.__port_Buzzer, GPIO.LOW)
                    time.sleep(self.__duration_break_Beep)
                    GPIO.output(self.__port_Buzzer, GPIO.HIGH)
                    time.sleep(self.__duration_Beep)
                    GPIO.output(self.__port_Buzzer, GPIO.LOW)

                self.__event_Beep.clear()

        # Clean up after exit
        GPIO.cleanup()



    # Returns the State of the Emergency Button
    # - 0: Emergency Button is pressed
    # - 1: Emergency Button not pressed
    def getButton_Emergency(self):

        state = GPIO.input(self.__port_Emergency_Button)

        # If emergency button not pressed -> LED ON
        if state:
            self.LED_blink_CNT = 0
            self.setSystemLED(True)
        # LED blinking
        else:
            self.LED_blink_CNT += 1

        # After 500ms toggle LED STATE
        if self.LED_blink_CNT > 10:
            self.LED_blink_CNT = 0
            self.setSystemLED(not self.LED_State)

        if state:
           return 0
        else:
            return 1

    # Returns the State of the BOOST Button
    # - 1: Button is pressed
    # - 0: Button not pressed
    def getButton_BOOST(self):

        state = GPIO.input(self.__port_BOOST_Button)

        if state:
            return 0
        else:
            return 1

    # Returns the State of the LEFT Button
    # - 1: Button is pressed
    # - 0: Button not pressed
    def getButton_LEFT(self):

        return  GPIO.input(self.__port_LEFT_Button)

    # Returns the State of the RIGHT Button
    # - 1: Button is pressed
    # - 0: Button not pressed
    def getButton_RIGHT(self):

        return GPIO.input(self.__port_RIGHT_Button)

    # Returns the State of the MAN_AUTO Switch
    # - 1: Switch is ON
    # - 0: Switch is OFF
    def getSwitch_MAN_AUTO(self):

        return GPIO.input(self.__port_SWITCH_MAN_AUTO)



    def getSpeedTimeStamp(self):
        return self.__lastSpeedTimstamp

    # Executes actions after receiving an event from Encoder Channel Z
    def __SPEED_callback(self, channel):

        if self.__lastSpeedTimstamp == 0.0:
            self.__lastSpeedTimstamp = time.time()
        else:
            now = time.time()

            if(now - self.__lastSpeedTimstamp) > self.__minSpeedPeriode:
                self.__lastSpeedTimstamp = now


    # Check Direction
    def __ENCODER_CheckDirection(self, channel):

        if GPIO.input(self.__port_CH_DIR):
            self.__Encoder_DIR = -1
        else:
            self.__Encoder_DIR = 1



    # Count on Channel
    def __ENCODER_Count(self, channel):
        self.__Encoder_Counter = self.__Encoder_Counter + self.__Encoder_DIR

        # Overflow Check
        if self.__Encoder_Counter > 360:
            self.__Encoder_Counter = 0

        if self.__Encoder_Counter < 0:
            self.__Encoder_Counter = 360

        print("Channel: " + str(self.__Encoder_Counter))


    # Reset Encoder
    def __ENCODER_Channel_Z_callback(self, channel):
        #print("\n RESET ENCODER")
        self.__TriggerEncoderInit = True

        if self.__Encoder_DIR == 1:
            self.__Encoder_Counter = 298
        else:
            self.__Encoder_Counter = 299


    # Returns the current value of the Encoder
    def getEncoderValue(self):

        if self.__TriggerEncoderInit:
            return self.__Encoder_Counter
        else:
            return -1

    # Returns the current Status of the Encoder
    def getEncoderStatus(self):

        if self.__TriggerEncoderInit:
            return 1
        else:
            return 0


    # Set´s or clears the output of the Debug-Pin TODO; REMOVE
    def setDEBUG_PIN(self, set_pin):
        return

    # Sets the System LED to indicate that the system is ready
    def setSystemLED(self, set_LED):

        if set_LED == self.LED_State:
            return

        if set_LED:
            GPIO.output(self.__port_System_LED, 1)
            self.LED_State = True
        else:
            GPIO.output(self.__port_System_LED, 0)
            self.LED_State = False



### Main Programm
if __name__ == '__main__':
    event_exit = threading.Event()
    mygpio = GPIO_Manager(event_exit)

    mygpio.DoubleBeep()

    try:
        while True:

            print("CrankAngle: " + str(mygpio.CrankAngle))
            time.sleep(0.01)
    except KeyboardInterrupt:
        print('\nUser requested Application STOP\n')
        event_exit.set()
