import copy
import numpy as np

X_ref = [0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0]

X = [1.5, 2.1, 3.1, 3.5, 3.7, 4.9, 5.1, 5.2, 6.8, 6.9]
Y = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0]


end = len(Y)-1
LEFT = Y[0]
RIGHT = Y[end]

Y_new = np.interp(X_ref, X, Y, left=LEFT, right=RIGHT)
Y_result = Y_new.tolist()

X_ref = (np.linspace(0,100,101)).tolist()
X_ref = range(10,-1,-1)


print(str(X_ref))

