
class CyclingComputer_Data(object):
    def __init__(self):

        # Flag identifying a new Cycle
        self.NewCycle = False

        # Speed
        self.Speed = 0.0

        # Distance
        self.Distance = 0.0

        # CrankAngle from OpenDAQ (Only ICE-Trike)
        self.CrankAngle = 0

        # Cadence
        self.Cadence = 0.0

        # Average Power per cycle
        self.Power_AVG = 0.0

        # Speed
        self.Speed = 0.0

        # Distance
        self.Distance = 0.0


