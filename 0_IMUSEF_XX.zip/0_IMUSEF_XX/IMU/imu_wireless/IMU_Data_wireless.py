# This class represents Data obtained from the wireless IMU
class IMU_Data_wireless(object):

    def __init__(self):

        # Wireless IMU Data
        self.CrankAngle = 0.0;