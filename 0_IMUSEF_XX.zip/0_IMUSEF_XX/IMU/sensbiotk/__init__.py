# -*- coding: utf-8; -*-
_version_major = 2
_version_minor = 0
_version_micro = ''
_version_extra = 'dev'

# Format expected by setup.py and doc/source/conf.py: string of form "X.Y.Z"
__version__ = "%s.%s.%s%s" % (_version_major,
                              _version_minor,
                              _version_micro,
                              _version_extra)
