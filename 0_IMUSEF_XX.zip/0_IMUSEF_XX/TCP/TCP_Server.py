# IMPORTS
import socket
import threading
import time
from TCP.TCP_Message import TCP_Message
import queue
from random import randrange
import socket
from socket import SHUT_RDWR
import struct
import sys



class TCP_Server(object):

    NOT_CONNECTED = -1
    LISTENING = 0
    CONNECTED = 1

    def __init__(self, port):

        # DataContainer
        self.__sendingQueue = queue.Queue()
        self.__receiveQueue = queue.Queue()
        self.queueLock = threading.Lock()

        # Settings
        self.__ReceiveBufferSize = 2048
        self.__TCP_port = port

        # Connection Variables
        self.STATE = TCP_Server.NOT_CONNECTED
        self.__reconnect = False

        # Keep Alive Variables
        self.__KeepAlive_Interval =  1.0           # [s]
        self.__KeepAlive_ACK = False
        self.__KeepAlive_MSG = TCP_Message()
        self.__KeepAlive_MSG.buildMessage(TCP_Message.CMD_KEEP_ALIVE,"")

        self.DEBUG = False


    # Working Thread to ensure Connection, performs automatic reconnect if connection is lost
    def __Connecting_Worker(self, exit_Event):

        # Main - Loop
        while not exit_Event.isSet():

            # If not connected
            if self.STATE == TCP_Server.NOT_CONNECTED:

                # Clear up old things
                try:
                    self.__connection.shutdown(SHUT_RDWR)
                    self.__connection.close()

                except Exception as e:

                    if self.DEBUG:
                        print ("TCP_Server: Closing Error:" ,e)
                    pass

                # Try to connect
                self.STATE = TCP_Server.LISTENING

                while not exit_Event.isSet() and self.STATE == TCP_Server.LISTENING:

                    try:
                        if not self.__reconnect:
                            # Create a TCP/IP socket
                            if self.DEBUG:
                                print("TCP-Server: Create Socket")
                            self.__sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

                            if self.DEBUG:
                                print("TCP-Server: Set Socket Options ")
                            self.__sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

                            # Bind the socket to the address given
                            server = ('', self.__TCP_port)
                            if self.DEBUG:
                                print("TCP-Server: Bind Server")
                            self.__sock.bind(server)

                            if self.DEBUG:
                                print("TCP-Server: Set Reconnect = True ")
                            self.__reconnect = True

                        if self.DEBUG:
                            print("TCP-Server: Start Listening for Client ")
                        self.__sock.listen(1)

                        # Waiting for Client
                        print('TCP-Server: Waiting for Client')
                        self.__connection, self.Client = self.__sock.accept()
                        self.__connection.settimeout(2.0)

                        # Found somebody to play with
                        print('TCP-Server: Client connected:', self.Client)

                        # Send first KeepAlive Message
                        self.__KeepAlive_ACK = True

                        # Set state connected
                        self.STATE = TCP_Server.CONNECTED


                    except Exception as error:

                        if self.DEBUG:
                            print("TCP-Server: Error during Connecting:", error)

                        self.STATE = TCP_Server.NOT_CONNECTED


            # Use to check if Connection is still alive
            elif self.STATE == TCP_Server.CONNECTED:

                    if self.__KeepAlive_ACK:
                        self.__KeepAlive_ACK = False

                        if self.DEBUG:
                            print("TCP-Server: Send Keep Alive -> ")

                        self.sendData(self.__KeepAlive_MSG.toString())
                    else:
                        if self.DEBUG:
                            print("TCP-Server: KA - Connection to Client lost!!!")

                        self.STATE = TCP_Server.NOT_CONNECTED

            if self.STATE == TCP_Server.CONNECTED:
                time.sleep(self.__KeepAlive_Interval)
            else:
                time.sleep(0.1)



    # Puts a new String into the Sending Queue to be processed
    def sendData(self, data):

        if self.STATE == TCP_Server.NOT_CONNECTED:
            return

        # Lock is potenitally useless - but it also does not do any harm
        self.queueLock.acquire()
        self.__sendingQueue.put(data)
        self.queueLock.release()

    # Returns the first message String of the sending Queue. If there is no data, "" is returned
    def getMessage(self):

        try:
            return self.__receiveQueue.get(False)
        except Exception as e:
            return ""

    # Informs wheter there is data received from the client
    def hasData(self):

        if not (self.STATE == TCP_Server.CONNECTED):
            return  False
        else:
            return not self.__receiveQueue.empty()


    # Doing the work, sends data if there is some. Otherwise just waiting
    def __Sending_Worker(self, exit_Event):

       while not exit_Event.isSet():

            if self.STATE == TCP_Server.CONNECTED:
                try:
                    # Get message to send
                     data = self.__sendingQueue.get(True, 0.5)
                     message = data.encode("utf-8")

                     self.__connection.sendall(message)


                except Exception as e:
                    # if self.DEBUG:
                    #     print("TCP-Server: Sending Error" + str(e))
                    pass
            else:
                time.sleep(0.01)

    # Doing the work, sends data if there is some. Otherwise just waiting
    def __Receiving_Worker(self, exit_Event):

        # Main Loop for Receiving
        while not exit_Event.isSet():

            if self.STATE == TCP_Server.CONNECTED:
               try:

                   data = self.__connection.recv(self.__ReceiveBufferSize).decode("utf-8")

                   # Client said good bye
                   if data =="":
                       raise Exception

                   else:
                       msg = TCP_Message()
                       msg.parseFromString(data)

                       self.__KeepAlive_ACK = True

                       if not (msg.CMD == TCP_Message.CMD_KEEP_ALIVE):
                           self.__receiveQueue.put(msg)

                       if self.DEBUG:
                           print("TCP-Server: Received: " + data)

               except Exception as error:

                   #print("Receiving error", error)
                   print("TCP-Server: Connection to Client lost!!!")
                   if self.STATE == TCP_Server.CONNECTED:
                       self.STATE = TCP_Server.NOT_CONNECTED
            else:
                time.sleep(0.1)



    # Starts the Server in order to find a client
    def start(self, exit_Event):

        # Start Connecting Thread
        self.__thread_Connecting_Worker = threading.Thread(name='TCP_Connenction_Thread', target=self.__Connecting_Worker, args=(exit_Event,))
        self.__thread_Connecting_Worker.daemon = True
        self.__thread_Connecting_Worker.start()

        # Starting Thread
        self.__thread_Receiving_Worker = threading.Thread(name='TCP_Receiving_Thread', target=self.__Receiving_Worker, args=(exit_Event,))
        self.__thread_Receiving_Worker.daemon = True
        self.__thread_Receiving_Worker.start()

        # Start Sending Thread
        self.__thread_Sending_Worker = threading.Thread(name='TCP_Sending_Thread', target=self.__Sending_Worker, args=(exit_Event,))
        self.__thread_Sending_Worker.daemon = True
        self.__thread_Sending_Worker.start()


    def stop(self):
        try:

            #self.__reconnect = False
            self.STATE = TCP_Server.NOT_CONNECTED
            self.__connection.close()
            self.__sock.close()

        except Exception as error:

            #Ignore for now
            if self.DEBUG:
                print("TCP_Server: Stop" + str(error))
            pass


if __name__ == '__main__':

    e = threading.Event()
    myTCPServer = TCP_Server(12346)
    myTCPServer.start(e)


    i = 0
    try:
        while True:


            i+=1
            if myTCPServer.STATE == TCP_Server.CONNECTED:
                print(str(i) + ") Working")

                myTCPServer.sendData(str(randrange(10)))

                # Did we receive some data?
                while myTCPServer.hasData():
                    msg = myTCPServer.getMessage()

                    print(str(myTCPServer.Client) + ": "+msg);

            elif myTCPServer.STATE == TCP_Server.LISTENING:
                print("Waiting for Client")
            else:
                print("No connection: Trying to connect")

            time.sleep(1)


    except KeyboardInterrupt:
       print("KEYBOARD INTERRUPT")

    e.set()



    print("All good now")





