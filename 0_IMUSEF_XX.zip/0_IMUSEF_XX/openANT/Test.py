
value = 0b10101010
mask  = 0b00001110

result = value & mask
result = result >> 1

print(str(result))


